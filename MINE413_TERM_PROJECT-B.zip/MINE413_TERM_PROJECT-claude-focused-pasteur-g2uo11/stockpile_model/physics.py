"""Forward (predictive) physics of dumping, dozing and gravity on a raster.

Used for two purposes:

1. to give every load a physically motivated *release point*: the place
   where the dozer pushes it over the crest of the active face (A-019);
2. to *predict* where an interval's material ends up without looking at that
   interval's survey, so that the movement concept can be tested on held-out
   intervals (Phase 5, `validation.py`).

Model (Methodology §5.1):

* Surface before interval k, ``Z_{k-1}``: latest top of earlier solids where
  known, otherwise the pre-model surface (base of the first solid that later
  covers the cell). Cells never covered are extrapolated from the nearest
  known cell (flat pad behind the crest, flat apron in front of the toe; A-020).
* Face cells: slope of ``Z_{k-1}`` >= ``face_slope_deg``.
* Push: each trusted-location load is moved from its dump point to the
  nearest face cell (dozer pushes the shortest way to the crest; A-019).
* Gravity: the load is deposited as a cone at the angle of repose at the
  release point and the surface is relaxed with a sand-pile cellular
  automaton (mobile layer over a fixed, non-erodible bed) until no slope of
  the new material exceeds the angle of repose (A-018).
"""

from __future__ import annotations

import numpy as np
from scipy.ndimage import distance_transform_edt, uniform_filter

from .io_survey import GridSpec

_NEIGH = [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]


def surface_before(rasters, z_pre: np.ndarray, k: int) -> np.ndarray:
    """Known surface at the start of interval k (NaN where never observed)."""
    Z = z_pre.copy()
    for j in range(k):
        m = rasters[j].mask
        Z[m] = rasters[j].top[m]
    return Z


def extrapolate(Z: np.ndarray) -> np.ndarray:
    """Fill NaN cells with the value of the nearest known cell."""
    known = np.isfinite(Z)
    if known.all():
        return Z.copy()
    idx = distance_transform_edt(~known, return_distances=False, return_indices=True)
    return Z[tuple(idx)]


def slope_deg(Z: np.ndarray, cell: float, smooth_cells: int = 1) -> np.ndarray:
    Zs = uniform_filter(Z, size=smooth_cells) if smooth_cells > 1 else Z
    gy, gx = np.gradient(Zs, cell)
    return np.degrees(np.arctan(np.hypot(gx, gy)))


def face_mask(Z_full: np.ndarray, known: np.ndarray, cell: float, face_slope_deg: float) -> np.ndarray:
    return known & (slope_deg(Z_full, cell, smooth_cells=3) >= face_slope_deg)


def release_points(grid: GridSpec, face: np.ndarray, x, y):
    """Nearest face cell to each (x, y); returns (row, col, push distance m)."""
    if not face.any():
        raise ValueError("no face cells")
    dist, idx = distance_transform_edt(~face, return_distances=True, return_indices=True)
    r, c = grid.index(x, y)
    ok = r >= 0
    rr = np.where(ok, idx[0][r.clip(0), c.clip(0)], -1)
    cc = np.where(ok, idx[1][r.clip(0), c.clip(0)], -1)
    d = np.where(ok, dist[r.clip(0), c.clip(0)] * grid.cell, np.nan)
    return rr, cc, d


def cone(grid: GridSpec, r0: int, c0: int, volume: float, repose_deg: float) -> np.ndarray:
    """Thickness raster of a cone of given volume at the angle of repose."""
    t = np.tan(np.radians(repose_deg))
    radius = (3.0 * volume / (np.pi * t)) ** (1.0 / 3.0)
    n = int(np.ceil(radius / grid.cell)) + 1
    rs = np.arange(max(r0 - n, 0), min(r0 + n + 1, grid.ny))
    cs = np.arange(max(c0 - n, 0), min(c0 + n + 1, grid.nx))
    R, C = np.meshgrid(rs, cs, indexing="ij")
    d = np.hypot(R - r0, C - c0) * grid.cell
    h = np.clip((radius - d) * t, 0, None)
    out = np.zeros((grid.ny, grid.nx))
    s = h.sum() * grid.cell_area
    if s > 0:
        out[R, C] = h * (volume / s)  # exact volume after discretisation / clipping
    return out


def relax(bed: np.ndarray, mobile: np.ndarray, cell: float, repose_deg: float, tol: float = 1e-3,
          max_iter: int = 20000, rate: float = 0.5) -> tuple[np.ndarray, int]:
    """Sand-pile relaxation of a mobile layer over a fixed bed.

    Only the mobile thickness (newly dumped material) can move; the surveyed
    bed is non-erodible (pre-existing faces stand steeper than the angle of
    repose in places, and must not be eroded by the model). Each iteration,
    for every cell and its 8 neighbours, the excess drop above
    ``tan(phi) * distance`` of the total surface is computed; a cell sends
    ``rate * max_excess / 2`` (capped by its mobile thickness) to its downhill
    neighbours in proportion to their excess. Transfers are pairwise, so
    volume is conserved exactly; the boundary is closed. Returns the final
    mobile thickness and the number of iterations.
    """
    m = mobile.astype(float).copy()
    t = np.tan(np.radians(repose_deg))
    crit = [t * cell * np.hypot(dr, dc) for dr, dc in _NEIGH]
    ny, nx = m.shape
    P = np.full((ny + 2, nx + 2), np.inf)
    it = 0
    for it in range(1, max_iter + 1):
        Z = bed + m
        P[1:-1, 1:-1] = Z
        ex = np.empty((8, ny, nx))
        for n, (dr, dc) in enumerate(_NEIGH):
            nb = P[1 + dr:1 + dr + ny, 1 + dc:1 + dc + nx]
            ex[n] = np.clip(Z - nb - crit[n], 0, None)
        ex *= (m > 0)[None]
        mx = ex.max(axis=0)
        if mx.max() < tol:
            break
        tot = ex.sum(axis=0)
        move = np.minimum(rate * 0.5 * mx, m)
        share = np.divide(ex, tot, out=np.zeros_like(ex), where=tot > 0)
        m -= move
        for n, (dr, dc) in enumerate(_NEIGH):
            inflow = move * share[n]
            m[max(dr, 0):ny + min(dr, 0), max(dc, 0):nx + min(dc, 0)] += \
                inflow[max(-dr, 0):ny + min(-dr, 0), max(-dc, 0):nx + min(-dc, 0)]
    return m, it


def relax_windowed(bed: np.ndarray, mobile: np.ndarray, cell: float, repose_deg: float,
                   margin_m: float = 40.0, **kw) -> tuple[np.ndarray, int]:
    """Run ``relax`` only on the bounding box of the mobile material + margin."""
    rows, cols = np.nonzero(mobile > 0)
    if rows.size == 0:
        return mobile.copy(), 0
    mg = int(np.ceil(margin_m / cell))
    r0, r1 = max(rows.min() - mg, 0), min(rows.max() + mg + 1, bed.shape[0])
    c0, c1 = max(cols.min() - mg, 0), min(cols.max() + mg + 1, bed.shape[1])
    out = mobile.astype(float).copy()
    sub, it = relax(bed[r0:r1, c0:c1], mobile[r0:r1, c0:c1], cell, repose_deg, **kw)
    out[r0:r1, c0:c1] = sub
    return out, it


def predict_interval(grid: GridSpec, Z_before_full: np.ndarray, face: np.ndarray, loads, repose_deg: float,
                     mode: str = "push", tol: float = 5e-3) -> np.ndarray:
    """Predicted fill thickness for one interval.

    ``loads``: iterable of (x, y, volume, trusted_location).
    ``mode``: "push" (dump -> nearest face cell -> cone -> relax),
    "no_push" (cone at the dump point -> relax), "uniform_face" (volume spread
    uniformly over face cells -> relax). Untrusted-location loads are spread
    uniformly over face cells in every mode.
    """
    add = np.zeros_like(Z_before_full)
    fr, fc = np.nonzero(face)
    for x, y, vol, trusted in loads:
        if vol <= 0:
            continue
        if mode == "uniform_face" or not trusted:
            add[fr, fc] += vol / (len(fr) * grid.cell_area)
            continue
        if mode == "push":
            rr, cc, _ = release_points(grid, face, np.array([x]), np.array([y]))
            r0, c0 = int(rr[0]), int(cc[0])
        else:
            r, c = grid.index(np.array([x]), np.array([y]))
            r0, c0 = int(r[0]), int(c[0])
        if r0 < 0:
            continue
        add += cone(grid, r0, c0, vol, repose_deg)
    mobile, _ = relax_windowed(Z_before_full, add, grid.cell, repose_deg, tol=tol)
    return mobile


def coarse_grid(grid: GridSpec, factor: int) -> GridSpec:
    return GridSpec(grid.x_min, grid.y_min, grid.nx // factor, grid.ny // factor, grid.cell * factor)


def block_mean(a: np.ndarray, factor: int) -> np.ndarray:
    """Mean of factor x factor blocks, ignoring NaN (NaN if a block is all NaN)."""
    ny, nx = a.shape[0] // factor, a.shape[1] // factor
    b = a[:ny * factor, :nx * factor].reshape(ny, factor, nx, factor)
    with np.errstate(invalid="ignore"):
        cnt = np.isfinite(b).sum(axis=(1, 3))
        s = np.nansum(b, axis=(1, 3))
    return np.where(cnt > 0, s / np.maximum(cnt, 1), np.nan)


def slide_path(S: np.ndarray, r: int, c: int, cell: float, repose_deg: float, max_steps: int = 400):
    """Follow steepest descent from (r, c) while the drop to the lowest
    neighbour is steeper than the angle of repose; return the stop cell.

    Represents loose material running down a face steeper than its repose
    angle until it reaches the toe (A-018).
    """
    t = np.tan(np.radians(repose_deg))
    ny, nx = S.shape
    for _ in range(max_steps):
        best, br, bc = 0.0, r, c
        for dr, dc in _NEIGH:
            rr, cc = r + dr, c + dc
            if 0 <= rr < ny and 0 <= cc < nx:
                d = cell * np.hypot(dr, dc)
                s = (S[r, c] - S[rr, cc]) / d
                if s > best:
                    best, br, bc = s, rr, cc
        if best <= t:
            break
        r, c = br, bc
    return r, c


def deposit_cone(S: np.ndarray, r0: int, c0: int, volume: float, cell: float, repose_deg: float,
                 max_radius_m: float = 60.0) -> np.ndarray:
    """Thickness of a pile of given volume built at (r0, c0) against the bed S.

    The pile surface is the cone H - tan(phi) * d; thickness = max(0, cone - S).
    H is found by bisection so the deposited volume is exact (to 1e-9 rel).
    """
    t = np.tan(np.radians(repose_deg))
    n = int(np.ceil(max_radius_m / cell))
    rs = slice(max(r0 - n, 0), min(r0 + n + 1, S.shape[0]))
    cs = slice(max(c0 - n, 0), min(c0 + n + 1, S.shape[1]))
    R, C = np.mgrid[rs, cs]
    d = np.hypot(R - r0, C - c0) * cell
    sub = S[rs, cs]
    a = cell * cell

    def vol(H):
        return np.clip(H - t * d - sub, 0, None).sum() * a

    lo = S[r0, c0]
    hi = lo + max(1.0, (3 * volume / (np.pi * t)) ** (1 / 3) * t * 4)
    while vol(hi) < volume:
        hi += (hi - lo)
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        if vol(mid) < volume:
            lo = mid
        else:
            hi = mid
        if hi - lo < 1e-7:
            break
    th = np.clip(hi - t * d - sub, 0, None)
    th *= volume / (th.sum() * a)
    out = np.zeros_like(S)
    out[rs, cs] = th
    return out


def predict_interval_geometric(grid: GridSpec, Z_before_full: np.ndarray, face: np.ndarray, loads,
                               repose_deg: float, mode: str = "push") -> np.ndarray:
    """Fast forward prediction: release -> slide to toe -> cone against bed.

    ``loads`` in time order: (x, y, volume, trusted_location). Modes as in
    ``predict_interval``. Material from untrusted locations (and all material
    in ``uniform_face`` mode) is spread as a uniform layer over face cells.
    """
    S = Z_before_full.copy()
    fr, fc = np.nonzero(face)
    for x, y, vol, trusted in loads:
        if vol <= 0:
            continue
        if mode == "uniform_face" or not trusted:
            S[fr, fc] += vol / (len(fr) * grid.cell_area)
            continue
        if mode == "push":
            rr, cc, _ = release_points(grid, face, np.array([x]), np.array([y]))
        else:
            rr, cc = grid.index(np.array([x]), np.array([y]))
        r0, c0 = int(rr[0]), int(cc[0])
        if r0 < 0:
            continue
        r1, c1 = slide_path(S, r0, c0, grid.cell, repose_deg)
        S += deposit_cone(S, r1, c1, vol, grid.cell, repose_deg)
    return S - Z_before_full


def block_sum(a: np.ndarray, factor: int) -> np.ndarray:
    """Sum of factor x factor blocks (NaN treated as 0)."""
    ny, nx = a.shape[0] // factor, a.shape[1] // factor
    return np.nan_to_num(a[:ny * factor, :nx * factor]).reshape(ny, factor, nx, factor).sum(axis=(1, 3))
