"""Configuration loading (TOML) with deep-merge of user overrides."""

from __future__ import annotations

import copy
import tomllib
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = REPO_ROOT / "config" / "default.toml"


def deep_merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_config(path: str | Path | None = None, overrides: dict | None = None) -> dict:
    with open(DEFAULT_CONFIG, "rb") as fh:
        cfg = tomllib.load(fh)
    if path is not None and Path(path).resolve() != DEFAULT_CONFIG:
        with open(path, "rb") as fh:
            cfg = deep_merge(cfg, tomllib.load(fh))
    if overrides:
        cfg = deep_merge(cfg, overrides)
    return cfg


def set_by_path(cfg: dict, dotted: str, value) -> dict:
    """Return a copy of cfg with ``a.b.c`` set to value (for sensitivity runs)."""
    out = copy.deepcopy(cfg)
    node = out
    parts = dotted.split(".")
    for p in parts[:-1]:
        node = node.setdefault(p, {})
    node[parts[-1]] = value
    return out
