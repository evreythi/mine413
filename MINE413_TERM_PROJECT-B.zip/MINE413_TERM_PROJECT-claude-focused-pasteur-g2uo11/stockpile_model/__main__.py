"""Command-line interface.

    python -m stockpile_model ingest "Data_Topo 2026.zip"   # import new data
    python -m stockpile_model run                            # full pipeline
    python -m stockpile_model run --stages qaqc              # selected stages
"""

from __future__ import annotations

import argparse
import sys
import time

from .config import REPO_ROOT, load_config
from .pipeline import load_inputs, resolve

STAGES = ["qaqc", "growth", "movement", "blockmodel", "uncertainty"]


def _qaqc_flags(inp, cfg):
    from . import qaqc
    return qaqc.flag_records(inp.fms, cfg, inp.grid, inp.rasters, inp.interval_idx)


def cmd_ingest(args):
    from .ingest import ingest
    cfg = load_config(args.config)
    new = ingest(args.source, resolve(cfg["data"]["raw_dir"]))
    print(new[["kind", "stored_as", "status", "sha256"]].to_string(index=False))
    if (new["status"] == "REFUSED_conflict").any():
        print("ERROR: a file with the same name but different content already exists; rename it.", file=sys.stderr)
        return 2
    return 0


def cmd_run(args):
    from . import audit
    cfg = load_config(args.config)
    if args.mc is not None:
        cfg["uncertainty"]["mc_realisations"] = args.mc
    out_root = resolve(args.out)
    out_root.mkdir(parents=True, exist_ok=True)
    stages = args.stages.split(",") if args.stages else STAGES
    for i, st in enumerate(stages):
        missing = [d for d in STAGES[:STAGES.index(st)] if d not in stages and d != "qaqc"]
        if missing:
            raise SystemExit(f"stage '{st}' needs {missing} in the same run")
    run_id = audit.new_run_id()
    git_at_start = audit.git_state()
    durations = {}
    t0 = time.time()
    inp = load_inputs(cfg)
    durations["load_inputs"] = round(time.time() - t0, 1)
    print(f"[{run_id}] loaded {len(inp.surveys)} surveys, {len(inp.fms)} FMS records in {durations['load_inputs']}s")
    results = {}
    iv = audit.load_interventions(resolve(cfg["data"]["interventions_file"]))
    t = time.time()
    if "qaqc" in stages:
        from . import stage_qaqc
        results["qaqc"] = stage_qaqc.run(inp, cfg, out_root / "01_qaqc", interventions=iv)
        print("qaqc:", results["qaqc"]["summary"])
        fl, iv_log = results["qaqc"]["flagged"], results["qaqc"]["interventions"]
    else:
        fl, iv_log = audit.apply_interventions(_qaqc_flags(inp, cfg), iv)
    durations["qaqc"] = round(time.time() - t, 1)
    t = time.time()
    if "growth" in stages:
        from . import stage_growth
        results["growth"] = stage_growth.run(inp, cfg, out_root / "02_growth", fl)
        durations["growth"] = round(time.time() - t, 1)
        print("growth:", {k: v for k, v in results["growth"]["summary"].items() if k != "calibration"})
    t = time.time()
    if "movement" in stages:
        from . import stage_movement
        results["movement"] = stage_movement.run(inp, cfg, out_root / "03_movement", results["growth"])
        durations["movement"] = round(time.time() - t, 1)
        print("movement:", results["movement"]["summary"])
    t = time.time()
    if "blockmodel" in stages:
        from . import stage_blockmodel
        results["blockmodel"] = stage_blockmodel.run(inp, cfg, out_root / "04_blockmodel", results["movement"],
                                                     results["growth"], fl)
        durations["blockmodel"] = round(time.time() - t, 1)
        print("blockmodel:", results["blockmodel"]["summary"])
    t = time.time()
    if "uncertainty" in stages:
        from . import stage_uncertainty
        results["uncertainty"] = stage_uncertainty.run(inp, cfg, out_root / "05_uncertainty", results, fl)
        durations["uncertainty"] = round(time.time() - t, 1)
        print("uncertainty:", results["uncertainty"]["summary"])
    manifest = audit.write_manifest(out_root, run_id, cfg, inp, stages, durations, results, iv_log, git_at_start)
    if "blockmodel" in stages:
        hist = audit.record_history(out_root, manifest)
        report = audit.change_report(hist)
        (out_root / "change_report.txt").write_text(report)
        print(report)
    print(f"[{run_id}] done in {time.time() - t0:.0f}s; manifest: {out_root / 'run_manifest.json'}")
    return 0


def cmd_report(args):
    from .report import build
    print("written:", build(resolve(args.out)))
    return 0


def cmd_status(args):
    """Show the managed inputs and the last recorded model run."""
    import pandas as pd
    cfg = load_config(args.config)
    raw = resolve(cfg["data"]["raw_dir"])
    log = raw / "ingest_log.csv"
    if log.exists():
        lg = pd.read_csv(log)
        print(lg.groupby("kind").stored_as.nunique().rename("files").to_string())
        print("last ingest:", lg.ingested_utc.max())
    else:
        print("no data ingested yet")
    hist = resolve(args.out) / "run_history.csv"
    if hist.exists():
        print(pd.read_csv(hist).tail(3).to_string(index=False))
    else:
        print("no model runs recorded")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="stockpile_model")
    sub = p.add_subparsers(dest="cmd", required=True)
    pi = sub.add_parser("ingest", help="import FMS CSV / survey DXF files from a zip or folder")
    pi.add_argument("source")
    pi.add_argument("--config", default=None)
    pi.set_defaults(func=cmd_ingest)
    pr = sub.add_parser("run", help="run the pipeline")
    pr.add_argument("--config", default=None)
    pr.add_argument("--out", default="outputs")
    pr.add_argument("--stages", default=None, help=f"comma list from {STAGES}")
    pr.add_argument("--mc", type=int, default=None, help="override number of Monte-Carlo realisations")
    pr.set_defaults(func=cmd_run)
    pp = sub.add_parser("report", help="fill docs/engineering_report.md from the latest run outputs")
    pp.add_argument("--out", default="outputs")
    pp.set_defaults(func=cmd_report)
    ps = sub.add_parser("status", help="show ingested data and recent model runs")
    ps.add_argument("--config", default=None)
    ps.add_argument("--out", default="outputs")
    ps.set_defaults(func=cmd_status)
    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
