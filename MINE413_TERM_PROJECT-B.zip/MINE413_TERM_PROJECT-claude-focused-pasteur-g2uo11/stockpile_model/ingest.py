"""Import new FMS exports and survey files into the managed raw-data store.

``data/raw/fms/*.csv`` and ``data/raw/surveys/*.dxf`` are the only inputs the
pipeline reads. Files are copied unmodified; every import is logged in
``data/raw/ingest_log.csv`` with its SHA-256 so that any later model run can be
traced to the exact bytes it used. Re-importing an identical file is a no-op;
importing a *different* file under an existing name is refused (the original
is never silently overwritten).
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import shutil
import zipfile
from pathlib import Path

import pandas as pd

LOG_COLUMNS = ["ingested_utc", "kind", "stored_as", "original_name", "source", "sha256", "bytes", "status"]


def _kind(name: str) -> str | None:
    low = name.lower()
    if low.endswith(".dxf"):
        return "surveys"
    if low.endswith(".csv"):
        return "fms"
    return None


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _iter_source(source: Path):
    """Yield (original_name, bytes) for every DXF/CSV in a zip or directory."""
    if source.is_file() and zipfile.is_zipfile(source):
        with zipfile.ZipFile(source) as zf:
            for info in zf.infolist():
                name = Path(info.filename).name
                if info.is_dir() or name.startswith(".") or _kind(name) is None:
                    continue
                yield name, zf.read(info)
    elif source.is_dir():
        for p in sorted(source.rglob("*")):
            if p.is_file() and _kind(p.name) is not None and not p.name.startswith("."):
                yield p.name, p.read_bytes()
    elif source.is_file() and _kind(source.name):
        yield source.name, source.read_bytes()
    else:
        raise FileNotFoundError(f"cannot ingest {source}")


def ingest(source: str | Path, raw_dir: str | Path) -> pd.DataFrame:
    source, raw_dir = Path(source), Path(raw_dir)
    log_path = raw_dir / "ingest_log.csv"
    log = pd.read_csv(log_path) if log_path.exists() else pd.DataFrame(columns=LOG_COLUMNS)
    rows = []
    now = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
    for name, data in _iter_source(source):
        kind = _kind(name)
        stored = name.replace(" ", "_")
        dest = raw_dir / kind / stored
        sha = _sha(data)
        if dest.exists():
            status = "unchanged" if _sha(dest.read_bytes()) == sha else "REFUSED_conflict"
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            status = "added"
        rows.append(dict(ingested_utc=now, kind=kind, stored_as=f"{kind}/{stored}", original_name=name,
                         source=str(source), sha256=sha, bytes=len(data), status=status))
    new = pd.DataFrame(rows, columns=LOG_COLUMNS)
    raw_dir.mkdir(parents=True, exist_ok=True)
    pd.concat([log, new], ignore_index=True).to_csv(log_path, index=False)
    return new


def copy_tree(src: Path, dst: Path) -> None:
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
