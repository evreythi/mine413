"""Temporal alignment of FMS dump records with survey intervals.

Survey ``k`` closes interval ``k``: (cutoff[k-1], cutoff[k]]. The cutoff of a
survey labelled day D is D 00:00 + ``survey_cutoff_hours`` (A-003). The first
interval has no preceding survey; it is assumed to span
``first_interval_hours`` before the first cutoff (A-011).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

AFTER_LAST = -1
BEFORE_FIRST = -2


def survey_cutoffs(dates, cutoff_hours: float) -> pd.DatetimeIndex:
    d = pd.DatetimeIndex(pd.to_datetime(dates)).normalize()
    if not d.is_monotonic_increasing or d.has_duplicates:
        raise ValueError("survey dates must be strictly increasing")
    return d + pd.to_timedelta(cutoff_hours, unit="h")


def assign_intervals(times, cutoffs: pd.DatetimeIndex, first_interval_hours: float) -> np.ndarray:
    """Return the interval index for each time.

    ``AFTER_LAST`` (-1) for records after the last cutoff (not yet surveyed),
    ``BEFORE_FIRST`` (-2) for records before the first interval opens, and -3
    for missing timestamps.
    """
    t = pd.DatetimeIndex(pd.to_datetime(times))
    start = cutoffs[0] - pd.to_timedelta(first_interval_hours, unit="h")
    idx = np.searchsorted(cutoffs.values, t.values, side="left")
    out = idx.astype(int)
    out[idx >= len(cutoffs)] = AFTER_LAST
    out[t.values <= start.to_datetime64()] = BEFORE_FIRST
    out[pd.isna(t)] = -3
    return out


def interval_table(survey_names, cutoffs: pd.DatetimeIndex, first_interval_hours: float) -> pd.DataFrame:
    start = [cutoffs[0] - pd.to_timedelta(first_interval_hours, unit="h")] + list(cutoffs[:-1])
    df = pd.DataFrame({
        "interval": np.arange(len(cutoffs)),
        "survey": list(survey_names),
        "start": pd.DatetimeIndex(start),
        "end": cutoffs,
    })
    df["duration_h"] = (df["end"] - df["start"]).dt.total_seconds() / 3600.0
    return df
