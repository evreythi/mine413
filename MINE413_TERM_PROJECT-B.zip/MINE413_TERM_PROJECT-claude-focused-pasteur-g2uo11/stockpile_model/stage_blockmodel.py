"""Stage 4 - block model construction, inventories and exports."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import blockmodel as B
from . import plots
from .pipeline import Inputs, write_json
from .plots import plt

EXPORT_COLUMNS = [
    "ix", "iy", "iz", "xc", "yc", "zc", "volume_m3", "fill_fraction", "tonnes", "density_t_m3",
    "cu_pct", "au_gpt", "ag_gpt", "cu_t", "au_g", "au_oz", "ag_g",
    "cu_t_recorded", "cu_t_assumed", "au_g_recorded", "au_g_assumed",
    "tonnes_recorded", "tonnes_unrecorded", "tonnes_premodel", "tonnes_location_unknown", "tonnes_rehandled",
    "frac_recorded", "frac_trusted", "frac_assumed_grade", "cu_mix_sd", "au_mix_sd", "travel_m", "mean_day",
    "confidence",
]
EVIDENCE = {  # evidence category of every exported attribute (Task 7 presentation requirement)
    "ix": "CALCULATED", "iy": "CALCULATED", "iz": "CALCULATED", "xc": "CALCULATED", "yc": "CALCULATED", "zc": "CALCULATED",
    "volume_m3": "MODEL-GENERATED (constrained to CALCULATED survey volume)", "fill_fraction": "MODEL-GENERATED",
    "tonnes": "MODEL-GENERATED (recorded tonnes MEASURED + UNK/PRE ASSUMED density)",
    "density_t_m3": "INFERRED (f_v calibration) / MODEL-GENERATED",
    "cu_pct": "MODEL-GENERATED from MEASURED source grades (+ ASSUMED UNK grade)",
    "au_gpt": "MODEL-GENERATED from MEASURED source grades (+ ASSUMED UNK grade)",
    "ag_gpt": "MODEL-GENERATED from MEASURED source grades (+ ASSUMED UNK grade)",
    "cu_t": "MODEL-GENERATED", "au_g": "MODEL-GENERATED", "au_oz": "MODEL-GENERATED", "ag_g": "MODEL-GENERATED",
    "cu_t_recorded": "MODEL-GENERATED placement of MEASURED metal", "au_g_recorded": "MODEL-GENERATED placement of MEASURED metal",
    "cu_t_assumed": "ASSUMED (A-023/A-024)", "au_g_assumed": "ASSUMED (A-023/A-024)",
    "tonnes_recorded": "MODEL-GENERATED placement of MEASURED tonnes", "tonnes_unrecorded": "INFERRED volume x ASSUMED density",
    "tonnes_premodel": "ASSUMED", "tonnes_location_unknown": "MODEL-GENERATED", "tonnes_rehandled": "MODEL-GENERATED",
    "frac_recorded": "MODEL-GENERATED indicator", "frac_trusted": "MODEL-GENERATED indicator",
    "frac_assumed_grade": "MODEL-GENERATED indicator", "cu_mix_sd": "MODEL-GENERATED indicator",
    "au_mix_sd": "MODEL-GENERATED indicator", "travel_m": "MODEL-GENERATED indicator", "mean_day": "MODEL-GENERATED",
    "confidence": "ASSUMED rule set (A-029) applied to indicators",
}
UNITS = {"volume_m3": "m3", "tonnes": "t", "density_t_m3": "t/m3", "cu_pct": "% (A-004)", "au_gpt": "g/t (A-004)",
         "ag_gpt": "g/t (A-004)", "cu_t": "t", "au_g": "g", "au_oz": "troy oz", "ag_g": "g", "travel_m": "m",
         "mean_day": "days since 2026-03-15 00:00", "xc": "m", "yc": "m", "zc": "m"}


def column_map(bm: pd.DataFrame, value: str, weight: str = "tonnes"):
    """Plan raster of a tonnage-weighted (or summed) attribute per block column."""
    nx, ny = bm.ix.max() + 1, bm.iy.max() + 1
    out = np.full((ny, nx), np.nan)
    if value in ("tonnes", "cu_t", "au_oz", "volume_m3"):
        s = bm.groupby(["iy", "ix"])[value].sum()
    else:
        s = bm.assign(_w=bm[value] * bm[weight]).groupby(["iy", "ix"]).apply(
            lambda d: d._w.sum() / d[weight].sum(), include_groups=False)
    out[s.index.get_level_values(0), s.index.get_level_values(1)] = s.values
    return out


def fig_plan_maps(bm, cfg_bm, x0, y0, path):
    dx, dy = cfg_bm["dx"], cfg_bm["dy"]
    nx, ny = bm.ix.max() + 1, bm.iy.max() + 1
    ext = (x0, x0 + nx * dx, y0, y0 + ny * dy)
    fig, axs = plt.subplots(2, 2, figsize=(15, 12), constrained_layout=True)
    specs = [("tonnes", "Tonnes per 2 × 2 m column", plots.SEQ),
             ("cu_pct", "Tonnage-weighted Cu % (column)", plots.SEQ),
             ("au_gpt", "Tonnage-weighted Au g/t (column)", plots.SEQ_ORANGE),
             ("frac_trusted", "Share of tonnes from recorded, located loads", plots.SEQ)]
    for ax, (v, title, cmap) in zip(axs.flat, specs):
        im = ax.imshow(column_map(bm, v), origin="lower", extent=ext, cmap=cmap,
                       vmin=0 if v == "frac_trusted" else None, vmax=1 if v == "frac_trusted" else None)
        fig.colorbar(im, ax=ax, shrink=0.8)
        ax.set_title(title + " (MODEL-GENERATED)", loc="left")
        ax.set_aspect("equal")
        ax.ticklabel_format(useOffset=False, style="plain")
        ax.set_xlabel("Easting X (m)")
        ax.set_ylabel("Northing Y (m)")
        ax.grid(False)
    fig.savefig(path)
    plt.close(fig)


def fig_benches(bm, cfg_bm, x0, y0, path, value="cu_pct"):
    dx, dy = cfg_bm["dx"], cfg_bm["dy"]
    nx, ny = bm.ix.max() + 1, bm.iy.max() + 1
    ext = (x0, x0 + nx * dx, y0, y0 + ny * dy)
    levels = sorted(bm.zc.unique())
    pick = [levels[int(i)] for i in np.linspace(1, len(levels) - 2, 6)]
    vmin, vmax = np.nanpercentile(bm[value], [2, 98])
    fig, axs = plt.subplots(2, 3, figsize=(18, 11), constrained_layout=True)
    for ax, z in zip(axs.flat, pick):
        d = bm[bm.zc == z]
        img = np.full((ny, nx), np.nan)
        img[d.iy, d.ix] = d[value]
        im = ax.imshow(img, origin="lower", extent=ext, cmap=plots.SEQ, vmin=vmin, vmax=vmax)
        low = d[d.confidence == "LOW"]
        ax.scatter(low.xc, low.yc, s=2, c=plots.INK2, marker=".", label="LOW confidence")
        ax.set_title(f"Bench {z - 0.5:.0f}–{z + 0.5:.0f} m: {value} ({len(d)} blocks)", loc="left")
        ax.set_aspect("equal")
        ax.ticklabel_format(useOffset=False, style="plain")
        ax.grid(False)
    axs.flat[0].legend(loc="lower left")
    fig.colorbar(im, ax=axs, shrink=0.6).set_label(f"{value} (MODEL-GENERATED)")
    fig.savefig(path)
    plt.close(fig)


def fig_sections(bm, path, ys=(7122335.0,), xs=(511349.0,)):
    fig, axs = plt.subplots(2, 2, figsize=(16, 8), constrained_layout=True)
    conf_code = bm.confidence.map({"LOW": 0, "MEDIUM": 1, "HIGH": 2})
    for row, (axis, coord) in enumerate((("y", ys[0]), ("x", xs[0]))):
        d = bm[(bm.yc - coord).abs() < 1.0] if axis == "y" else bm[(bm.xc - coord).abs() < 1.0]
        h = d.xc if axis == "y" else d.yc
        for col, (v, cmap) in enumerate((("cu_pct", plots.SEQ), ("confidence", None))):
            ax = axs[row, col]
            if v == "confidence":
                colors = np.array([plots.STATUS["critical"], plots.STATUS["warning"], plots.STATUS["good"]])
                c = colors[conf_code[d.index].values]
                ax.scatter(h, d.zc, c=c, marker="s", s=28)
                for lab, cc in zip(["LOW", "MEDIUM", "HIGH"], colors):
                    ax.scatter([], [], c=cc, marker="s", label=lab)
                ax.legend(loc="upper right", title="confidence (A-029)")
            else:
                sc = ax.scatter(h, d.zc, c=d[v], cmap=cmap, marker="s", s=28)
                fig.colorbar(sc, ax=ax, shrink=0.8).set_label("Cu %")
            ax.set_xlabel("Easting X (m)" if axis == "y" else "Northing Y (m)")
            ax.set_ylabel("Elevation (m)")
            ax.ticklabel_format(useOffset=False, style="plain")
            ax.set_title(f"Block section {'Y' if axis == 'y' else 'X'} = {coord:,.0f} m: {v}", loc="left")
    fig.savefig(path)
    plt.close(fig)


def fig_grade_tonnage(gt_all, gt_rec, path):
    fig, axs = plt.subplots(1, 2, figsize=(13, 4.5), constrained_layout=True)
    axs[0].plot(gt_all.cutoff, gt_all.tonnes / 1000, marker="o", label="All material")
    axs[0].plot(gt_rec.cutoff, gt_rec.tonnes / 1000, marker="s", label="Blocks ≥ 90 % recorded")
    axs[0].set_xlabel("Block Cu cut-off (%)")
    axs[0].set_ylabel("Tonnes above cut-off (kt)")
    axs[0].set_title("Grade–tonnage: tonnes", loc="left")
    axs[0].legend()
    axs[1].plot(gt_all.cutoff, gt_all.cu_pct, marker="o", label="All material")
    axs[1].plot(gt_rec.cutoff, gt_rec.cu_pct, marker="s", label="Blocks ≥ 90 % recorded")
    axs[1].set_xlabel("Block Cu cut-off (%)")
    axs[1].set_ylabel("Mean Cu above cut-off (%)")
    axs[1].set_title("Grade–tonnage: grade", loc="left")
    axs[1].legend()
    fig.savefig(path)
    plt.close(fig)


def run(inp: Inputs, cfg: dict, out_dir: Path, movement: dict, growth: dict, flagged: pd.DataFrame) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    M = movement["M"]
    cb = cfg["blockmodel"]
    bm = B.build_block_model(M["layers"], M["geometry"].grid, cb)
    chk = B.check_totals(bm, M["layers"])
    g = M["geometry"].grid

    bm[EXPORT_COLUMNS].to_csv(out_dir / "block_model.csv", index=False, float_format="%.6g")
    # mine-software style export (centroid + increments)
    mine = bm[["xc", "yc", "zc"]].rename(columns={"xc": "XC", "yc": "YC", "zc": "ZC"})
    mine["XINC"], mine["YINC"], mine["ZINC"] = cb["dx"], cb["dy"], cb["dz"]
    for c in ["tonnes", "density_t_m3", "cu_pct", "au_gpt", "ag_gpt", "fill_fraction", "confidence"]:
        mine[c.upper()] = bm[c]
    mine.to_csv(out_dir / "block_model_minesoftware.csv", index=False, float_format="%.6g")
    pd.DataFrame([dict(attribute=c, units=UNITS.get(c, "-"), evidence=EVIDENCE[c]) for c in EXPORT_COLUMNS]).to_csv(
        out_dir / "block_model_dictionary.csv", index=False)
    B.write_vtk(bm, out_dir / "block_model.vtk", cb["dx"], cb["dy"], cb["dz"], g.x_min, g.y_min, cb["z0"],
                ["tonnes", "density_t_m3", "cu_pct", "au_gpt", "fill_fraction", "frac_trusted", "travel_m"])

    inv_total = B.inventory(bm)
    inv_conf = B.inventory(bm, "confidence")
    inv_bench = B.inventory(bm, "zc")
    gt_all = B.grade_tonnage(bm, "cu_pct", cb["cutoffs_cu_pct"])
    gt_rec = B.grade_tonnage(bm[bm.frac_recorded >= 0.9], "cu_pct", cb["cutoffs_cu_pct"])
    inv_total.to_csv(out_dir / "inventory_total.csv")
    inv_conf.to_csv(out_dir / "inventory_by_confidence.csv")
    inv_bench.to_csv(out_dir / "inventory_by_bench.csv")
    gt_all.to_csv(out_dir / "grade_tonnage_cu.csv", index=False)

    fig_plan_maps(bm, cb, g.x_min, g.y_min, out_dir / "fig_block_plan_maps.png")
    fig_benches(bm, cb, g.x_min, g.y_min, out_dir / "fig_block_benches_cu.png")
    fig_sections(bm, out_dir / "fig_block_sections.png")
    fig_grade_tonnage(gt_all, gt_rec, out_dir / "fig_grade_tonnage.png")

    pending = flagged[flagged.qa_TIME_AFTER_LAST_SURVEY]
    unplaced = growth["reconciliation"].unplaced
    unplaced.to_csv(out_dir / "unplaced_recorded_material.csv", index=False)
    t = inv_total.iloc[0]
    summary = dict(
        n_blocks=int(len(bm)), block_size=[cb["dx"], cb["dy"], cb["dz"]], integration_errors=chk,
        tonnes=float(t.tonnes), cu_pct=float(t.cu_pct), au_gpt=float(t.au_gpt), cu_t=float(t.cu_t),
        cu_t_recorded=float(t.cu_t_recorded), cu_t_assumed=float(t.cu_t_assumed), au_oz=float(t.au_oz),
        tonnes_by_confidence=bm.groupby("confidence").tonnes.sum().round(1).to_dict(),
        pending_after_last_survey_t=float(pending.payload_t.sum()),
        unplaced_recorded_t=float(unplaced.tonnes.sum()),
        domain_note="Material placed 15 Mar 07:00 - 30 Mar 07:00 within surveyed fill solids; pre-existing stockpile below the pre-model surface is not modelled (no data).",
    )
    write_json(out_dir / "blockmodel_summary.json", summary)
    return dict(bm=bm, summary=summary)
