"""Quantitative comparison of predicted and observed volume distributions.

Metrics (all on plan thickness rasters, volumes in m3):

* ``overlap``  = sum(min(pred, obs)) / sum(obs)            (1 = identical)
* ``centroid_m`` = distance between volume-weighted centroids
* ``emd_m``    = Earth mover's (Wasserstein-1) distance: the mean distance
  (m) that predicted volume must be moved to become the observed
  distribution. Computed exactly by linear programming after aggregating to
  coarse cells (``emd_cell`` m). Lower is better; it directly measures how
  well material *location* is predicted.

``pred`` is rescaled to the observed total before comparison so that the
metrics measure location skill only (totals are tested separately).
"""

from __future__ import annotations

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from .io_survey import GridSpec


def coarsen(a: np.ndarray, factor: int) -> np.ndarray:
    ny, nx = a.shape
    ny2, nx2 = ny // factor, nx // factor
    return a[:ny2 * factor, :nx2 * factor].reshape(ny2, factor, nx2, factor).sum(axis=(1, 3))


def emd(pred_v: np.ndarray, obs_v: np.ndarray, grid: GridSpec, emd_cell: float = 2.0) -> float:
    """Exact W1 distance between two non-negative volume rasters (equal totals)."""
    f = max(int(round(emd_cell / grid.cell)), 1)
    P, O = coarsen(pred_v, f), coarsen(obs_v, f)
    cs = grid.cell * f
    ip, io = np.nonzero(P > 1e-9 * P.sum()), np.nonzero(O > 1e-9 * O.sum())
    a, b = P[ip], O[io]
    a = a / a.sum()
    b = b / b.sum()
    xp = np.c_[ip[1], ip[0]] * cs
    xo = np.c_[io[1], io[0]] * cs
    C = np.hypot(xp[:, None, 0] - xo[None, :, 0], xp[:, None, 1] - xo[None, :, 1])
    n, m = len(a), len(b)
    rows = np.r_[np.repeat(np.arange(n), m), n + np.tile(np.arange(m), n)]
    cols = np.r_[np.arange(n * m), np.arange(n * m)]
    A = coo_matrix((np.ones(2 * n * m), (rows, cols)), shape=(n + m, n * m)).tocsr()
    res = linprog(C.ravel(), A_eq=A, b_eq=np.r_[a, b], bounds=(0, None), method="highs")
    if not res.success:
        raise RuntimeError(f"EMD LP failed: {res.message}")
    return float(res.fun)


def compare(pred_h: np.ndarray, obs_h: np.ndarray, grid: GridSpec, emd_cell: float = 4.0) -> dict:
    a = grid.cell_area
    obs = np.clip(np.nan_to_num(obs_h), 0, None) * a
    pred = np.clip(np.nan_to_num(pred_h), 0, None) * a
    if pred.sum() <= 0 or obs.sum() <= 0:
        return dict(overlap=np.nan, centroid_m=np.nan, emd_m=np.nan)
    pred = pred * (obs.sum() / pred.sum())
    Y, X = np.mgrid[0:grid.ny, 0:grid.nx]
    cp = np.array([(X * pred).sum(), (Y * pred).sum()]) / pred.sum()
    co = np.array([(X * obs).sum(), (Y * obs).sum()]) / obs.sum()
    return dict(
        overlap=float(np.minimum(pred, obs).sum() / obs.sum()),
        centroid_m=float(np.hypot(*(cp - co)) * grid.cell),
        emd_m=emd(pred, obs, grid, emd_cell),
    )
