"""Sensitivity (one-at-a-time) and Monte-Carlo uncertainty analysis (Task 7).

``run_core`` re-runs reconciliation -> movement -> block model for a given
configuration and (optionally perturbed) load table. Survey geometry and the
growth history are fixed inputs (their error is treated through the survey
tolerance and f_v, A-016/A-014).

Monte-Carlo random errors per realisation (A-008, A-030, A-031, A-014):

* payload:  T_i + U(-q/2, q/2), q = 38 t loading-pass quantum
* grades:   per source group, Cu/Au/Ag x lognormal(0, sigma_grade) (correlated
            within a source because grades are source attributes, A-007)
* position: x_i, y_i + N(0, sigma_gps) for trusted-location loads
* f_v:      bootstrap of the robust calibration over consistent intervals
"""

from __future__ import annotations

import copy

import numpy as np
import pandas as pd

from . import blockmodel as B
from .config import set_by_path
from .movement import run_movement
from .reconcile import reconcile, robust_volume_factor


def bootstrap_f_v(net_table: pd.DataFrame, k_mad: float, n: int, rng) -> np.ndarray:
    cal = robust_volume_factor(net_table, k_mad)
    used = net_table[net_table.interval.isin(cal["used_intervals"])]
    out = np.empty(n)
    for i in range(n):
        s = used.sample(len(used), replace=True, random_state=rng.integers(1 << 31))
        out[i] = s.net_m3.sum() / s.vdens_m3.sum()
    return out


def run_core(inp, hist, net_table, loads, cfg, f_v=None, carry_over=True):
    rc = cfg["reconcile"]
    if f_v is None:
        f_v = robust_volume_factor(net_table, rc["outlier_k_mad"])["f_v"] if rc["f_v"] == "auto" else float(rc["f_v"])
    rec = reconcile(loads, net_table, f_v, rc["sigma_z_m"], carry_over=carry_over)
    M = run_movement(inp, hist, rec, loads, cfg)
    bm = B.build_block_model(M["layers"], M["geometry"].grid, cfg["blockmodel"])
    return rec, M, bm


def summarise(bm: pd.DataFrame, rec, base_bm: pd.DataFrame | None = None, loads: pd.DataFrame | None = None) -> dict:
    """Inventory totals = spatially located material (block model) + recorded material
    that the reconciliation could not place in any surveyed fill ('unplaced', e.g. still
    on the unsurveyed pad top). Unplaced material is part of the stockpile but has no
    block location; it is reported separately and included in the totals."""
    up = rec.unplaced.merge(loads[["record_id", "cu", "au"]], on="record_id") if (loads is not None and len(rec.unplaced)) else None
    up_t = float(rec.unplaced.tonnes.sum())
    up_cu = float((up.tonnes * up.cu / 100).sum()) if up is not None else 0.0
    up_au = float((up.tonnes * up.au).sum()) if up is not None else 0.0
    t = bm.tonnes.sum() + up_t
    cu_t = bm.cu_t.sum() + up_cu
    au_g = bm.au_g.sum() + up_au
    out = dict(tonnes=t, cu_pct=100 * cu_t / t, au_gpt=au_g / t, cu_t=cu_t,
               cu_t_recorded=bm.cu_t_recorded.sum() + up_cu, au_oz=au_g / B.TROY_OZ_G,
               tonnes_located=bm.tonnes.sum(), tonnes_unrecorded=bm.tonnes_unrecorded.sum(), unplaced_t=up_t,
               unplaced_cu_t=up_cu,
               tonnes_high=bm.loc[bm.confidence == "HIGH", "tonnes"].sum(),
               tonnes_low=bm.loc[bm.confidence == "LOW", "tonnes"].sum(),
               f_v=rec.f_v)
    if base_bm is not None:
        a = base_bm.set_index(["ix", "iy", "iz"])
        b = bm.set_index(["ix", "iy", "iz"])
        j = a.join(b, how="inner", lsuffix="_a", rsuffix="_b")
        w = j.tonnes_a
        out["block_cu_mad_vs_base"] = float((np.abs(j.cu_pct_b - j.cu_pct_a) * w).sum() / w.sum())
        out["block_au_mad_vs_base"] = float((np.abs(j.au_gpt_b - j.au_gpt_a) * w).sum() / w.sum())
        out["block_tonnes_rel_mad_vs_base"] = float(np.abs(j.tonnes_b - j.tonnes_a).sum() / w.sum())
    return out


def oat_cases(cfg) -> list[dict]:
    """One-at-a-time cases: (name, assumption id, low/high settings)."""
    u = cfg["uncertainty"]
    cases = []
    for item in u["oat"]:
        for label, val in (("low", item["low"]), ("high", item["high"])):
            cases.append(dict(param=item["param"], assumption=item["assumption"], level=label, value=val))
    return cases


def apply_case(cfg, case):
    """Return (cfg', options) for an OAT case."""
    p, v = case["param"], case["value"]
    opts = {}
    if p == "reconcile.f_v":
        return set_by_path(cfg, "reconcile.f_v", v), opts
    if p == "reconcile.carry_over":
        opts["carry_over"] = bool(v)
        return cfg, opts
    if p == "unk_grade":
        opts["unk_grade"] = v
        return cfg, opts
    return set_by_path(cfg, p, v), opts


def unk_grade_bound(bm: pd.DataFrame, loads: pd.DataFrame, which: str) -> dict:
    """Recompute block grades with UNK/PRE material at the min or max source grade."""
    g = dict(cu=loads.cu.min() if which == "min" else loads.cu.max(),
             au=loads.au.min() if which == "min" else loads.au.max())
    m_asm = bm.tonnes_unrecorded + bm.tonnes_premodel
    cu_t = bm.cu_t_recorded + m_asm * g["cu"] / 100
    au_g = bm.au_g_recorded + m_asm * g["au"]
    t = bm.tonnes.sum()
    return dict(cu_t=cu_t.sum(), cu_pct=100 * cu_t.sum() / t, au_oz=au_g.sum() / B.TROY_OZ_G, au_gpt=au_g.sum() / t)


def perturb_loads(loads: pd.DataFrame, rng, ucfg) -> pd.DataFrame:
    L = loads.copy()
    q = ucfg["payload_quantum_t"]
    L["payload_t"] = np.clip(L.payload_t + rng.uniform(-q / 2, q / 2, len(L)), q / 2, None)
    groups = L.source_group.unique()
    s = ucfg["sigma_grade_log"]
    fac = {gk: np.exp(rng.normal(-0.5 * s * s, s, 3)) for gk in groups}
    L["cu"] = L.cu * L.source_group.map(lambda gk: fac[gk][0])
    L["au"] = L.au * L.source_group.map(lambda gk: fac[gk][1])
    L["ag"] = L.ag * L.source_group.map(lambda gk: fac[gk][2])
    tr = L.use_location
    L.loc[tr, "x"] = L.loc[tr, "x"] + rng.normal(0, ucfg["sigma_gps_m"], tr.sum())
    L.loc[tr, "y"] = L.loc[tr, "y"] + rng.normal(0, ucfg["sigma_gps_m"], tr.sum())
    return L


class BlockAccumulator:
    """Running per-block sums of x and x^2 over realisations (keyed by ix, iy, iz)."""

    def __init__(self, fields):
        self.fields = fields
        self.n = 0
        self.s = None
        self.s2 = None
        self.cnt = None
        self.samples = {f: [] for f in fields}

    def add(self, bm: pd.DataFrame):
        d = bm.set_index(["ix", "iy", "iz"])[self.fields]
        if self.s is None:
            self.s, self.s2 = d * 0.0, d * 0.0
            self.cnt = pd.Series(0, index=d.index)
        self.s = self.s.add(d, fill_value=0.0)
        self.s2 = self.s2.add(d ** 2, fill_value=0.0)
        self.cnt = self.cnt.add(pd.Series(1, index=d.index), fill_value=0)
        for f in self.fields:
            self.samples[f].append(d[f])
        self.n += 1

    def result(self) -> pd.DataFrame:
        mean = self.s.div(self.cnt, axis=0)
        var = (self.s2.div(self.cnt, axis=0) - mean ** 2).clip(lower=0)
        out = mean.add_suffix("_mean").join(np.sqrt(var).add_suffix("_sd"))
        for f in self.fields:
            S = pd.concat(self.samples[f], axis=1)
            out[f + "_p10"] = S.quantile(0.10, axis=1)
            out[f + "_p90"] = S.quantile(0.90, axis=1)
        out["n_realisations"] = self.cnt
        return out.reset_index()


def monte_carlo(inp, hist, net_table, loads, cfg, n: int, seed: int, progress=None):
    ucfg = cfg["uncertainty"]
    rng = np.random.default_rng(seed)
    fvs = bootstrap_f_v(net_table, cfg["reconcile"]["outlier_k_mad"], n, rng)
    acc = BlockAccumulator(["tonnes", "cu_pct", "au_gpt"])
    rows = []
    for i in range(n):
        L = perturb_loads(loads, rng, ucfg)
        rec, M, bm = run_core(inp, hist, net_table, L, cfg, f_v=float(fvs[i]))
        acc.add(bm)
        rows.append(dict(realisation=i, **summarise(bm, rec, loads=L)))
        if progress:
            progress(i)
    return pd.DataFrame(rows), acc.result()
