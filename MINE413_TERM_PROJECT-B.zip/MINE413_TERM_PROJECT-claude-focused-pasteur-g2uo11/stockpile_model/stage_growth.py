"""Stage 2 - stockpile growth characterisation and tonnage/volume reconciliation."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import plots
from .growth import exact_tin_volume, repose_estimate, slope_statistics, track, volume_at_resolution
from .pipeline import Inputs, write_json
from .plots import plt
from .reconcile import mass_check, reconcile, robust_volume_factor


def resolve_f_v(cfg, net_table) -> tuple[float, dict]:
    rc = cfg["reconcile"]
    cal = robust_volume_factor(net_table, rc["outlier_k_mad"])
    early = robust_volume_factor(net_table[net_table.interval <= net_table.interval.median()], rc["outlier_k_mad"])
    cal["f_v_first_half_only"] = early["f_v"]
    f = cal["f_v"] if rc["f_v"] == "auto" else float(rc["f_v"])
    cal["f_v_used"] = f
    cal["mode"] = "auto (robust pooled ratio)" if rc["f_v"] == "auto" else "fixed by config"
    return f, cal


def net_table(inp: Inputs, loads: pd.DataFrame, hist) -> pd.DataFrame:
    t = hist.table[["interval", "survey", "fill_m3", "revealed_cut_m3", "revealed_missing_fill_m3",
                    "net_m3", "footprint_m2"]].copy()
    vd = loads.assign(vd=loads.payload_t / loads.dens).groupby("interval")["vd"].sum()
    t["vdens_m3"] = t["interval"].map(vd).fillna(0.0)
    t["fms_t"] = t["interval"].map(loads.groupby("interval")["payload_t"].sum()).fillna(0.0)
    return t


def holdout_check(nt: pd.DataFrame, k_mad: float) -> pd.DataFrame:
    """Calibrate f_v on the first half of intervals, predict the second half."""
    split = nt.interval.median()
    cal = robust_volume_factor(nt[nt.interval <= split], k_mad)
    full = robust_volume_factor(nt, k_mad)
    out = nt[["interval", "survey", "net_m3", "vdens_m3", "fms_t"]].copy()
    out["role"] = np.where(out.interval <= split, "calibration", "held-out")
    out["consistent_interval"] = out.interval.isin(full["used_intervals"])
    out["f_v_calibrated"] = cal["f_v"]
    out["pred_net_m3"] = cal["f_v"] * out["vdens_m3"]
    out["rel_error"] = (out["net_m3"] - out["pred_net_m3"]) / out["net_m3"]
    # alternative model: constant density (ignores Dens column)
    c = nt[nt.interval.isin(cal["used_intervals"])]
    k_const = c.net_m3.sum() / c.fms_t.sum()
    out["pred_const_density_m3"] = k_const * out["fms_t"]
    out["rel_error_const_density"] = (out["net_m3"] - out["pred_const_density_m3"]) / out["net_m3"]
    return out


# --------------------------------------------------------------------- figures
def fig_cumulative(nt, rec, path):
    I = rec.intervals.merge(nt[["interval", "survey"]], on="interval")
    x = np.arange(len(I))
    fig, axs = plt.subplots(1, 2, figsize=(14, 4.6), constrained_layout=True)
    a = axs[0]
    a.plot(x, np.cumsum(I.net_m3), marker="o", label="Surveyed net volume (CALCULATED)")
    a.plot(x, np.cumsum(nt.vdens_m3 * rec.f_v), marker="s", label=f"FMS volume at f_v = {rec.f_v:.3f} (CALCULATED)")
    a.plot(x, np.cumsum(I.placed_fms_m3), marker="^", label="FMS material placed in surveyed fill (MODEL)")
    a.set_xticks(x, I.survey.str.replace("Topo_", ""), rotation=45)
    a.set_ylabel("Cumulative volume (m³)")
    a.set_title("Cumulative placement curves", loc="left")
    a.legend(loc="upper left")
    b = axs[1]
    w = 0.38
    b.bar(x - w / 2, I.net_m3, width=w, color=plots.SERIES[0], label="Surveyed net volume")
    b.bar(x + w / 2, I.placed_fms_m3, width=w, color=plots.SERIES[2], label="Placed FMS material")
    b.bar(x + w / 2, I.unk_m3, width=w, bottom=I.placed_fms_m3, color=plots.SERIES[1], label="Unrecorded material (UNK)")
    b.plot(x, I.buffer_after_m3, color=plots.INK2, marker="o", ms=4, lw=1.2, label="Pad buffer after survey")
    b.set_xticks(x, I.survey.str.replace("Topo_", ""), rotation=45)
    b.set_ylim(0, float(max(I.net_m3.max(), (I.placed_fms_m3 + I.unk_m3).max())) * 1.18)
    b.set_ylabel("Volume per interval (m³)")
    b.set_title("Per-interval reconciliation (stock-flow model, A-014-A-017)", loc="left")
    b.legend(loc="upper right")
    fig.savefig(path)
    plt.close(fig)


def fig_ratio(nt, cal, path):
    r = nt.net_m3 / nt.vdens_m3
    fig, ax = plt.subplots(figsize=(9, 4))
    used = nt.interval.isin(cal["used_intervals"])
    ax.scatter(nt.interval[used], r[used], s=60, color=plots.SERIES[0], label="used for calibration", zorder=3)
    ax.scatter(nt.interval[~used], r[~used], s=60, marker="D", color=plots.SERIES[1], label="outlier: probable FMS gap", zorder=3)
    ax.axhline(cal["f_v_used"], color=plots.INK2, lw=1.2)
    ax.axhspan(cal["median_ratio"] - 3 * cal["robust_sd"], cal["median_ratio"] + 3 * cal["robust_sd"], color=plots.GRID, alpha=0.6, lw=0)
    ax.text(7.2, cal["f_v_used"] - 0.06, f"adopted f_v = {cal['f_v_used']:.3f}", va="center", color=plots.INK2, fontsize=8)
    for k, s, v in zip(nt.interval, nt.survey, r):
        ax.annotate(s.replace("Topo_", ""), (k, v), textcoords="offset points", xytext=(0, 7), ha="center", fontsize=7, color=plots.MUTED)
    ax.set_xlabel("Interval")
    ax.set_ylabel("Net surveyed volume ÷ Σ(t / Dens)")
    ax.set_title("Volume-conversion ratio per interval (band = median ± 3 robust SD)", loc="left")
    ax.legend(loc="upper center")
    fig.savefig(path)
    plt.close(fig)


def fig_maps(inp, hist, path):
    g = inp.grid
    cut = np.sum(hist.cut, axis=0)
    miss = np.sum(hist.missfill, axis=0)
    total = np.where(np.isfinite(hist.z_pre), hist.z_final - hist.z_pre, np.nan)
    fig, axs = plt.subplots(1, 3, figsize=(18, 5.6), constrained_layout=True)
    im0 = axs[0].imshow(total, origin="lower", extent=g.extent(), cmap=plots.SEQ, vmin=0)
    fig.colorbar(im0, ax=axs[0], shrink=0.75).set_label("Final surface − pre-model surface (m)")
    plots.plan_axes(axs[0], g, "Total thickness placed 15–30 Mar (all solids)")
    first = np.where(hist.first_cover >= 0, hist.first_cover, np.nan)
    im1 = axs[1].imshow(first, origin="lower", extent=g.extent(), cmap=plots.SEQ_ORANGE)
    fig.colorbar(im1, ax=axs[1], shrink=0.75).set_label("Interval of first coverage")
    plots.plan_axes(axs[1], g, "Face advance: interval in which each cell first filled")
    signed = np.where((cut > 0) | (miss > 0), miss - cut, np.nan)
    lim = max(np.nanmax(np.abs(signed)) if np.isfinite(signed).any() else 1, 0.5)
    im2 = axs[2].imshow(signed, origin="lower", extent=g.extent(), cmap=plots.DIV, vmin=-lim, vmax=lim)
    union = np.isfinite(hist.z_pre)
    axs[2].contour(g.xc, g.yc, union.astype(float), levels=[0.5], colors=[plots.AXIS], linewidths=0.7)
    fig.colorbar(im2, ax=axs[2], shrink=0.75).set_label("Revealed cut (−, blue) / missing fill (+, red) (m)")
    plots.plan_axes(axs[2], g, "Changes revealed between non-consecutive solids\n(cut streaks follow former crest lines)")
    fig.savefig(path)
    plt.close(fig)


def fig_slopes(slopes, rep, aor, path):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.hist(slopes, bins=np.arange(0, 66, 1), color=plots.SERIES[0], edgecolor=plots.SURFACE)
    ax.axvline(aor, color=plots.SERIES[1], lw=1.5)
    ax.text(aor + 0.8, ax.get_ylim()[1] * 0.92, f"adopted angle of repose {aor:.0f}°\n(mode of >25° = {rep['mode_deg']:.1f}°)", color=plots.INK2, fontsize=8)
    ax.set_xlabel("Surface slope of solid tops (°), cells thicker than 0.3 m")
    ax.set_ylabel("Cells (0.5 m)")
    ax.set_title("Surveyed face slopes, all 10 solids pooled", loc="left")
    fig.savefig(path)
    plt.close(fig)


def fig_fv_scan(scan, f_used, path):
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(scan.f_v, scan.unk_m3, marker="o", ms=4, label="Unrecorded material (UNK)")
    ax.plot(scan.f_v, scan.final_buffer_m3, marker="s", ms=4, label="FMS material never surveyed (end buffer)")
    ax.plot(scan.f_v, scan.max_buffer_m3, marker="^", ms=4, label="Peak pad buffer")
    ax.axvline(f_used, color=plots.MUTED, ls=":", lw=1)
    ax.set_xlabel("Volume-conversion factor f_v")
    ax.set_ylabel("Volume (m³)")
    ax.set_title("Trade-off between unrecorded material and carry-over as f_v varies", loc="left")
    ax.legend(loc="upper center")
    fig.savefig(path)
    plt.close(fig)


def run(inp: Inputs, cfg: dict, out_dir: Path, flagged: pd.DataFrame) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    gcfg, rcfg = cfg["growth"], cfg["reconcile"]
    hist = track(inp.rasters, gcfg["stacking_tol_m"])
    loads = flagged[flagged["use_in_model"]].copy()
    nt = net_table(inp, loads, hist)
    f_v, cal = resolve_f_v(cfg, nt)
    rec = reconcile(loads, nt, f_v, rcfg["sigma_z_m"])
    mc = mass_check(loads, rec)
    ho = holdout_check(nt, rcfg["outlier_k_mad"])

    lo, hi, step = rcfg["f_v_scan"]
    rows = []
    for f in np.arange(lo, hi + 1e-9, step):
        r = reconcile(loads, nt, float(f), rcfg["sigma_z_m"])
        rows.append(dict(f_v=round(float(f), 3), unk_m3=r.intervals.unk_m3.sum(),
                         final_buffer_m3=r.unplaced.volume_m3.sum(),
                         max_buffer_m3=r.intervals.buffer_after_m3.max(),
                         max_buffer_loads=int(r.intervals.n_buffer_loads.max())))
    scan = pd.DataFrame(rows)

    slope_tab, slopes = slope_statistics(inp.rasters, inp.grid.cell)
    rep = repose_estimate(slopes)

    res_rows = []
    for s, r in zip(inp.surveys, inp.rasters):
        res_rows.append(dict(survey=s.name, raster_0p5_m3=r.volume, exact_tin_m3=exact_tin_volume(s.triangles)))
    res = pd.DataFrame(res_rows)
    g = cfg["grid"]
    for c in gcfg.get("resolution_check_cells", []):
        res[f"raster_{str(c).replace('.', 'p')}_m3"] = volume_at_resolution(inp.surveys, c, (g["x_min"], g["x_max"], g["y_min"], g["y_max"]))
    for col in [c for c in res.columns if c.startswith("raster_")]:
        res[f"{col}_rel_to_exact"] = res[col] / res["exact_tin_m3"] - 1

    nt.merge(rec.intervals, on=["interval", "net_m3"]).to_csv(out_dir / "growth_budget_and_reconciliation.csv", index=False)
    rec.placements.to_csv(out_dir / "load_placement_schedule.csv", index=False)
    rec.unplaced.to_csv(out_dir / "unplaced_buffer_end.csv", index=False)
    ho.to_csv(out_dir / "volume_factor_holdout.csv", index=False)
    scan.to_csv(out_dir / "volume_factor_scan.csv", index=False)
    slope_tab.to_csv(out_dir / "face_slope_statistics.csv", index=False)
    res.to_csv(out_dir / "volume_resolution_check.csv", index=False)
    np.savez_compressed(out_dir / "growth_history.npz", z_pre=hist.z_pre, z_final=hist.z_final,
                        first_cover=hist.first_cover, last_cover=hist.last_cover,
                        cut=np.array(hist.cut), missfill=np.array(hist.missfill))

    fig_cumulative(nt, rec, out_dir / "fig_cumulative_and_interval_reconciliation.png")
    fig_ratio(nt, cal, out_dir / "fig_volume_ratio_by_interval.png")
    fig_maps(inp, hist, out_dir / "fig_growth_maps.png")
    fig_slopes(slopes, rep, cfg["physics"]["angle_of_repose_deg"], out_dir / "fig_face_slopes.png")
    fig_fv_scan(scan, f_v, out_dir / "fig_volume_factor_tradeoff.png")

    held = ho[(ho.role == "held-out") & ho.consistent_interval]
    I = rec.intervals
    summary = dict(
        fill_m3=float(nt.fill_m3.sum()), revealed_cut_m3=float(nt.revealed_cut_m3.sum()),
        revealed_missing_fill_m3=float(nt.revealed_missing_fill_m3.sum()), net_m3=float(nt.net_m3.sum()),
        calibration=cal, mass_check=mc,
        unk_m3=float(I.unk_m3.sum()), unk_intervals=I.loc[I.unk_m3 > 1, "interval"].tolist(),
        placed_fms_t=float(I.placed_fms_t.sum()), placed_fms_m3=float(I.placed_fms_m3.sum()),
        mean_placed_density_t_m3=float(I.placed_fms_t.sum() / I.placed_fms_m3.sum()),
        peak_buffer_m3=float(I.buffer_after_m3.max()), peak_buffer_loads=int(I.n_buffer_loads.max()),
        holdout_mean_abs_rel_error=float(held.rel_error.abs().mean()) if len(held) else None,
        holdout_mean_abs_rel_error_const_density=float(held.rel_error_const_density.abs().mean()) if len(held) else None,
        angle_of_repose=rep,
        max_raster_vs_exact_rel=float(res["raster_0p5_m3_rel_to_exact"].abs().max()),
        volume_by_cell_m3={c.replace('raster_', '').replace('_m3', '').replace('p', '.') + ' m': float(res[c].sum()) for c in res.columns if c.startswith('raster_') and c.endswith('_m3')} | {'exact': float(res['exact_tin_m3'].sum())},
    )
    write_json(out_dir / "growth_summary.json", summary)
    return dict(history=hist, net=nt, reconciliation=rec, calibration=cal, summary=summary, loads=loads)
