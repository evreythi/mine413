"""Fill the engineering-report template from the outputs of the latest run.

Keeping report numbers machine-filled prevents transcription errors and
stale figures after a model update (assignment reproducibility standard).
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

from .config import REPO_ROOT


def _j(path: Path) -> dict:
    return json.loads(path.read_text())


def tokens(out: Path) -> dict:
    man = _j(out / "run_manifest.json")
    bm = _j(out / "04_blockmodel" / "blockmodel_summary.json")
    gr = _j(out / "02_growth" / "growth_summary.json")
    mv = _j(out / "03_movement" / "movement_summary.json")
    un = _j(out / "05_uncertainty" / "uncertainty_summary.json")
    oat = pd.read_csv(out / "05_uncertainty" / "sensitivity_oat.csv")
    mc = pd.read_csv(out / "05_uncertainty" / "mc_totals.csv")
    bu = pd.read_csv(out / "05_uncertainty" / "block_uncertainty.csv")
    conf = pd.read_csv(out / "05_uncertainty" / "inventory_by_final_confidence.csv")
    val = pd.read_csv(out / "05_uncertainty" / "validation_metrics.csv")
    alt = un["alternative_scenario"]
    order = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
    conf = conf.sort_values("confidence_final", key=lambda s: s.map(order))
    conf_rows = "\n".join(f"| {r.confidence_final} | {r.tonnes:,.0f} | {r.cu_pct:.2f} | {r.cu_t:,.0f} |" for r in conf.itertuples())
    esc = lambda x: str(x).replace("|", "\\|")  # noqa: E731  (pipes inside markdown table cells)
    val_rows = "\n".join(f"| {esc(r.area)} | {esc(r.measure)} | {esc(r.result)} | {esc(r.evidence)} |" for r in val.itertuples())
    return {
        "RUN_ID": man["run_id"], "T_KT": f"{bm['tonnes'] / 1000:.1f}", "CU_PCT": f"{bm['cu_pct']:.2f}",
        "AU_GPT": f"{bm['au_gpt']:.2f}", "CU_T": f"{bm['cu_t']:,.0f}", "AU_OZ": f"{bm['au_oz']:,.0f}",
        "CU_ASM": f"{bm['cu_t_assumed']:,.0f}", "REC_SHARE": f"{100 * bm['cu_t_recorded'] / bm['cu_t']:.1f}",
        "ASM_SHARE": f"{100 * bm['cu_t_assumed'] / bm['cu_t']:.1f}", "PENDING_T": f"{bm['pending_after_last_survey_t']:,.0f}",
        "MC_N": str(len(mc)), "MC_CU_P10": f"{un['mc']['cu_t']['p10']:,.0f}", "MC_CU_P90": f"{un['mc']['cu_t']['p90']:,.0f}",
        "MC_AU_P10": f"{un['mc']['au_oz']['p10']:,.0f}", "MC_AU_P90": f"{un['mc']['au_oz']['p90']:,.0f}",
        "MC_T_P10": f"{un['mc']['tonnes']['p10'] / 1000:.1f}", "MC_T_P90": f"{un['mc']['tonnes']['p90'] / 1000:.1f}",
        "OAT_CU_MIN": f"{oat.cu_t.min():,.0f}", "OAT_CU_MAX": f"{oat.cu_t.max():,.0f}",
        "ALT_KT": f"{alt['tonnes_recorded'] / 1000:.1f}",
        "ALT_CU": f"{alt['cu_t_recorded']:,.0f}",
        "REC_KT": f"{alt['tonnes_recorded'] / alt['factor'] / 1000:.1f}", "REC_CU": f"{bm['cu_t_recorded']:,.0f}", "BLK_CU_SD": f"{bu.cu_pct_sd.median():.2f}",
        "FV": f"{gr['calibration']['f_v_used']:.3f}", "UNK_M3": f"{gr['unk_m3']:,.0f}",
        "EMD_PUSH": f"{mv['heldout_mean_emd_m']['push']:.1f}", "EMD_NOPUSH": f"{mv['heldout_mean_emd_m']['no_push']:.1f}",
        "EMD_UNI": f"{mv['heldout_mean_emd_m']['uniform_face']:.1f}",
        "HIGH_KT": f"{conf.set_index('confidence_final').tonnes.get('HIGH', 0) / 1000:.1f}",
        "CONF_TABLE": conf_rows, "VALIDATION_TABLE": val_rows,
    }


def build(out: Path | None = None, template: Path | None = None, dest: Path | None = None) -> Path:
    out = out or REPO_ROOT / "outputs"
    template = template or REPO_ROOT / "docs" / "engineering_report_template.md"
    dest = dest or REPO_ROOT / "docs" / "engineering_report.md"
    text = template.read_text()
    tk = tokens(out)
    text = re.sub(r"⟨([A-Z0-9_]+)⟩", lambda m: tk[m.group(1)], text)
    left = re.findall(r"⟨[A-Z0-9_]+⟩", text)
    if left:
        raise ValueError(f"unfilled tokens: {left}")
    dest.write_text(text)
    return dest
