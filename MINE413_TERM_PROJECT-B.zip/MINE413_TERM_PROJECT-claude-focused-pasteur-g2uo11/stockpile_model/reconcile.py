"""FMS tonnage <-> surveyed volume reconciliation (stock-flow model).

Notation for interval k:

* load i has recorded mass ``T_i`` (t) and source density ``Dens_i`` (t/m3);
  its in-pile volume is ``v_i = f_v * T_i / Dens_i`` where ``f_v`` is the
  volume-conversion (bulking) factor (A-014). In-pile bulk density of load i
  is therefore ``rho_i = Dens_i / f_v``.
* ``N_k`` = surveyed net volume placed in interval k (fill + revealed missing
  fill - revealed cut; ``growth.track``).
* ``B_{k-1}`` = pad buffer: loads dumped on the pile top but not yet pushed
  into a surveyed fill at the previous survey (A-015). It is consumed first
  (FIFO by dump time).

Supply ``S_k = B_{k-1} + sum_{i in k} v_i``.

* ``N_k <= S_k``  : volume N_k is supplied by the oldest material first; the
  remainder ``S_k - N_k`` stays in the buffer (partial loads allowed).
* ``N_k >  S_k``  : all supply is placed. The excess ``E_k = N_k - S_k`` is
  compared with the survey tolerance ``tau_k = sigma_z * footprint_k``
  (A-016): up to ``tau_k`` it is attributed to measurement error and absorbed
  by expanding the placed material's volume (density lowered locally); the
  rest is *unrecorded material* (UNK) with unknown grade (A-017).

Mass conservation: every recorded tonne is either placed exactly once or is
in the buffer at the end (reported as "unplaced, on unsurveyed pad top").
"""

from __future__ import annotations

import dataclasses

import numpy as np
import pandas as pd


@dataclasses.dataclass
class Reconciliation:
    placements: pd.DataFrame   # record_id, interval_placed, interval_dumped, frac, tonnes, volume_m3
    intervals: pd.DataFrame    # per-interval budget
    unplaced: pd.DataFrame     # buffer left after last interval (record_id, frac, tonnes, volume_m3)
    f_v: float


def reconcile(loads: pd.DataFrame, net: pd.DataFrame, f_v: float, sigma_z: float,
              carry_over: bool = True) -> Reconciliation:
    """``loads``: columns record_id, interval, timestamp, payload_t, dens.
    ``net``: columns interval, net_m3, footprint_m2 (one row per interval).
    ``carry_over=False`` disables the pad buffer (A-015 sensitivity): material
    not placed in its own interval is reported as unplaced immediately."""
    loads = loads.sort_values(["timestamp", "record_id"], kind="stable")
    buffer: list[list] = []  # [record_id, interval_dumped, remaining_frac, tonnes_full, vol_full]
    dropped: list[list] = []
    place_rows, int_rows = [], []
    for _, row in net.sort_values("interval").iterrows():
        k = int(row["interval"])
        new = loads[loads["interval"] == k]
        for r in new.itertuples():
            vol = f_v * r.payload_t / r.dens
            buffer.append([r.record_id, k, 1.0, r.payload_t, vol])
        supply = sum(b[2] * b[4] for b in buffer)
        need = float(row["net_m3"])
        tau = sigma_z * float(row["footprint_m2"])
        placed_v = 0.0
        placed_t = 0.0
        remaining = need
        while buffer and remaining > 1e-9:
            b = buffer[0]
            avail = b[2] * b[4]
            take = min(avail, remaining)
            frac = take / b[4]
            place_rows.append(dict(record_id=b[0], interval_placed=k, interval_dumped=b[1], frac=frac,
                                   tonnes=frac * b[3], volume_m3=take))
            placed_v += take
            placed_t += frac * b[3]
            remaining -= take
            b[2] -= frac
            if b[2] <= 1e-12:
                buffer.pop(0)
        excess = max(need - supply, 0.0)
        absorbed = min(excess, tau)
        unk = excess - absorbed
        if absorbed > 0 and placed_v > 0:
            # stretch this interval's placements to fill the tolerance volume
            scale = (placed_v + absorbed) / placed_v
            for pr in place_rows:
                if pr["interval_placed"] == k:
                    pr["volume_m3"] *= scale
        if not carry_over:
            dropped.extend(buffer)
            buffer = []
        int_rows.append(dict(
            interval=k, net_m3=need, supply_m3=supply, fms_new_t=float(new.payload_t.sum()),
            placed_fms_t=placed_t, placed_fms_m3=placed_v + absorbed, absorbed_tolerance_m3=absorbed,
            tolerance_m3=tau, unk_m3=unk, buffer_after_m3=sum(b[2] * b[4] for b in buffer),
            buffer_after_t=sum(b[2] * b[3] for b in buffer), n_buffer_loads=len(buffer),
        ))
    unplaced = pd.DataFrame([dict(record_id=b[0], interval_dumped=b[1], frac=b[2], tonnes=b[2] * b[3],
                                  volume_m3=b[2] * b[4]) for b in dropped + buffer],
                            columns=["record_id", "interval_dumped", "frac", "tonnes", "volume_m3"])
    P = pd.DataFrame(place_rows, columns=["record_id", "interval_placed", "interval_dumped", "frac", "tonnes", "volume_m3"])
    I = pd.DataFrame(int_rows)
    I["placed_density_t_m3"] = I["placed_fms_t"] / I["placed_fms_m3"].replace(0, np.nan)
    return Reconciliation(P, I, unplaced, f_v)


def mass_check(loads: pd.DataFrame, rec: Reconciliation) -> dict:
    """Recorded tonnes = placed + unplaced (exactly, up to float rounding)."""
    total = float(loads["payload_t"].sum())
    placed = float(rec.placements["tonnes"].sum())
    unplaced = float(rec.unplaced["tonnes"].sum())
    per_load = rec.placements.groupby("record_id")["frac"].sum().add(
        rec.unplaced.groupby("record_id")["frac"].sum(), fill_value=0.0)
    return dict(recorded_t=total, placed_t=placed, unplaced_t=unplaced,
                residual_t=total - placed - unplaced,
                max_load_frac_error=float(np.abs(per_load.reindex(loads.record_id).fillna(0) - 1).max()))


def robust_volume_factor(table: pd.DataFrame, k_mad: float = 3.0) -> dict:
    """Pooled f_v over intervals whose ratio net/(sum T/Dens) is not an outlier.

    ``table`` columns: interval, net_m3, vdens_m3 (= sum T/Dens of the interval's loads).
    Outliers (median +/- k_mad * 1.4826 * MAD) indicate incomplete FMS or
    survey coverage and are excluded from calibration, not from the model.
    """
    r = table["net_m3"] / table["vdens_m3"]
    med = float(np.median(r))
    sd = 1.4826 * float(np.median(np.abs(r - med)))
    ok = (np.abs(r - med) <= k_mad * sd) & (table["vdens_m3"] > 0)
    f = float(table.loc[ok, "net_m3"].sum() / table.loc[ok, "vdens_m3"].sum())
    return dict(f_v=f, median_ratio=med, robust_sd=sd, used_intervals=table.loc[ok, "interval"].tolist(),
                outlier_intervals=table.loc[~ok, "interval"].tolist(), ratios=r.round(4).tolist())
