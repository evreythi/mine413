"""Audit trail: run manifests, run history, manual interventions, change reports.

Every ``run`` writes ``outputs/run_manifest.json`` (what was run, on which
exact inputs, with which code and parameters, what came out) and appends a
row to ``outputs/run_history.csv``. Key result files of each run are copied
to ``outputs/history/<run_id>/`` so earlier model updates can be compared
(Task 8 item 11).

Manual interventions (``config/manual_interventions.csv``) are the *only*
supported way to override the data; each must carry a reason, an author and
a date, and is applied and reported by the QA stage.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import platform
import shutil
import subprocess
from importlib import metadata
from pathlib import Path

import pandas as pd

from . import __version__
from .config import REPO_ROOT

INTERVENTION_TYPES = {
    "exclude_record": "Exclude an FMS record (by cycle_id) from the model",
    "location_unknown": "Treat an FMS record's dump position as unknown (by cycle_id)",
}
INTERVENTION_COLUMNS = ["id", "type", "cycle_id", "reason", "author", "date"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def git_state(root: Path = REPO_ROOT) -> dict:
    def run(*args):
        try:
            return subprocess.run(["git", *args], cwd=root, capture_output=True, text=True, timeout=10).stdout.strip()
        except Exception:  # git not available: record that fact
            return ""
    # generated files (outputs/, the filled report) are excluded: they change during every run
    changed = run("status", "--porcelain", "--untracked-files=no", "--", ".", ":(exclude)outputs",
                  ":(exclude)docs/engineering_report.md")
    return dict(commit=run("rev-parse", "HEAD") or "unknown", branch=run("rev-parse", "--abbrev-ref", "HEAD"),
                dirty=bool(changed), uncommitted_files=changed.splitlines())


def environment() -> dict:
    libs = {}
    for name in ("numpy", "pandas", "scipy", "matplotlib", "ezdxf"):
        try:
            libs[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            libs[name] = "not installed"
    return dict(python=platform.python_version(), platform=platform.platform(), package_version=__version__,
                libraries=libs)


def load_interventions(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame(columns=INTERVENTION_COLUMNS)
    df = pd.read_csv(path, dtype=str).fillna("")
    missing = [c for c in INTERVENTION_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"{path.name}: missing columns {missing}")
    bad = df[~df["type"].isin(INTERVENTION_TYPES)]
    if len(bad):
        raise ValueError(f"{path.name}: unknown intervention types {bad['type'].tolist()}")
    incomplete = df[(df["reason"].str.strip() == "") | (df["author"].str.strip() == "") | (df["date"].str.strip() == "")]
    if len(incomplete):
        raise ValueError(f"{path.name}: interventions {incomplete['id'].tolist()} lack reason/author/date")
    return df


def apply_interventions(flagged: pd.DataFrame, iv: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Apply manual interventions to the flagged FMS table; return (table, log)."""
    out = flagged.copy()
    out["manual_intervention"] = ""
    rows = []
    for r in iv.itertuples():
        m = out["cycle_id"].astype("Int64").astype(str) == str(r.cycle_id).strip()
        n = int(m.sum())
        if r.type == "exclude_record":
            out.loc[m, "use_in_model"] = False
        elif r.type == "location_unknown":
            out.loc[m, "use_location"] = False
        out.loc[m, "manual_intervention"] = out.loc[m, "manual_intervention"] + f"{r.id};"
        rows.append(dict(id=r.id, type=r.type, cycle_id=r.cycle_id, records_matched=n, tonnes=float(out.loc[m, "payload_t"].sum()),
                         reason=r.reason, author=r.author, date=r.date, status="applied" if n else "NO MATCH"))
    return out, pd.DataFrame(rows, columns=["id", "type", "cycle_id", "records_matched", "tonnes", "reason", "author", "date", "status"])


def new_run_id() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def write_manifest(out_root: Path, run_id: str, cfg: dict, inputs, stages: list, durations: dict,
                   results: dict, interventions_log: pd.DataFrame | None, git: dict | None = None) -> dict:
    files = [dict(kind="fms", file=str(p.relative_to(REPO_ROOT)) if p.is_relative_to(REPO_ROOT) else str(p), sha256=sha256(p))
             for p in inputs.fms_files]
    files += [dict(kind="survey", file=str(s.path.relative_to(REPO_ROOT)) if s.path.is_relative_to(REPO_ROOT) else str(s.path),
                   sha256=s.sha256, date_used=str(s.date)) for s in inputs.surveys]
    summ = {k: v.get("summary") for k, v in results.items() if isinstance(v, dict) and "summary" in v}
    bm_path = out_root / "04_blockmodel" / "block_model.csv"
    manifest = dict(
        run_id=run_id, utc=_dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
        git=git or git_state(), environment=environment(), stages=stages, durations_s=durations,
        inputs=files, config=cfg,
        manual_interventions=[] if interventions_log is None else interventions_log.to_dict("records"),
        outputs=dict(block_model_sha256=sha256(bm_path) if bm_path.exists() else None),
        summaries=summ,
    )
    (out_root / "run_manifest.json").write_text(json.dumps(manifest, indent=2, default=str))
    return manifest


def record_history(out_root: Path, manifest: dict) -> pd.DataFrame:
    """Append to run_history.csv and archive small key outputs of this run."""
    s = manifest["summaries"]
    bm = s.get("blockmodel") or {}
    row = dict(run_id=manifest["run_id"], utc=manifest["utc"], git_commit=manifest["git"]["commit"][:12],
               git_dirty=manifest["git"]["dirty"], n_surveys=sum(1 for f in manifest["inputs"] if f["kind"] == "survey"),
               last_survey=max((f.get("date_used", "") for f in manifest["inputs"] if f["kind"] == "survey"), default=""),
               n_fms_records=(s.get("qaqc") or {}).get("n_fms_records"),
               tonnes=bm.get("tonnes"), cu_pct=bm.get("cu_pct"), au_gpt=bm.get("au_gpt"), cu_t=bm.get("cu_t"),
               au_oz=bm.get("au_oz"), pending_t=bm.get("pending_after_last_survey_t"),
               f_v=((s.get("growth") or {}).get("calibration") or {}).get("f_v_used"),
               n_interventions=len(manifest["manual_interventions"]),
               block_model_sha256=manifest["outputs"]["block_model_sha256"])
    hist_path = out_root / "run_history.csv"
    hist = pd.read_csv(hist_path) if hist_path.exists() else pd.DataFrame()
    hist = pd.concat([hist, pd.DataFrame([row])], ignore_index=True)
    hist.to_csv(hist_path, index=False)
    arch = out_root / "history" / manifest["run_id"]
    arch.mkdir(parents=True, exist_ok=True)
    shutil.copy(out_root / "run_manifest.json", arch / "run_manifest.json")
    for rel in ("04_blockmodel/inventory_total.csv", "04_blockmodel/inventory_by_confidence.csv",
                "02_growth/growth_budget_and_reconciliation.csv", "01_qaqc/qa_flag_summary.csv"):
        p = out_root / rel
        if p.exists():
            shutil.copy(p, arch / p.name)
    return hist


def change_report(hist: pd.DataFrame) -> str:
    """Plain-text comparison of the latest run with the previous one."""
    if len(hist) < 2:
        return "First recorded run - no previous model to compare with.\n"
    a, b = hist.iloc[-2], hist.iloc[-1]
    lines = [f"Model update {b.run_id} vs previous {a.run_id}", ""]
    for col, lab, fmt in (("n_surveys", "Surveys", "{:.0f}"), ("last_survey", "Last survey", "{}"),
                          ("n_fms_records", "FMS records", "{:.0f}"), ("tonnes", "Modelled tonnes", "{:,.0f}"),
                          ("cu_pct", "Cu %", "{:.3f}"), ("au_gpt", "Au g/t", "{:.3f}"), ("cu_t", "Cu t", "{:,.1f}"),
                          ("au_oz", "Au oz", "{:,.0f}"), ("pending_t", "Pending (after last survey) t", "{:,.0f}"),
                          ("f_v", "Volume factor f_v", "{:.4f}"), ("n_interventions", "Manual interventions", "{:.0f}")):
        va, vb = a.get(col), b.get(col)
        try:
            sa, sb = fmt.format(va), fmt.format(vb)
        except (ValueError, TypeError):
            sa, sb = str(va), str(vb)
        mark = "" if sa == sb else "   <- changed"
        lines.append(f"  {lab:32s} {sa:>14s} -> {sb:>14s}{mark}")
    same = a.get("block_model_sha256") == b.get("block_model_sha256")
    lines.append("")
    lines.append("  Block model file identical to previous run." if same else "  Block model file changed.")
    return "\n".join(lines) + "\n"
