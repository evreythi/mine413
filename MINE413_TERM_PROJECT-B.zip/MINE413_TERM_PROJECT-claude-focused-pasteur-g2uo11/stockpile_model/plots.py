"""Shared figure styling (static PNG report figures).

Colour rules follow the project's data-viz convention: categorical hues in a
fixed order, sequential = one hue light->dark, diverging = blue/red with a
neutral grey midpoint, recessive grids, one y-axis per chart.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
STATUS = {"good": "#0ca30c", "warning": "#fab219", "serious": "#ec835a", "critical": "#d03b3b"}

_BLUE = ["#cde2fb", "#b7d3f6", "#9ec5f4", "#86b6ef", "#6da7ec", "#5598e7", "#3987e5",
         "#2a78d6", "#256abf", "#1c5cab", "#184f95", "#104281", "#0d366b"]
SEQ = LinearSegmentedColormap.from_list("seq_blue", _BLUE)
SEQ_ORANGE = LinearSegmentedColormap.from_list(
    "seq_orange", ["#fde3d6", "#f8b99d", "#f28f65", "#eb6834", "#c94f1f", "#9a3a14", "#6b280d"])
DIV = LinearSegmentedColormap.from_list(
    "div_blue_red", ["#0d366b", "#2a78d6", "#9ec5f4", "#f0efec", "#f4a5a4", "#e34948", "#8f1f1e"])
SEQ = SEQ.with_extremes(bad=SURFACE)
SEQ_ORANGE = SEQ_ORANGE.with_extremes(bad=SURFACE)
DIV = DIV.with_extremes(bad=SURFACE)


def apply_style():
    plt.rcParams.update({
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.edgecolor": AXIS,
        "axes.labelcolor": INK2,
        "axes.titlecolor": INK,
        "axes.titlesize": 11,
        "axes.labelsize": 9,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "axes.grid": True,
        "grid.color": GRID,
        "grid.linewidth": 0.6,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.prop_cycle": matplotlib.cycler(color=SERIES),
        "lines.linewidth": 2.0,
        "legend.frameon": False,
        "legend.fontsize": 8,
        "font.family": "sans-serif",
        "savefig.dpi": 130,
        "savefig.bbox": "tight",
    })


def plan_axes(ax, grid, title=None):
    ax.set_xlim(grid.x_min, grid.x_max)
    ax.set_ylim(grid.y_min, grid.y_max)
    ax.set_aspect("equal")
    ax.ticklabel_format(useOffset=False, style="plain")
    ax.set_xlabel("Easting X (m)")
    ax.set_ylabel("Northing Y (m)")
    ax.grid(False)
    if title:
        ax.set_title(title, loc="left")


apply_style()
