"""Evidence categories used to label every major result.

These labels are deliberately strict. ``VALIDATED`` may only be used for a
result that has been compared against an independent or held-out observation;
code that merely runs produces ``MODEL-GENERATED`` or ``CALCULATED`` output.
"""

MEASURED = "MEASURED"            # directly present in supplied data
CALCULATED = "CALCULATED"        # mathematically derived from measured data
INFERRED = "INFERRED"            # estimated from evidence
ASSUMED = "ASSUMED"              # chosen because the data do not determine it
MODEL_GENERATED = "MODEL-GENERATED"  # produced by the movement/block model
VALIDATED = "VALIDATED"          # checked against independent/held-out data

ALL = (MEASURED, CALCULATED, INFERRED, ASSUMED, MODEL_GENERATED, VALIDATED)
