"""Stockpile growth: composite surface history and per-interval volume budget.

Because the survey files are fill-only increment solids (A-009), the surface
at any time is known only where some solid has covered it. A per-cell tracker
walks the solids in time order and keeps the latest known surface ``Z``:

* ``base_k`` above the known surface  -> *revealed missing fill*: material
  placed during an interval with no supplied survey (e.g. 17 March);
* ``base_k`` below the known surface  -> *revealed cut*: material removed
  (dozer re-push) between the two observations;
* first coverage of a cell            -> ``base_k`` is the pre-model surface
  (pre-existing pile or ground).

Revealed cut and missing fill are attributed to the interval in which they
are revealed (A-013); the earliest possible interval is stored as well.

Net volume change  V_net,k = V_fill,k + V_missfill,k - V_cut,k  is the
quantity compared with FMS tonnage (mass conservation); fill alone would
double count rehandled material.
"""

from __future__ import annotations

import dataclasses

import numpy as np
import pandas as pd

from .surfaces import SolidRaster


@dataclasses.dataclass
class GrowthHistory:
    z_pre: np.ndarray            # pre-model surface (base at first coverage), NaN if never covered
    z_final: np.ndarray          # latest known surface after the last solid
    first_cover: np.ndarray      # interval index of first coverage, -1 if never
    last_cover: np.ndarray       # interval index of last coverage, -1 if never
    cut: list                    # per interval: (ny, nx) revealed cut depth (>= 0)
    cut_from: list               # per interval: (ny, nx) index of the solid that last set Z (earliest possible interval - 1)
    missfill: list               # per interval: (ny, nx) revealed missing-fill thickness (>= 0)
    table: pd.DataFrame          # per-interval volume budget


def track(rasters: list[SolidRaster], tol: float = 0.10) -> GrowthHistory:
    ny, nx = rasters[0].top.shape
    area = rasters[0].cell_area
    Z = np.full((ny, nx), np.nan)
    src = np.full((ny, nx), -1)
    z_pre = np.full((ny, nx), np.nan)
    first = np.full((ny, nx), -1)
    cuts, cut_from, misses, rows = [], [], [], []
    for k, r in enumerate(rasters):
        m = r.mask
        known = m & np.isfinite(Z)
        dz = np.where(known, r.base - np.nan_to_num(Z), 0.0)
        cut = np.where(dz < -tol, -dz, 0.0)
        miss = np.where(dz > tol, dz, 0.0)
        new = m & ~np.isfinite(Z)
        z_pre[new] = r.base[new]
        first[new] = k
        cuts.append(cut)
        cut_from.append(np.where(cut > 0, src, -1))
        misses.append(miss)
        fill_v = r.volume
        cut_v = float(cut.sum() * area)
        miss_v = float(miss.sum() * area)
        rows.append(dict(
            interval=k, survey=r.name, fill_m3=fill_v, revealed_cut_m3=cut_v,
            revealed_missing_fill_m3=miss_v, net_m3=fill_v + miss_v - cut_v,
            footprint_m2=r.area, new_area_m2=float(new.sum() * area),
            reoccupied_area_m2=float(known.sum() * area),
            cut_area_m2=float((cut > 0).sum() * area), missfill_area_m2=float((miss > 0).sum() * area),
            max_cut_m=float(cut.max()), max_missfill_m=float(miss.max()),
            cut_earliest_interval=int(src[cut > 0].min() + 1) if (cut > 0).any() else -1,
        ))
        Z = np.where(m, r.top, Z)
        src = np.where(m, k, src)
    last = src.copy()
    return GrowthHistory(z_pre, Z, first, last, cuts, cut_from, misses, pd.DataFrame(rows))


def volume_at_resolution(surveys, cell: float, grid_bounds) -> list[float]:
    """Solid volumes recomputed at another plan resolution (A-010 check)."""
    from .io_survey import GridSpec
    from .surfaces import rasterise_solid
    g = GridSpec.from_bounds(*grid_bounds, cell)
    return [rasterise_solid(s, g).volume for s in surveys]


def exact_tin_volume(tri: np.ndarray) -> float:
    """Enclosed volume of a closed, consistently oriented triangulated solid.

    Divergence theorem with F = (0, 0, z): V = sum_f A_xy(f) * zbar(f), where
    A_xy is the signed plan area of face f (sign from its orientation) and zbar
    the mean vertex elevation. This is exact for planar triangles and is
    independent of any grid, so it is an independent check of the raster
    volume (and of the closed-solid interpretation, A-009): it only agrees with
    the raster volume if the faces form a closed, consistently oriented shell.
    """
    a = tri[:, 1, :2] - tri[:, 0, :2]
    b = tri[:, 2, :2] - tri[:, 0, :2]
    signed = 0.5 * (a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0])
    zbar = tri[:, :, 2].mean(axis=1)
    return float(abs(np.sum(signed * zbar)))


def slope_statistics(rasters, cell: float, min_thickness: float = 0.3) -> tuple[pd.DataFrame, np.ndarray]:
    """Surface slope of each solid top (central differences over 2 cells).

    Cells thinner than ``min_thickness`` (pinch-out edges) are excluded because
    their slope mixes top and base. The steep-face mode estimates the angle of
    repose of the dumped material (A-018).
    """
    rows, pooled = [], []
    for r in rasters:
        gy, gx = np.gradient(r.top, cell)
        sl = np.degrees(np.arctan(np.hypot(gx, gy)))
        ok = r.mask & np.isfinite(sl) & (r.thickness > min_thickness)
        v = sl[ok]
        pooled.append(v)
        p = np.percentile(v, [50, 75, 90, 95, 99])
        rows.append(dict(survey=r.name, n_cells=int(v.size), p50=p[0], p75=p[1], p90=p[2], p95=p[3], p99=p[4],
                         frac_gt_40=float(np.mean(v > 40)), frac_gt_45=float(np.mean(v > 45))))
    return pd.DataFrame(rows), np.concatenate(pooled)


def repose_estimate(slopes: np.ndarray, min_deg: float = 25.0) -> dict:
    s = slopes[slopes > min_deg]
    h, e = np.histogram(s, bins=np.arange(min_deg, 70.0, 1.0))
    return dict(mode_deg=float(e[np.argmax(h)] + 0.5), median_deg=float(np.median(s)),
                p25_deg=float(np.percentile(s, 25)), p75_deg=float(np.percentile(s, 75)),
                p95_deg=float(np.percentile(s, 95)), n_cells=int(s.size), threshold_deg=min_deg)
