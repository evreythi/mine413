"""Rasterised survey solids and their stacking relationships.

Interpretation (INFERRED in Phase 1, see docs/data_register.md §2):
each supplied DXF is a *closed fill solid* for one survey interval: its base
is the surface at the previous survey and its top is the surface at this
survey, restricted to cells where the surface rose. Evidence: every covered
grid cell is intersected exactly twice (top + base), and on 7 of 9
consecutive pairs the base of solid k+1 equals the top of solid k to < 1 mm.
"""

from __future__ import annotations

import dataclasses

import numpy as np
import pandas as pd

from .io_survey import GridSpec, Survey, rasterise_tin


@dataclasses.dataclass
class SolidRaster:
    name: str
    date: np.datetime64
    top: np.ndarray    # (ny, nx) elevation of solid top, NaN outside
    base: np.ndarray   # (ny, nx) elevation of solid base, NaN outside
    hits: np.ndarray   # (ny, nx) number of TIN faces intersected per cell
    cell_area: float

    @property
    def mask(self) -> np.ndarray:
        return np.isfinite(self.top)

    @property
    def thickness(self) -> np.ndarray:
        return np.where(self.mask, self.top - self.base, 0.0)

    @property
    def volume(self) -> float:
        return float(self.thickness.sum() * self.cell_area)

    @property
    def area(self) -> float:
        return float(self.mask.sum() * self.cell_area)


def rasterise_solid(s: Survey, grid: GridSpec) -> SolidRaster:
    top, base, hits = rasterise_tin(s.triangles, grid)
    return SolidRaster(s.name, s.date, top, base, hits, grid.cell_area)


def closure_check(r: SolidRaster) -> dict:
    """A closed 2.5D solid is hit by exactly 2 faces at every covered cell."""
    h = r.hits[r.hits > 0]
    n = h.size
    return dict(
        survey=r.name,
        covered_cells=int(n),
        frac_hits_eq_2=float(np.mean(h == 2)) if n else np.nan,
        cells_hits_1=int(np.sum(h == 1)),
        cells_hits_gt2=int(np.sum(h > 2)),
        thin_cells_lt_1cm=int(np.sum((r.top - r.base)[r.mask] < 0.01)),
    )


def pair_stacking(a: SolidRaster, b: SolidRaster, tol: float = 0.10) -> dict:
    """Compare base of later solid ``b`` with top of earlier solid ``a``.

    If no material is removed between the two surveys, ``base_b == top_a``
    wherever both exist. ``base_b < top_a - tol`` is evidence that material
    placed in ``a`` was cut (e.g. a dozer crest push) before ``b``.
    """
    m = a.mask & b.mask
    out = dict(earlier=a.name, later=b.name, overlap_m2=float(m.sum() * a.cell_area))
    if m.sum() == 0:
        return out | dict(median_dz=np.nan, frac_within_tol=np.nan, frac_cut=np.nan,
                          cut_volume_m3=0.0, max_cut_m=0.0)
    dz = (b.base - a.top)[m]
    cut = np.clip(-dz, 0, None)
    return out | dict(
        median_dz=float(np.median(dz)),
        p05_dz=float(np.percentile(dz, 5)),
        p95_dz=float(np.percentile(dz, 95)),
        frac_within_tol=float(np.mean(np.abs(dz) <= tol)),
        frac_cut=float(np.mean(dz < -tol)),
        cut_volume_m3=float(cut[dz < -tol].sum() * a.cell_area),
        max_cut_m=float(cut.max()),
    )


def stacking_table(rasters: list[SolidRaster], tol: float = 0.10, consecutive_only=False) -> pd.DataFrame:
    rows = []
    for i in range(len(rasters)):
        js = [i + 1] if consecutive_only else range(i + 1, len(rasters))
        for j in js:
            if j < len(rasters):
                rows.append(pair_stacking(rasters[i], rasters[j], tol) | dict(gap=j - i))
    return pd.DataFrame(rows)
