"""Pipeline context: locate inputs, load/rasterise them (with cache), run stages."""

from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import timing
from .config import REPO_ROOT
from .io_fms import read_fms
from .io_survey import GridSpec, read_dxf_tin
from .surfaces import SolidRaster, rasterise_solid


@dataclasses.dataclass
class Inputs:
    grid: GridSpec
    surveys: list            # list[Survey], sorted by date
    rasters: list            # list[SolidRaster], same order
    fms: pd.DataFrame        # raw standardised FMS (no flags yet)
    cutoffs: pd.DatetimeIndex
    intervals: pd.DataFrame
    interval_idx: np.ndarray  # interval of each FMS record
    fms_files: list
    survey_files: list


def grid_from_cfg(cfg) -> GridSpec:
    g = cfg["grid"]
    return GridSpec.from_bounds(g["x_min"], g["x_max"], g["y_min"], g["y_max"], g["cell"])


def resolve(path, root=REPO_ROOT) -> Path:
    p = Path(path)
    return p if p.is_absolute() else Path(root) / p


def _cache_key(sha: str, grid: GridSpec) -> str:
    s = f"{sha}|{grid.x_min}|{grid.y_min}|{grid.nx}|{grid.ny}|{grid.cell}|v2"
    return hashlib.sha256(s.encode()).hexdigest()[:24]


def load_rasters(surveys, grid: GridSpec, cache_dir: Path | None) -> list[SolidRaster]:
    out = []
    for s in surveys:
        cached = None
        if cache_dir is not None:
            cache_dir.mkdir(parents=True, exist_ok=True)
            cached = cache_dir / f"{s.name}_{_cache_key(s.sha256, grid)}.npz"
        if cached is not None and cached.exists():
            z = np.load(cached)
            out.append(SolidRaster(s.name, s.date, z["top"], z["base"], z["hits"], grid.cell_area))
            continue
        r = rasterise_solid(s, grid)
        if cached is not None:
            np.savez_compressed(cached, top=r.top, base=r.base, hits=r.hits)
        out.append(r)
    return out


def load_inputs(cfg, root=REPO_ROOT, cache_dir=None) -> Inputs:
    raw = resolve(cfg["data"]["raw_dir"], root)
    fms_files = sorted(raw.glob(cfg["data"]["fms_glob"]))
    survey_files = sorted(raw.glob(cfg["data"]["survey_glob"]))
    if not fms_files or not survey_files:
        raise FileNotFoundError(f"no inputs under {raw}; run `python -m stockpile_model ingest` first")
    grid = grid_from_cfg(cfg)
    surveys = [read_dxf_tin(p, year_override=cfg["data"].get("survey_year")) for p in survey_files]
    surveys.sort(key=lambda s: s.date)
    dates = [s.date for s in surveys]
    if len(set(dates)) != len(dates):
        raise ValueError("two survey files resolve to the same date")
    rasters = load_rasters(surveys, grid, cache_dir if cache_dir is not None else resolve("outputs/.cache", root))
    fms = read_fms(fms_files)
    tcfg = cfg["timing"]
    cut = timing.survey_cutoffs(dates, tcfg["survey_cutoff_hours"])
    intervals = timing.interval_table([s.name for s in surveys], cut, tcfg["first_interval_hours"])
    idx = timing.assign_intervals(fms["timestamp"], cut, tcfg["first_interval_hours"])
    return Inputs(grid, surveys, rasters, fms, cut, intervals, idx, fms_files, survey_files)


def write_json(path: Path, obj) -> None:
    def default(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, (pd.Timestamp, np.datetime64)):
            return str(o)
        if isinstance(o, Path):
            return str(o)
        raise TypeError(type(o))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, default=default))
