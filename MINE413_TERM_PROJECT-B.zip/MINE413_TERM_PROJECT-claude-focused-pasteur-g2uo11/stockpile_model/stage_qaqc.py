"""Stage 1 - data inventory, QA/QC flags, temporal alignment evidence, figures."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy.ndimage import distance_transform_edt
from scipy.stats import spearmanr

from . import plots, qaqc, timing
from .io_survey import sha256_file
from .pipeline import Inputs, write_json
from .plots import plt
from .surfaces import closure_check, stacking_table


def dataset_inventory(inp: Inputs) -> pd.DataFrame:
    rows = []
    for s, r in zip(inp.surveys, inp.rasters):
        x0, x1, y0, y1 = s.xy_bounds
        rows.append(dict(kind="survey", file=s.path.name, sha256=s.sha256, layer=s.layer,
                         file_date_code=s.file_date_code, layer_date_code=s.layer_date_code,
                         date_used=str(s.date), year_conflict=s.file_date_code[:2] != (s.layer_date_code or "")[:2],
                         records=s.n_faces_raw, degenerate_faces=s.n_degenerate,
                         x_min=x0, x_max=x1, y_min=y0, y_max=y1,
                         z_min=float(s.triangles[:, :, 2].min()), z_max=float(s.triangles[:, :, 2].max()),
                         footprint_m2=r.area, solid_volume_m3=r.volume))
    for f in inp.fms_files:
        sub = inp.fms[inp.fms["source_file"] == f.name]
        rows.append(dict(kind="fms", file=f.name, sha256=sha256_file(f), records=len(sub),
                         x_min=sub.x.min(), x_max=sub.x.max(), y_min=sub.y.min(), y_max=sub.y.max(),
                         z_min=sub.z.min(), z_max=sub.z.max(),
                         date_used=f"{sub.timestamp.min()} .. {sub.timestamp.max()}"))
    return pd.DataFrame(rows)


def cutoff_scan(fms: pd.DataFrame, inp: Inputs, hours, first_interval_hours) -> pd.DataFrame:
    """Score candidate survey cut-off times (evidence for assumption A-003).

    For each candidate, loads are assigned to intervals and two independent
    consistency measures are computed: (1) correlation between interval FMS
    tonnage and interval fill-solid volume (first, open interval excluded);
    (2) distance from each dump to the nearest cell of its assigned solid.
    Records with untrusted locations are excluded from (2).
    """
    g = inp.grid
    vols = np.array([r.volume for r in inp.rasters])
    r, c = g.index(fms["x"].values, fms["y"].values)
    okloc = fms["use_location"].values & (r >= 0)
    dist = np.stack([(distance_transform_edt(~ras.mask) * g.cell)[r.clip(0), c.clip(0)] for ras in inp.rasters], axis=1)
    dates = [s.date for s in inp.surveys]
    rows = []
    for h in hours:
        cut = timing.survey_cutoffs(dates, h)
        idx = timing.assign_intervals(fms["timestamp"], cut, first_interval_hours)
        ok = idx >= 0
        T = np.bincount(idx[ok], weights=fms["payload_t"].values[ok], minlength=len(dates))
        sel = ok & okloc
        d = dist[np.where(sel)[0], idx[sel]]
        rows.append(dict(cutoff_hours=h, pearson_T_V=np.corrcoef(T[1:], vols[1:])[0, 1],
                         spearman_T_V=spearmanr(T[1:], vols[1:]).statistic,
                         median_dist_to_assigned_solid_m=float(np.median(d)),
                         frac_within_3m=float(np.mean(d < 3.0)), n_in_intervals=int(ok.sum())))
    return pd.DataFrame(rows)


def interval_summary(fl: pd.DataFrame, inp: Inputs) -> pd.DataFrame:
    m = fl[fl["use_in_model"]]
    g = m.groupby("interval")
    t = pd.DataFrame({
        "n_loads": g.size(),
        "fms_t": g["payload_t"].sum(),
        "fms_t_over_dens_m3": g.apply(lambda s: (s.payload_t / s.dens).sum(), include_groups=False),
        "n_loc_unknown": g["use_location"].apply(lambda s: int((~s).sum())),
        "first_dump": g["timestamp"].min(),
        "last_dump": g["timestamp"].max(),
    })
    out = inp.intervals.set_index("interval").join(t).reset_index()
    out[["n_loads", "fms_t", "fms_t_over_dens_m3", "n_loc_unknown"]] = out[["n_loads", "fms_t", "fms_t_over_dens_m3", "n_loc_unknown"]].fillna(0)
    out["solid_volume_m3"] = [r.volume for r in inp.rasters]
    out["solid_footprint_m2"] = [r.area for r in inp.rasters]
    out["fms_t_per_solid_m3"] = out["fms_t"] / out["solid_volume_m3"]
    out["solid_over_fms_dens_volume"] = out["solid_volume_m3"] / out["fms_t_over_dens_m3"].replace(0, np.nan)
    return out


# --------------------------------------------------------------------- figures
def fig_dump_map(fl, inp, path):
    g = inp.grid
    union_top = np.full((g.ny, g.nx), np.nan)
    for r in inp.rasters:
        union_top = np.where(r.mask, r.top, union_top)
    fig, ax = plt.subplots(figsize=(8.5, 7.5))
    im = ax.imshow(union_top, origin="lower", extent=g.extent(), cmap=plots.SEQ, alpha=0.85)
    cb = fig.colorbar(im, ax=ax, shrink=0.7)
    cb.set_label("Final surveyed top elevation within solids (m)")
    ok = fl["use_location"]
    t0 = fl["timestamp"].min()
    days = (fl["timestamp"] - t0).dt.total_seconds() / 86400
    sc = ax.scatter(fl.loc[ok, "x"], fl.loc[ok, "y"], c=days[ok], cmap=plots.SEQ_ORANGE, s=14,
                    edgecolors=plots.SURFACE, linewidths=0.5, label="Dump (trusted XY), colour = days since first")
    d = fl["qa_LOC_DEFAULT"]
    ax.scatter(fl.loc[d, "x"], fl.loc[d, "y"], marker="x", s=60, c=plots.STATUS["critical"], linewidths=1.5,
               label=f"Fallback coordinate (LOC_DEFAULT, n={int(d.sum())})")
    late = fl["qa_TIME_AFTER_LAST_SURVEY"]
    ax.scatter(fl.loc[late, "x"], fl.loc[late, "y"], marker="s", s=40, facecolors="none",
               edgecolors=plots.INK, label=f"After last survey (n={int(late.sum())})")
    cb2 = fig.colorbar(sc, ax=ax, shrink=0.7)
    cb2.set_label("Days since first FMS record")
    plots.plan_axes(ax, g, "FMS dump locations over the union of surveyed fill solids")
    ax.legend(loc="lower left")
    fig.savefig(path)
    plt.close(fig)


def fig_daily(fl, inp, path):
    m = fl[fl["use_in_model"] | fl["qa_TIME_AFTER_LAST_SURVEY"]].copy()
    m["day"] = m["timestamp"].dt.floor("D")
    days = pd.date_range(m["day"].min(), m["day"].max(), freq="D")
    t = m.groupby("day")["payload_t"].sum().reindex(days, fill_value=0)
    cu = (m.payload_t * m.cu).groupby(m.day).sum().reindex(days) / t.replace(0, np.nan)
    au = (m.payload_t * m.au).groupby(m.day).sum().reindex(days) / t.replace(0, np.nan)
    fig, axs = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    axs[0].bar(days, t.values, width=0.8, color=plots.SERIES[0])
    for c in inp.cutoffs:
        for a in axs:
            a.axvline(c, color=plots.MUTED, lw=0.8, ls=":")
    axs[0].set_ylabel("FMS tonnes per calendar day")
    axs[0].set_title("Daily FMS tonnage and tonnage-weighted grade (dotted = survey cut-offs, A-003)", loc="left")
    axs[1].plot(days, cu.values, marker="o", ms=4, color=plots.SERIES[1])
    axs[1].set_ylabel("Cu (%)")
    axs[2].plot(days, au.values, marker="o", ms=4, color=plots.SERIES[2])
    axs[2].set_ylabel("Au (g/t)")
    fig.autofmt_xdate()
    fig.savefig(path)
    plt.close(fig)


def fig_hours(fl, scan, cut_h, path):
    fig, axs = plt.subplots(1, 2, figsize=(12, 4))
    mins = fl["timestamp"].dt.hour + fl["timestamp"].dt.minute / 60
    axs[0].hist(mins, bins=np.arange(0, 24.5, 0.5), color=plots.SERIES[0], edgecolor=plots.SURFACE)
    axs[0].axvline(cut_h % 24, color=plots.SERIES[1], lw=1.5)
    axs[0].text(cut_h % 24 + 0.2, axs[0].get_ylim()[1] * 0.9, "assumed survey\ncut-off", color=plots.INK2, fontsize=8)
    axs[0].set_xlabel("Hour of day (dump timestamp)")
    axs[0].set_ylabel("Loads per 30 min")
    axs[0].set_title("Dump time-of-day: gaps mark shift changes", loc="left")
    axs[1].plot(scan.cutoff_hours, scan.pearson_T_V, marker="o", ms=4, label="Pearson r (tonnage vs solid volume)")
    axs[1].plot(scan.cutoff_hours, scan.frac_within_3m, marker="s", ms=4, label="Fraction of dumps < 3 m from assigned solid")
    axs[1].axvline(cut_h, color=plots.MUTED, lw=1, ls=":")
    axs[1].set_xlabel("Cut-off = label date 00:00 + hours")
    axs[1].set_ylabel("Consistency score")
    axs[1].set_title("Survey cut-off scan (evidence for A-003)", loc="left")
    axs[1].legend(loc="upper left")
    fig.savefig(path)
    plt.close(fig)


def fig_solids(fl, inp, path):
    g = inp.grid
    n = len(inp.rasters)
    ncol = 5
    nrow = int(np.ceil(n / ncol))
    fig, axs = plt.subplots(nrow, ncol, figsize=(4.2 * ncol, 3.9 * nrow), constrained_layout=True)
    vmax = max(np.nanmax(np.where(r.mask, r.thickness, np.nan)) for r in inp.rasters)
    union = np.zeros((g.ny, g.nx), bool)
    for r in inp.rasters:
        union |= r.mask
    for k, (ax, r) in enumerate(zip(axs.flat, inp.rasters)):
        ax.contour(g.xc, g.yc, union.astype(float), levels=[0.5], colors=[plots.AXIS], linewidths=0.6)
        im = ax.imshow(np.where(r.mask, r.thickness, np.nan), origin="lower", extent=g.extent(),
                       cmap=plots.SEQ, vmin=0, vmax=vmax)
        sel = (fl["interval"] == k) & fl["use_location"]
        ax.scatter(fl.loc[sel, "x"], fl.loc[sel, "y"], s=10, c=plots.SERIES[1], edgecolors=plots.SURFACE, linewidths=0.4)
        plots.plan_axes(ax, g)
        ax.set_xlabel("")
        ax.set_ylabel("")
        ax.tick_params(labelsize=6)
        ax.set_title(f"{k}: {r.name}  V={r.volume:,.0f} m³  n={int(sel.sum())}", loc="left", fontsize=9)
    for ax in list(axs.flat)[n:]:
        ax.axis("off")
    cb = fig.colorbar(im, ax=axs, shrink=0.6)
    cb.set_label("Fill-solid thickness (m)")
    fig.suptitle("Survey fill solids per interval (blue) with that interval's dump locations (orange); grey = union outline", x=0.01, ha="left")
    fig.savefig(path)
    plt.close(fig)


def fig_qa_hist(fl, path):
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.2), constrained_layout=True)
    vals = fl["payload_t"].value_counts().sort_index()
    axs[0].bar(vals.index.astype(int).astype(str), vals.values, color=plots.SERIES[0])
    axs[0].set_xlabel("Payload (t)")
    axs[0].set_ylabel("Loads")
    axs[0].set_title("Payload distribution\n(all multiples of 38 t)", loc="left")
    dz = fl.loc[fl["use_location"], "dz_surface"].dropna()
    axs[1].hist(dz, bins=30, color=plots.SERIES[0], edgecolor=plots.SURFACE)
    axs[1].axvline(0, color=plots.MUTED, lw=0.8)
    axs[1].set_xlabel("Dump Z outside surveyed surface envelope (m; 0 = inside)")
    axs[1].set_ylabel("Loads")
    axs[1].set_title(f"Dump Z residual\n(n={len(dz)}, median {np.median(dz):+.2f} m)", loc="left")
    grp = fl.groupby("source_group").agg(t=("payload_t", "sum"), cu=("cu", "first"), au=("au", "first"))
    axs[2].scatter(grp.cu, grp.au, s=np.sqrt(grp.t) * 3, color=plots.SERIES[0], alpha=0.8, edgecolors=plots.SURFACE)
    axs[2].set_xlabel("Cu (%)")
    axs[2].set_ylabel("Au (g/t)")
    axs[2].set_title(f"{len(grp)} distinct grade tuples\n(marker area ~ tonnes)", loc="left")
    fig.savefig(path)
    plt.close(fig)


def run(inp: Inputs, cfg: dict, out_dir: Path, interventions=None) -> dict:
    from .audit import apply_interventions, load_interventions
    out_dir.mkdir(parents=True, exist_ok=True)
    fl = qaqc.flag_records(inp.fms, cfg, inp.grid, inp.rasters, inp.interval_idx)
    if interventions is None:
        interventions = load_interventions(Path("__none__"))
    fl, iv_log = apply_interventions(fl, interventions)
    iv_log.to_csv(out_dir / "manual_interventions_applied.csv", index=False)
    fl["interval_survey"] = [inp.intervals.survey[i] if i >= 0 else "" for i in fl["interval"]]
    inv = dataset_inventory(inp)
    closure = pd.DataFrame([closure_check(r) for r in inp.rasters])
    stack_all = stacking_table(inp.rasters, tol=0.10)
    scan = cutoff_scan(fl, inp, np.arange(0, 37, 1.0), cfg["timing"]["first_interval_hours"])
    isum = interval_summary(fl, inp)
    summ = qaqc.flag_summary(fl)

    inv.to_csv(out_dir / "dataset_inventory.csv", index=False)
    closure.to_csv(out_dir / "survey_closure_check.csv", index=False)
    stack_all.to_csv(out_dir / "survey_stacking_pairs.csv", index=False)
    scan.to_csv(out_dir / "survey_cutoff_scan.csv", index=False)
    isum.to_csv(out_dir / "interval_summary.csv", index=False)
    summ.to_csv(out_dir / "qa_flag_summary.csv", index=False)
    qaqc.rules_table().to_csv(out_dir / "qa_rules.csv", index=False)
    fl.to_csv(out_dir / "fms_flagged.csv", index=False)

    fig_dump_map(fl, inp, out_dir / "fig_dump_map.png")
    fig_daily(fl, inp, out_dir / "fig_daily_tonnage_grade.png")
    fig_hours(fl, scan, cfg["timing"]["survey_cutoff_hours"], out_dir / "fig_time_of_day_and_cutoff_scan.png")
    fig_solids(fl, inp, out_dir / "fig_fill_solids_by_interval.png")
    fig_qa_hist(fl, out_dir / "fig_payload_dz_grades.png")

    consec = stack_all[stack_all.gap == 1]
    summary = dict(
        n_fms_records=len(fl), fms_tonnes_total=float(fl.payload_t.sum()),
        n_in_model=int(fl.use_in_model.sum()), tonnes_in_model=float(fl.loc[fl.use_in_model, "payload_t"].sum()),
        n_location_unknown_in_model=int((fl.use_in_model & ~fl.use_location).sum()),
        tonnes_location_unknown_in_model=float(fl.loc[fl.use_in_model & ~fl.use_location, "payload_t"].sum()),
        n_after_last_survey=int(fl.qa_TIME_AFTER_LAST_SURVEY.sum()),
        n_surveys=len(inp.surveys), total_solid_volume_m3=float(sum(r.volume for r in inp.rasters)),
        closure_frac_hits_eq_2_min=float(closure.frac_hits_eq_2.min()),
        consecutive_pairs_exact_stacking=int((consec.frac_within_tol > 0.99).sum()),
        consecutive_pairs=int(len(consec)),
        n_source_groups=int(fl.source_group.nunique()),
        cutoff_hours_used=cfg["timing"]["survey_cutoff_hours"],
        cutoff_scan_best_pearson_hours=float(scan.loc[scan.pearson_T_V.idxmax(), "cutoff_hours"]),
    )
    write_json(out_dir / "qaqc_summary.json", summary)
    summary["manual_interventions_applied"] = int((iv_log.status == "applied").sum()) if len(iv_log) else 0
    write_json(out_dir / "qaqc_summary.json", summary)
    return dict(flagged=fl, intervals=isum, summary=summary, scan=scan, stacking=stack_all, interventions=iv_log)
