"""Read Fleet Management System (FMS) dump records.

The supplied export has one row per truck dump with columns::

    Cycle ID, Truck PayLoad, Au, Ag, Cu, Dens,
    X (Dump Event), Y (Dump Event), Z (Dump Event), Dump_tstamp

The loader renames these to stable internal names, parses timestamps, keeps
the original row number and source file for traceability, and never drops a
record. Data-quality decisions are recorded as flag columns by
``stockpile_model.qaqc`` instead of deleting rows.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

COLUMN_MAP = {
    "Cycle ID": "cycle_id",
    "Truck PayLoad": "payload_t",
    "Au": "au",
    "Ag": "ag",
    "Cu": "cu",
    "Dens": "dens",
    "X (Dump Event)": "x",
    "Y (Dump Event)": "y",
    "Z (Dump Event)": "z",
    "Dump_tstamp": "timestamp_raw",
}
REQUIRED = list(COLUMN_MAP.values())
TIMESTAMP_FORMAT = "%m/%d/%Y %H:%M"
NUMERIC = ["payload_t", "au", "ag", "cu", "dens", "x", "y", "z"]


def read_fms_csv(path: str | Path) -> pd.DataFrame:
    """Read one FMS export, standardise columns, parse timestamps.

    Unparseable numbers / timestamps become NaN / NaT (and are flagged later)
    rather than raising, so that a single bad row cannot block an update.
    """
    path = Path(path)
    raw = pd.read_csv(path, dtype=str, keep_default_na=False)
    raw.columns = [c.strip() for c in raw.columns]
    missing = [c for c in COLUMN_MAP if c not in raw.columns]
    if missing:
        raise ValueError(f"{path.name}: missing FMS columns {missing}")
    extra = [c for c in raw.columns if c not in COLUMN_MAP]
    df = raw.rename(columns=COLUMN_MAP)
    for c in NUMERIC:
        df[c] = pd.to_numeric(df[c].str.strip().replace("", np.nan), errors="coerce")
    df["cycle_id"] = pd.to_numeric(df["cycle_id"], errors="coerce").astype("Int64")
    df["timestamp"] = pd.to_datetime(df["timestamp_raw"].str.strip(),
                                     format=TIMESTAMP_FORMAT, errors="coerce")
    df["source_file"] = path.name
    df["source_row"] = np.arange(2, len(df) + 2)  # 1-based, header is row 1
    df.attrs["extra_columns"] = extra
    return df[REQUIRED + ["timestamp", "source_file", "source_row"] + extra]


def read_fms(paths) -> pd.DataFrame:
    """Read and concatenate several FMS exports (in the order given).

    Exact duplicate records (same cycle id and identical values, e.g. an
    export re-ingested twice) are collapsed; conflicting duplicates are kept
    and flagged by QA/QC.
    """
    frames = [read_fms_csv(p) for p in paths]
    if not frames:
        raise ValueError("no FMS files supplied")
    df = pd.concat(frames, ignore_index=True)
    key = ["cycle_id", "payload_t", "au", "ag", "cu", "dens", "x", "y", "z", "timestamp"]
    df["n_exact_copies"] = df.groupby(key, dropna=False)["cycle_id"].transform("size")
    df = df.drop_duplicates(subset=key, keep="first").reset_index(drop=True)
    df = df.sort_values(["timestamp", "cycle_id"], kind="stable").reset_index(drop=True)
    df.insert(0, "record_id", np.arange(len(df)))
    return df
