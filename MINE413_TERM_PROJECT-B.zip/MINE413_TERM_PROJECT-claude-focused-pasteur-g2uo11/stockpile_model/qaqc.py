"""Record-level QA/QC of FMS dump data.

Policy (assignment Task 1): questionable data are never deleted. Each rule
adds a boolean ``qa_<RULE>`` column; the combined effect on the model is
expressed by three usage columns:

``use_in_model``  the load's tonnage and metal enter the reconstruction
``use_location``  the reported XY is trusted as the dump location
``use_grade``     the reported grades are used (else imputed, flagged)

The rule catalogue (code, meaning, action) is in ``RULES`` and is written to
the QA report so that every flag can be traced to a documented decision.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .io_survey import GridSpec
from .timing import AFTER_LAST, BEFORE_FIRST

RULES = {
    "MISSING_PAYLOAD": ("Payload missing or non-numeric", "Excluded from model (no mass); retained in register"),
    "MISSING_TIME": ("Timestamp missing/unparseable", "Excluded from model (cannot assign interval)"),
    "DUP_CONFLICT": ("Cycle ID repeated with different values", "Later copies excluded; first kept"),
    "PAYLOAD_NONPOSITIVE": ("Payload <= 0", "Excluded from model"),
    "PAYLOAD_PARTIAL": ("Payload <= partial threshold", "Kept; flagged (plausible part load)"),
    "PAYLOAD_HIGH": ("Payload > modal full-load maximum", "Kept as recorded; flagged; covered by payload uncertainty"),
    "PAYLOAD_OFF_QUANTUM": ("Payload not a multiple of the loading-pass quantum", "Kept; flagged"),
    "GRADE_MISSING": ("Cu/Au missing", "Grade imputed from interval tonnage-weighted mean; flagged"),
    "GRADE_INVALID": ("Grade outside physical range", "Grade imputed; flagged"),
    "DENS_INVALID": ("Density missing/outside plausible range", "Density imputed from interval mean; flagged"),
    "LOC_MISSING": ("X/Y missing", "Location unknown: spread over interval fill"),
    "LOC_OUTSIDE_DOMAIN": ("X/Y outside model domain", "Location unknown: spread over interval fill"),
    "LOC_DEFAULT": ("Identical XYZ repeated across many cycles (fallback coordinate)", "Location unknown: spread over interval fill"),
    "LOC_Z_INCONSISTENT": ("Z further than tolerance outside the surveyed surface envelope of its interval", "Kept; flagged (XY still used)"),
    "LOC_OUTSIDE_SURVEYS": ("XY outside the union footprint of all survey solids", "Kept; informational"),
    "TIME_AFTER_LAST_SURVEY": ("Dumped after the last survey cutoff", "Not in current model; reported as pending tonnage"),
    "TIME_BEFORE_FIRST_INTERVAL": ("Dumped before the first modelled interval", "Not in model; reported"),
    "TIME_DUPLICATE": ("Same timestamp as another record", "Kept; informational (different trucks)"),
}


def source_groups(df: pd.DataFrame) -> pd.Series:
    """Label loads that share an identical (Au, Ag, Cu, Dens) tuple.

    In the supplied data only 21 distinct tuples occur in 275 loads, so the
    grades are evidently attributes of the source (dig block) rather than
    per-truck assays (INFERRED). The group id is a proxy for 'source'.
    """
    key = df[["au", "ag", "cu", "dens"]].round(6).astype(str).agg("|".join, axis=1)
    codes = {k: i for i, k in enumerate(pd.unique(key))}
    return key.map(codes).astype(int)


def surface_envelope_at_dumps(df, grid: GridSpec, rasters, interval_idx):
    """Surveyed bounds on the ground elevation at each dump, during its interval.

    If the dump cell lies in the fill solid of its own interval, the surface
    during the interval lies between that solid's base (start of interval) and
    top (end of interval). Otherwise the surface is the top of the latest
    earlier solid covering the cell (unchanged during the interval within the
    fill-only interpretation, A-009). Returns ``(lo, hi)``; NaN if unknown.
    """
    r, c = grid.index(df["x"].fillna(-1e12).values, df["y"].fillna(-1e12).values)
    lo = np.full(len(df), np.nan)
    hi = np.full(len(df), np.nan)
    for i in range(len(df)):
        k = interval_idx[i]
        if r[i] < 0 or k < 0:
            continue
        if np.isfinite(rasters[k].base[r[i], c[i]]):
            lo[i] = rasters[k].base[r[i], c[i]]
            hi[i] = rasters[k].top[r[i], c[i]]
            continue
        for j in range(k - 1, -1, -1):
            if np.isfinite(rasters[j].top[r[i], c[i]]):
                lo[i] = hi[i] = rasters[j].top[r[i], c[i]]
                break
    return lo, hi


def flag_records(df: pd.DataFrame, cfg: dict, grid: GridSpec, rasters, interval_idx) -> pd.DataFrame:
    q = cfg["qaqc"]
    out = df.copy()
    out["interval"] = interval_idx
    f = {}
    f["MISSING_PAYLOAD"] = out["payload_t"].isna()
    f["MISSING_TIME"] = out["timestamp"].isna()
    dup = out["cycle_id"].notna() & out.duplicated("cycle_id", keep="first")
    f["DUP_CONFLICT"] = dup
    f["PAYLOAD_NONPOSITIVE"] = out["payload_t"] <= 0
    f["PAYLOAD_PARTIAL"] = (out["payload_t"] > 0) & (out["payload_t"] <= q["payload_partial_t"])
    f["PAYLOAD_HIGH"] = out["payload_t"] > q["payload_nominal_max_t"]
    quantum = q["payload_quantum_t"]
    f["PAYLOAD_OFF_QUANTUM"] = out["payload_t"].notna() & (np.abs(out["payload_t"] / quantum - np.round(out["payload_t"] / quantum)) > 1e-6)
    f["GRADE_MISSING"] = out["cu"].isna() | out["au"].isna()
    bad = np.zeros(len(out), bool)
    for col, key in (("cu", "cu_range"), ("au", "au_range"), ("ag", "ag_range")):
        lo, hi = q[key]
        bad |= out[col].notna() & ((out[col] < lo) | (out[col] > hi))
    f["GRADE_INVALID"] = pd.Series(bad, index=out.index)
    lo, hi = q["dens_range"]
    f["DENS_INVALID"] = out["dens"].isna() | (out["dens"] < lo) | (out["dens"] > hi)
    f["LOC_MISSING"] = out["x"].isna() | out["y"].isna()
    r, c = grid.index(out["x"].fillna(-1e12).values, out["y"].fillna(-1e12).values)
    f["LOC_OUTSIDE_DOMAIN"] = pd.Series((r < 0) & ~f["LOC_MISSING"].values, index=out.index)
    xyz = out[["x", "y", "z"]].round(3).astype(str).agg("|".join, axis=1)
    f["LOC_DEFAULT"] = (out.groupby(xyz)["x"].transform("size") >= q["default_location_min_repeats"]) & ~f["LOC_MISSING"]
    lo, hi = surface_envelope_at_dumps(out, grid, rasters, np.asarray(interval_idx))
    out["z_surface_lo"] = lo
    out["z_surface_hi"] = hi
    # signed distance of dump Z outside the [lo, hi] surface envelope (0 inside)
    zv = out["z"].values
    out["dz_surface"] = np.where(zv < lo, zv - lo, np.where(zv > hi, zv - hi, 0.0))
    out.loc[np.isnan(lo) | np.isnan(zv), "dz_surface"] = np.nan
    f["LOC_Z_INCONSISTENT"] = pd.Series(np.abs(out["dz_surface"].values) > q["z_tolerance_m"], index=out.index)
    union = np.zeros((grid.ny, grid.nx), bool)
    for ras in rasters:
        union |= ras.mask
    inside = np.zeros(len(out), bool)
    ok = r >= 0
    inside[ok] = union[r[ok], c[ok]]
    f["LOC_OUTSIDE_SURVEYS"] = pd.Series(~inside & ok, index=out.index)
    f["TIME_AFTER_LAST_SURVEY"] = pd.Series(np.asarray(interval_idx) == AFTER_LAST, index=out.index)
    f["TIME_BEFORE_FIRST_INTERVAL"] = pd.Series(np.asarray(interval_idx) == BEFORE_FIRST, index=out.index)
    f["TIME_DUPLICATE"] = out["timestamp"].notna() & out["timestamp"].duplicated(keep=False)

    for k, v in f.items():
        out[f"qa_{k}"] = v.fillna(False).astype(bool).values
    flag_cols = [f"qa_{k}" for k in RULES]
    out["qa_flags"] = out[flag_cols].apply(lambda row: ";".join(k[3:] for k, v in row.items() if v), axis=1)
    out["use_in_model"] = ~(out["qa_MISSING_PAYLOAD"] | out["qa_MISSING_TIME"] | out["qa_DUP_CONFLICT"]
                            | out["qa_PAYLOAD_NONPOSITIVE"] | out["qa_TIME_AFTER_LAST_SURVEY"]
                            | out["qa_TIME_BEFORE_FIRST_INTERVAL"])
    out["use_location"] = ~(out["qa_LOC_MISSING"] | out["qa_LOC_OUTSIDE_DOMAIN"] | out["qa_LOC_DEFAULT"])
    out["use_grade"] = ~(out["qa_GRADE_MISSING"] | out["qa_GRADE_INVALID"])
    out["source_group"] = source_groups(out)
    return out


def rules_table() -> pd.DataFrame:
    return pd.DataFrame([(k, v[0], v[1]) for k, v in RULES.items()], columns=["rule", "meaning", "model_action"])


def flag_summary(flagged: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for k, (meaning, action) in RULES.items():
        m = flagged[f"qa_{k}"]
        rows.append(dict(rule=k, n_records=int(m.sum()), tonnes=float(flagged.loc[m, "payload_t"].sum()),
                         meaning=meaning, model_action=action))
    return pd.DataFrame(rows)
