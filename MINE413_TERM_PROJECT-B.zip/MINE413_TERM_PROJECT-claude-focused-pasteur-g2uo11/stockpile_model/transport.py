"""Entropic optimal transport used to allocate supplies to surveyed fill cells.

Problem (Methodology §5.2): supplies i (volumes a_i) must exactly fill sink
cells p (capacities b_p), sum a = sum b. With cost C_ip (m) and entropic
regularisation eps (m), the plan

    pi = argmin  <C, pi> + eps * KL(pi | a b^T)   s.t.  pi 1 = a,  pi^T 1 = b

is computed by log-domain Sinkhorn iterations. ``eps`` is a *mixing length*:
eps -> 0 gives the minimum-total-push (sharp) allocation; larger eps spreads
each load over more cells (more mixing between loads; A-021).

The returned plan satisfies both marginals to ``tol`` (relative); a final
exact column rescaling makes cell capacities exact, and row sums are checked.
"""

from __future__ import annotations

import numpy as np
from scipy.special import logsumexp


def sinkhorn_log(a: np.ndarray, b: np.ndarray, C: np.ndarray, eps: float, tol: float = 1e-10,
                 max_iter: int = 20000) -> tuple[np.ndarray, dict]:
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    if a.min() < 0 or b.min() < 0:
        raise ValueError("negative marginals")
    sa, sb = a.sum(), b.sum()
    if not np.isclose(sa, sb, rtol=1e-9):
        raise ValueError(f"unbalanced marginals: {sa} vs {sb}")
    ia, ib = a > 0, b > 0
    A, B, Cs = a[ia] / sa, b[ib] / sa, C[np.ix_(ia, ib)]
    la, lb = np.log(A), np.log(B)
    f = np.zeros(len(A))
    g = np.zeros(len(B))
    M = -Cs / eps
    err = np.inf
    it = 0
    for it in range(1, max_iter + 1):
        f = eps * (la - logsumexp(M + g[None, :] / eps, axis=1))
        g = eps * (lb - logsumexp(M + f[:, None] / eps, axis=0))
        if it % 10 == 0:
            row = np.exp(logsumexp(M + (f[:, None] + g[None, :]) / eps, axis=1))
            err = np.abs(row - A).max() / A.max()
            if err < tol:
                break
    P = np.exp(M + (f[:, None] + g[None, :]) / eps)
    P *= (B / P.sum(axis=0))[None, :]          # exact column (capacity) marginals
    plan = np.zeros((len(a), len(b)))
    plan[np.ix_(ia, ib)] = P * sa
    info = dict(iterations=it, row_rel_error=float(np.abs(plan.sum(axis=1) - a).max() / max(a.max(), 1e-300)),
                col_rel_error=float(np.abs(plan.sum(axis=0) - b).max() / max(b.max(), 1e-300)),
                transport_cost=float((plan * C).sum() / sa))
    return plan, info


def sparsify(plan: np.ndarray, a: np.ndarray, b: np.ndarray, rel: float = 0.01, row_cover: float = 0.999,
             n_ipf: int = 5000, tol: float = 1e-12) -> tuple[np.ndarray, dict]:
    """Reduce the plan to a sparse support while conserving supplies exactly.

    Support = entries >= ``rel`` of their cell's capacity (cell-significant)
    UNION each supply's largest entries covering ``row_cover`` of its volume
    (supply-significant, so every supply can still place all its volume).
    Iterative proportional fitting then restores the marginals on the
    support, ending with a row scaling: supply totals (hence mass and metal)
    are exact to rounding; any residual appears only as a small cell-capacity
    (geometry) error, which is reported.
    """
    keep = plan >= rel * b[None, :]
    keep[np.argmax(plan, axis=0), np.arange(plan.shape[1])] = True
    order = np.argsort(-plan, axis=1)
    srt = np.take_along_axis(plan, order, axis=1)
    cum = np.cumsum(srt, axis=1)
    need = cum - srt < row_cover * a[:, None]          # entries until cover is reached
    rows = np.repeat(np.arange(plan.shape[0]), plan.shape[1]).reshape(plan.shape)
    keep[rows[need], order[need]] = True
    keep &= plan > 0
    P = np.where(keep, plan, 0.0)
    dropped = float(plan.sum() - P.sum())
    it = 0
    for it in range(1, n_ipf + 1):
        cs = P.sum(axis=0)
        P *= np.divide(b, cs, out=np.ones_like(b), where=cs > 0)[None, :]
        rs = P.sum(axis=1)
        P *= np.divide(a, rs, out=np.ones_like(a), where=rs > 0)[:, None]
        if np.abs(P.sum(axis=0) - b).max() <= tol * b.max():
            break
    info = dict(nnz=int((P > 0).sum()), dropped_before_ipf=dropped, ipf_iterations=it,
                row_rel_error=float(np.abs(P.sum(axis=1) - a).max() / a.max()),
                col_rel_error=float(np.abs(P.sum(axis=0) - b).max() / b.max()))
    return P, info
