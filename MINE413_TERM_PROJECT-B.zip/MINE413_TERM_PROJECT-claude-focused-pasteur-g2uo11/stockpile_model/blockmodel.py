"""3D block model built by exact integration of the layered column state.

Each layer (1 m column cell, z_bot..z_top, extensive components) is split
over the block z-slices it intersects, in proportion to the overlapping
thickness (material assumed uniform within a layer, A-025), and summed into
regular blocks of ``dx x dy x dz``. Because every component is extensive,
block totals sum exactly to the layer totals (checked).

Partial blocks: blocks are not sub-blocked; each block carries the material
volume it contains and ``fill_fraction = volume / block volume``. Grades are
tonnage-weighted over the material actually present, so partial blocks are
not diluted with air (A-028).
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from .movement import CI, COMP

TROY_OZ_G = 31.1034768


def integrate_layers(layers, model_grid, dx: float, dy: float, dz: float, z0: float):
    """Return (block keys (n,3) int, component sums (n, len(COMP)))."""
    fx = int(round(dx / model_grid.cell))
    fy = int(round(dy / model_grid.cell))
    if not np.isclose(fx * model_grid.cell, dx) or not np.isclose(fy * model_grid.cell, dy):
        raise ValueError("block plan size must be a multiple of the model cell")
    r, c = np.unravel_index(layers.cell, (model_grid.ny, model_grid.nx))
    bx, by = c // fx, r // fy
    zb, zt = layers.z_bot, layers.z_top
    thick = zt - zb
    k0 = np.floor((zb - z0) / dz).astype(int)
    k1 = np.floor((zt - z0 - 1e-12) / dz).astype(int)
    if (k0 < 0).any():
        raise ValueError("material below block-model base elevation z0")
    nspan = k1 - k0 + 1
    rep = np.repeat(np.arange(len(zb)), nspan)
    kk = k0[rep] + (np.arange(len(rep)) - np.repeat(np.cumsum(nspan) - nspan, nspan))
    lo = np.maximum(zb[rep], z0 + kk * dz)
    hi = np.minimum(zt[rep], z0 + (kk + 1) * dz)
    frac = np.divide(hi - lo, thick[rep], out=np.ones_like(lo), where=thick[rep] > 0)
    vals = layers.comp[rep] * frac[:, None]
    keys = np.c_[bx[rep], by[rep], kk]
    uk, inv = np.unique(keys, axis=0, return_inverse=True)
    sums = np.zeros((len(uk), vals.shape[1]))
    np.add.at(sums, inv.ravel(), vals)
    return uk, sums


def build_block_model(layers, model_grid, cfg_bm: dict) -> pd.DataFrame:
    dx, dy, dz, z0 = cfg_bm["dx"], cfg_bm["dy"], cfg_bm["dz"], cfg_bm["z0"]
    keys, S = integrate_layers(layers, model_grid, dx, dy, dz, z0)
    g = lambda name: S[:, CI[name]]  # noqa: E731
    mass = g("mass")
    vol = g("vol")
    bm = pd.DataFrame({
        "ix": keys[:, 0], "iy": keys[:, 1], "iz": keys[:, 2],
        "xc": model_grid.x_min + (keys[:, 0] + 0.5) * dx,
        "yc": model_grid.y_min + (keys[:, 1] + 0.5) * dy,
        "zc": z0 + (keys[:, 2] + 0.5) * dz,
        "volume_m3": vol,
        "fill_fraction": vol / (dx * dy * dz),
        "tonnes": mass,
    })
    keep = (vol > 1e-6) & (mass > 1e-9)
    bm, S = bm[keep].reset_index(drop=True), S[keep]
    mass = S[:, CI["mass"]]
    with np.errstate(invalid="ignore", divide="ignore"):
        bm["density_t_m3"] = mass / S[:, CI["vol"]]
        cu_t = S[:, CI["cu_t_rec"]] + S[:, CI["cu_t_asm"]]
        au_g = S[:, CI["au_g_rec"]] + S[:, CI["au_g_asm"]]
        ag_g = S[:, CI["ag_g_rec"]] + S[:, CI["ag_g_asm"]]
        bm["cu_pct"] = 100 * cu_t / mass
        bm["au_gpt"] = au_g / mass
        bm["ag_gpt"] = ag_g / mass
        bm["cu_t"] = cu_t
        bm["au_g"] = au_g
        bm["au_oz"] = au_g / TROY_OZ_G
        bm["ag_g"] = ag_g
        bm["cu_t_recorded"] = S[:, CI["cu_t_rec"]]
        bm["au_g_recorded"] = S[:, CI["au_g_rec"]]
        bm["cu_t_assumed"] = S[:, CI["cu_t_asm"]]
        bm["au_g_assumed"] = S[:, CI["au_g_asm"]]
        bm["tonnes_recorded"] = S[:, CI["mass_fms"]]
        bm["tonnes_unrecorded"] = S[:, CI["mass_unk"]]
        bm["tonnes_premodel"] = S[:, CI["mass_pre"]]
        bm["tonnes_location_unknown"] = S[:, CI["mass_locunk"]]
        bm["tonnes_rehandled"] = S[:, CI["mass_rehandled"]]
        # data-quality / uncertainty indicators
        bm["frac_recorded"] = S[:, CI["mass_fms"]] / mass
        bm["frac_trusted"] = (S[:, CI["mass_fms"]] - S[:, CI["mass_locunk"]]) / mass
        bm["frac_assumed_grade"] = (S[:, CI["mass_unk"]] + S[:, CI["mass_pre"]]) / mass
        bm["cu_mix_sd"] = np.sqrt(np.clip(S[:, CI["m_cu2"]] / mass - bm["cu_pct"] ** 2, 0, None))
        bm["au_mix_sd"] = np.sqrt(np.clip(S[:, CI["m_au2"]] / mass - bm["au_gpt"] ** 2, 0, None))
        trusted_mass = S[:, CI["mass"]] - S[:, CI["mass_unk"]] - S[:, CI["mass_locunk"]] - S[:, CI["mass_pre"]]
        bm["travel_m"] = np.where(trusted_mass > 1e-9, S[:, CI["m_travel"]] / np.maximum(trusted_mass, 1e-12), np.nan)
        bm["mean_day"] = S[:, CI["m_day"]] / np.maximum(mass - S[:, CI["mass_pre"]], 1e-12)
    bm["confidence"] = classify(bm, cfg_bm["confidence"])
    return bm


def classify(bm: pd.DataFrame, rules: dict) -> pd.Series:
    """Provisional confidence class from data-provenance indicators (A-029).

    HIGH   : recorded & location-trusted share >= high_trusted and travel <= high_travel_m
    MEDIUM : recorded share >= medium_recorded and travel <= medium_travel_m (or no trusted mass)
    LOW    : otherwise (dominated by unrecorded / location-unknown material or long travel)
    Phase 5 refines this with Monte-Carlo grade/tonnage dispersion.
    """
    tr = bm["travel_m"].fillna(np.inf)
    high = (bm["frac_trusted"] >= rules["high_trusted"]) & (tr <= rules["high_travel_m"])
    med = (bm["frac_recorded"] >= rules["medium_recorded"]) & (tr <= rules["medium_travel_m"])
    return pd.Series(np.where(high, "HIGH", np.where(med, "MEDIUM", "LOW")), index=bm.index)


def check_totals(bm: pd.DataFrame, layers) -> dict:
    tot = layers.totals()
    return dict(
        volume_err=float(bm.volume_m3.sum() - tot[CI["vol"]]),
        tonnes_err=float(bm.tonnes.sum() - tot[CI["mass"]]),
        cu_err=float(bm.cu_t.sum() - tot[CI["cu_t_rec"]] - tot[CI["cu_t_asm"]]),
        au_err=float(bm.au_g.sum() - tot[CI["au_g_rec"]] - tot[CI["au_g_asm"]]),
        recorded_tonnes_err=float(bm.tonnes_recorded.sum() - tot[CI["mass_fms"]]),
    )


def inventory(bm: pd.DataFrame, by: str | None = None) -> pd.DataFrame:
    def agg(d):
        t = d.tonnes.sum()
        return pd.Series(dict(
            blocks=len(d), volume_m3=d.volume_m3.sum(), tonnes=t,
            tonnes_recorded=d.tonnes_recorded.sum(), tonnes_unrecorded=d.tonnes_unrecorded.sum(),
            cu_pct=100 * d.cu_t.sum() / t, au_gpt=d.au_g.sum() / t, ag_gpt=d.ag_g.sum() / t,
            cu_t=d.cu_t.sum(), cu_t_recorded=d.cu_t_recorded.sum(), cu_t_assumed=d.cu_t_assumed.sum(),
            au_oz=d.au_oz.sum(), au_g_recorded=d.au_g_recorded.sum(), au_g_assumed=d.au_g_assumed.sum()))
    if by is None:
        return agg(bm).to_frame("total").T
    return bm.groupby(by).apply(agg, include_groups=False)


def grade_tonnage(bm: pd.DataFrame, grade: str, cutoffs) -> pd.DataFrame:
    rows = []
    for c in cutoffs:
        d = bm[bm[grade] >= c]
        t = d.tonnes.sum()
        rows.append(dict(cutoff=c, tonnes=t, cu_pct=100 * d.cu_t.sum() / t if t else np.nan,
                         au_gpt=d.au_g.sum() / t if t else np.nan, cu_t=d.cu_t.sum(), au_oz=d.au_oz.sum()))
    return pd.DataFrame(rows)


def write_vtk(bm: pd.DataFrame, path, dx, dy, dz, x0, y0, z0, fields):
    """Legacy VTK STRUCTURED_POINTS file (open in ParaView); empty blocks = NaN."""
    nx, ny, nz = bm.ix.max() + 1, bm.iy.max() + 1, bm.iz.max() + 1
    idx = (bm.iz.values * ny + bm.iy.values) * nx + bm.ix.values
    with open(path, "w") as fh:
        fh.write("# vtk DataFile Version 3.0\nStockpile block model (MODEL-GENERATED)\nASCII\nDATASET STRUCTURED_POINTS\n")
        fh.write(f"DIMENSIONS {nx + 1} {ny + 1} {nz + 1}\nORIGIN {x0} {y0} {z0}\nSPACING {dx} {dy} {dz}\n")
        fh.write(f"CELL_DATA {nx * ny * nz}\n")
        for f in fields:
            arr = np.full(nx * ny * nz, np.nan)
            vals = bm[f].values
            if vals.dtype == object:
                continue
            arr[idx] = vals
            fh.write(f"SCALARS {f} float 1\nLOOKUP_TABLE default\n")
            np.savetxt(fh, arr.reshape(-1, 1), fmt="%.6g")
