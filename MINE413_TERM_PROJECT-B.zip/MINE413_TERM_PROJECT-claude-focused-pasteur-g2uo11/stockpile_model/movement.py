"""Material-movement algorithm: survey-constrained allocation of loads.

For each interval k (Methodology §5):

1. **Initial placement (A).** Each recorded load (or load fraction released
   from the pad buffer by the reconciliation, `reconcile.py`) is a supply of
   known volume, mass and metal at its reported dump point.
2. **Direction and distance (B, C).** The dozer pushes it the shortest way to
   the active face of the surface at the start of the interval (nearest cell
   with slope >= ``face_slope_deg``, calibrated; A-019). This *release point*
   and the push distance are recorded.
3. **Downslope behaviour (D).** From the release point the material can end
   anywhere in the interval's surveyed fill; the cost of reaching fill cell p
   is the plan distance |p - release|. Gravity is represented by the survey
   geometry itself (the fill is where material came to rest) and, for
   validation, by the forward model in `physics.py`.
4. **Surface reconciliation and mixing (E, F).** Entropic optimal transport
   allocates supply volumes to fill-cell capacities exactly (both marginals),
   with mixing length ``eps`` (A-021). Supplies without a trusted location
   (fallback coordinate, UNK) have a flat cost and take the remaining space.
5. **Elevation decreases.** Cells where a cut is revealed lose the top of
   their column first; the removed material (with its tracked composition)
   becomes a *rehandle* supply of the same interval (A-013, A-024).
6. **Vertical order.** Within a cell, contributions are stacked by time
   (dump time; rehandle at interval start; UNK at mid-interval).
7. **Conservation (G, H).** All quantities are carried as extensive
   components (volume, mass, metal, ...); allocation only splits them, so
   totals are conserved to floating-point precision and checked every
   interval.
8. **Sequential updating (I).** The layered column state after interval k is
   the initial condition of interval k+1.
"""

from __future__ import annotations

import dataclasses

import numpy as np
import pandas as pd
from scipy.ndimage import label

from . import physics
from .io_survey import GridSpec
from .transport import sinkhorn_log, sparsify

COMP = ["vol", "mass", "mass_fms", "mass_unk", "mass_pre", "mass_locunk", "mass_rehandled",
        "cu_t_rec", "au_g_rec", "ag_g_rec", "cu_t_asm", "au_g_asm", "ag_g_asm",
        "m_cu2", "m_au2", "m_travel", "m_day"]
CI = {c: i for i, c in enumerate(COMP)}


def comp_vector(**kw) -> np.ndarray:
    v = np.zeros(len(COMP))
    for k, x in kw.items():
        v[CI[k]] = x
    return v


@dataclasses.dataclass
class Layers:
    """Flat layer table: one row = one supply's material in one model cell."""
    cell: np.ndarray       # flat model-cell index
    interval: np.ndarray   # interval in which placed
    sid: np.ndarray        # supply id (index into supplies table)
    z_bot: np.ndarray
    z_top: np.ndarray
    comp: np.ndarray       # (n, len(COMP)) extensive quantities

    @classmethod
    def empty(cls):
        return cls(np.zeros(0, int), np.zeros(0, int), np.zeros(0, int), np.zeros(0), np.zeros(0),
                   np.zeros((0, len(COMP))))

    def append(self, other: "Layers"):
        for f in ("cell", "interval", "sid", "z_bot", "z_top"):
            setattr(self, f, np.concatenate([getattr(self, f), getattr(other, f)]))
        self.comp = np.vstack([self.comp, other.comp])

    def keep(self, m: np.ndarray):
        for f in ("cell", "interval", "sid", "z_bot", "z_top", "comp"):
            setattr(self, f, getattr(self, f)[m])

    def totals(self) -> np.ndarray:
        return self.comp.sum(axis=0)


@dataclasses.dataclass
class ModelGeometry:
    """Per-interval geometry aggregated from 0.5 m rasters to model cells."""
    grid: GridSpec
    z_pre: np.ndarray            # (ny, nx) pre-model surface (NaN = never covered)
    sink: list                   # per interval (ny, nx) volume to place [m3]
    cut: list                    # per interval (ny, nx) revealed cut volume [m3]


def model_geometry(hist, rasters, grid: GridSpec, factor: int) -> ModelGeometry:
    g = physics.coarse_grid(grid, factor)
    a = grid.cell_area
    z_pre = physics.block_mean(hist.z_pre, factor)
    sink = [physics.block_sum(r.thickness + m, factor) * a for r, m in zip(rasters, hist.missfill)]
    cut = [physics.block_sum(c, factor) * a for c in hist.cut]
    return ModelGeometry(g, z_pre, sink, cut)


def rehandle_supplies(layers: Layers, cut_vol: np.ndarray, col_top: np.ndarray, z_pre: np.ndarray,
                      grid: GridSpec, pre_density: float, pre_grade: dict, k: int, day: float):
    """Remove ``cut_vol`` from the top of each column; return supplies per cluster.

    Material below the modelled layers is pre-model stockpile (PRE) with an
    assumed density and grade (A-024). Mutates ``layers``, ``col_top``,
    ``z_pre``.
    """
    a = grid.cell_area
    cut_cells = np.flatnonzero(cut_vol.ravel() > 1e-9)
    if cut_cells.size == 0:
        return []
    removed = {}
    zc = col_top.ravel() - cut_vol.ravel() / a       # new column top
    for p in cut_cells:
        rows = np.flatnonzero((layers.cell == p) & (layers.z_top > zc[p] + 1e-12))
        acc = np.zeros(len(COMP))
        for i in rows:
            zb, zt = layers.z_bot[i], layers.z_top[i]
            frac = (zt - max(zb, zc[p])) / (zt - zb) if zt > zb else 1.0
            acc += frac * layers.comp[i]
            layers.comp[i] *= (1 - frac)
            layers.z_top[i] = max(zb, zc[p])
        zp = z_pre.ravel()[p]
        if np.isfinite(zp) and zc[p] < zp:            # cut into pre-model material
            v = (zp - zc[p]) * a
            m = v * pre_density
            acc += comp_vector(vol=v, mass=m, mass_pre=m, cu_t_asm=m * pre_grade["cu"] / 100,
                               au_g_asm=m * pre_grade["au"], ag_g_asm=m * pre_grade["ag"],
                               m_cu2=m * pre_grade["cu"] ** 2, m_au2=m * pre_grade["au"] ** 2)
            z_pre.ravel()[p] = zc[p]
        removed[p] = acc
        col_top.ravel()[p] = zc[p]
    layers.keep(layers.z_top - layers.z_bot > 1e-9)
    # one supply per connected cluster of cut cells
    lab, n = label(cut_vol > 1e-9, structure=np.ones((3, 3)))
    sup = []
    for j in range(1, n + 1):
        cells = np.flatnonzero(lab.ravel() == j)
        comp = sum(removed[p] for p in cells)
        comp[CI["mass_rehandled"]] = comp[CI["mass"]]
        r, c = np.unravel_index(cells, lab.shape)
        w = np.array([removed[p][CI["vol"]] for p in cells])
        sup.append(dict(kind="rehandle", record_id=-1, interval=k, day=day,
                        rel_r=int(round(np.average(r, weights=w))), rel_c=int(round(np.average(c, weights=w))),
                        push_m=0.0, trusted=True, comp=comp))
    return sup


def allocate_interval(supplies: list, sink_vol: np.ndarray, col_top: np.ndarray, grid: GridSpec,
                      eps: float, sparsify_rel: float):
    """Optimal-transport allocation of one interval's supplies to its sink cells."""
    cells = np.flatnonzero(sink_vol.ravel() > 1e-9)
    b = sink_vol.ravel()[cells]
    a = np.array([s["comp"][CI["vol"]] for s in supplies])
    if a.sum() <= 0:
        raise ValueError("no supply")
    b = b * (a.sum() / b.sum())                     # exact balance (difference is float noise; checked by caller)
    r, c = np.unravel_index(cells, sink_vol.shape)
    C = np.empty((len(supplies), len(cells)))
    for i, s in enumerate(supplies):
        if s["trusted"]:
            C[i] = np.hypot(r - s["rel_r"], c - s["rel_c"]) * grid.cell
        else:
            C[i] = np.nan
    finite = np.isfinite(C)
    flat = np.nanmean(C) if finite.any() else 0.0
    C[~finite] = flat                                # no spatial preference
    plan, info = sinkhorn_log(a, b, C, eps)
    P, sinfo = sparsify(plan, a, b, rel=sparsify_rel)
    info.update({f"sparse_{k}": v for k, v in sinfo.items()})
    return cells, P, C, info


def stack_layers(cells, P, C, supplies, sid0: int, col_top: np.ndarray, grid: GridSpec, k: int) -> Layers:
    a = grid.cell_area
    ii, jj = np.nonzero(P)
    vol_i = np.array([s["comp"][CI["vol"]] for s in supplies])
    day_i = np.array([s["day"] for s in supplies])
    frac = P[ii, jj] / vol_i[ii]
    comp = np.array([supplies[i]["comp"] for i in ii]) * frac[:, None]
    # travel of this move (push + distance from release point); only material whose
    # origin is known (recorded, trusted-location, not pre-model) accumulates travel,
    # added to any travel it already had (rehandled material keeps its history).
    move = np.array([supplies[i]["push_m"] if supplies[i]["kind"] == "load" else 0.0 for i in ii]) + np.where(
        np.array([supplies[i]["trusted"] for i in ii]), C[ii, jj], np.nan)
    known = comp[:, CI["mass"]] - comp[:, CI["mass_unk"]] - comp[:, CI["mass_locunk"]] - comp[:, CI["mass_pre"]]
    comp[:, CI["m_travel"]] += np.clip(known, 0, None) * np.nan_to_num(move)
    cell = cells[jj]
    order = np.lexsort((ii, day_i[ii], cell))
    cell, ii, jj, comp = cell[order], ii[order], jj[order], comp[order]
    thick = P[ii, jj] / a
    start = np.r_[0, np.flatnonzero(np.diff(cell)) + 1]
    cum = np.cumsum(thick)
    base_cum = np.repeat(cum[start] - thick[start], np.diff(np.r_[start, len(cell)]))
    z0 = col_top.ravel()[cell]
    z_bot = z0 + (cum - thick) - base_cum
    z_top = z_bot + thick
    out = Layers(cell, np.full(len(cell), k), sid0 + ii, z_bot, z_top, comp)
    last = np.r_[start[1:] - 1, len(cell) - 1]
    col_top.ravel()[cell[last]] = z_top[last]
    return out


def run_movement(inp, hist, rec, loads: pd.DataFrame, cfg: dict) -> dict:
    """Sequentially allocate every interval; return layers, supplies and checks."""
    mcfg = cfg["movement"]
    factor = int(round(mcfg["model_cell_m"] / inp.grid.cell))
    geo = model_geometry(hist, inp.rasters, inp.grid, factor)
    g = geo.grid
    z_pre = geo.z_pre.copy()
    col_top = z_pre.copy()
    L = loads.set_index("record_id")
    t0 = loads["timestamp"].min().normalize()
    to_day = lambda t: (pd.Timestamp(t) - t0).total_seconds() / 86400.0  # noqa: E731
    repose = cfg["physics"]["angle_of_repose_deg"]
    face_deg = cfg["physics"]["face_slope_deg"]

    # assumed grades for UNK (neighbouring intervals) and PRE (all recorded loads) - A-023/A-024
    def tw(df):
        t = df.payload_t.sum()
        return dict(cu=(df.payload_t * df.cu).sum() / t, au=(df.payload_t * df.au).sum() / t,
                    ag=(df.payload_t * df.ag).sum() / t)
    pre_grade = tw(loads)
    pre_density = float(rec.intervals.placed_fms_t.sum() / rec.intervals.placed_fms_m3.sum())

    layers = Layers.empty()
    sup_rows, checks, logs = [], [], []
    for k in range(len(inp.rasters)):
        Zb = physics.surface_before(inp.rasters, hist.z_pre, k)
        Zb = physics.block_mean(Zb, factor)
        # surveyed surface where known; elsewhere the modelled column top
        Zb = np.where(np.isfinite(Zb), Zb, col_top)
        face = physics.face_mask(physics.extrapolate(Zb), np.isfinite(Zb), g.cell, face_deg)
        I = rec.intervals.set_index("interval").loc[k]
        tstart = to_day(inp.intervals.loc[k, "start"])
        tmid = to_day(inp.intervals.loc[k, "start"] + (inp.intervals.loc[k, "end"] - inp.intervals.loc[k, "start"]) / 2)
        supplies = []
        # 1. rehandle (cut) supplies
        supplies += rehandle_supplies(layers, geo.cut[k], col_top, z_pre, g, pre_density, pre_grade, k, tstart)
        # 2. recorded loads placed in this interval
        P = rec.placements[rec.placements.interval_placed == k]
        trusted_idx = [i for i, rid in enumerate(P.record_id) if bool(L.loc[rid, "use_location"])]
        xs = np.array([L.loc[rid, "x"] for rid in P.record_id])
        ys = np.array([L.loc[rid, "y"] for rid in P.record_id])
        rr, cc, dd = physics.release_points(g, face, xs, ys) if len(P) else (np.array([]),) * 3
        for i, row in enumerate(P.itertuples()):
            ld = L.loc[row.record_id]
            m = row.tonnes
            trusted = i in trusted_idx and rr[i] >= 0
            comp = comp_vector(vol=row.volume_m3, mass=m, mass_fms=m, mass_locunk=0.0 if trusted else m,
                               cu_t_rec=m * ld.cu / 100, au_g_rec=m * ld.au, ag_g_rec=m * ld.ag,
                               m_cu2=m * ld.cu ** 2, m_au2=m * ld.au ** 2, m_day=m * to_day(ld.timestamp))
            supplies.append(dict(kind="load", record_id=int(row.record_id), interval=k, day=to_day(ld.timestamp),
                                 rel_r=int(rr[i]) if trusted else -1, rel_c=int(cc[i]) if trusted else -1,
                                 push_m=float(dd[i]) if trusted else np.nan, trusted=trusted, comp=comp,
                                 dump_x=float(ld.x), dump_y=float(ld.y)))
        # 3. unrecorded material
        if I.unk_m3 > 1e-9:
            lo, hi = max(k - 1, 0), k + 1
            nb = loads[(loads.interval >= lo) & (loads.interval <= hi)]
            gr = tw(nb if len(nb) else loads)
            rho = I.placed_fms_t / I.placed_fms_m3 if I.placed_fms_m3 > 0 else pre_density
            m = I.unk_m3 * rho
            comp = comp_vector(vol=I.unk_m3, mass=m, mass_unk=m, cu_t_asm=m * gr["cu"] / 100,
                               au_g_asm=m * gr["au"], ag_g_asm=m * gr["ag"], m_cu2=m * gr["cu"] ** 2,
                               m_au2=m * gr["au"] ** 2, m_day=m * tmid)
            supplies.append(dict(kind="unk", record_id=-1, interval=k, day=tmid, rel_r=-1, rel_c=-1,
                                 push_m=np.nan, trusted=False, comp=comp))
        supply_total = sum(s["comp"] for s in supplies)
        sink_total = geo.sink[k].sum()
        vol_gap = supply_total[CI["vol"]] - sink_total
        cells, Pl, C, info = allocate_interval(supplies, geo.sink[k], col_top, g, mcfg["eps_m"], mcfg["sparsify_rel"])
        sid0 = len(sup_rows)
        new = stack_layers(cells, Pl, C, supplies, sid0, col_top, g, k)
        before = layers.totals()
        layers.append(new)
        after = layers.totals()
        for s in supplies:
            sup_rows.append({k2: v for k2, v in s.items() if k2 != "comp"} | {c: s["comp"][CI[c]] for c in COMP})
        checks.append(dict(interval=k, supply_vol=supply_total[CI["vol"]], sink_vol=sink_total,
                           vol_gap_rel=vol_gap / sink_total,
                           mass_in=supply_total[CI["mass"]], mass_added_to_layers=(after - before)[CI["mass"]],
                           cu_in=supply_total[CI["cu_t_rec"]], cu_added=(after - before)[CI["cu_t_rec"]],
                           au_in=supply_total[CI["au_g_rec"]], au_added=(after - before)[CI["au_g_rec"]],
                           n_supplies=len(supplies), n_cells=len(cells), n_layers=len(new.cell),
                           **{k2: v for k2, v in info.items() if k2 in ("iterations", "row_rel_error", "col_rel_error", "transport_cost", "sparse_row_rel_error", "sparse_col_rel_error")}))
        logs.append(dict(interval=k, face_cells=int(face.sum())))
    supplies_df = pd.DataFrame(sup_rows)
    return dict(layers=layers, supplies=supplies_df, checks=pd.DataFrame(checks), geometry=geo,
                col_top=col_top, z_pre_model=z_pre, pre_grade=pre_grade, pre_density=pre_density, logs=logs)
