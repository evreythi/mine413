"""Stage 5 - validation summary, sensitivity (OAT), Monte-Carlo uncertainty."""

from __future__ import annotations

import copy
import dataclasses
from pathlib import Path

import numpy as np
import pandas as pd

from . import physics, plots, timing, uncertainty as U, validation
from .config import set_by_path
from .pipeline import Inputs, write_json
from .plots import plt
from .stage_growth import net_table
from .stage_movement import forward_items


def _with_cutoff(inp: Inputs, cfg, loads_all: pd.DataFrame):
    """Re-assign loads to intervals under a different survey cut-off (A-003)."""
    t = cfg["timing"]
    cut = timing.survey_cutoffs([s.date for s in inp.surveys], t["survey_cutoff_hours"])
    inp2 = dataclasses.replace(inp, cutoffs=cut,
                               intervals=timing.interval_table([s.name for s in inp.surveys], cut, t["first_interval_hours"]))
    L = loads_all.copy()
    L["interval"] = timing.assign_intervals(L["timestamp"], cut, t["first_interval_hours"])
    ok = L["interval"] >= 0
    return inp2, L[ok & L.use_in_model.astype(bool) | (ok & L.qa_TIME_AFTER_LAST_SURVEY)]


def run_oat(inp, hist, flagged, cfg, base_bm, log=print):
    rows = []
    base_loads = flagged[flagged.use_in_model]
    for case in U.oat_cases(cfg):
        c2, opts = U.apply_case(cfg, case)
        if case["param"] == "unk_grade":
            b = U.unk_grade_bound(base_bm, base_loads, case["value"])
            rows.append(dict(case, **{k: v for k, v in b.items()}, tonnes=base_bm.tonnes.sum(), note="analytic rescoring of UNK/PRE grade"))
            continue
        if case["param"] == "blockmodel.size":
            size = float(case["value"])
            c2 = set_by_path(cfg, "blockmodel.dx", size)
            c2 = set_by_path(c2, "blockmodel.dy", size)
            c2 = set_by_path(c2, "blockmodel.dz", 1.0 if size <= 2 else 2.0)
        inp2, loads = inp, base_loads
        if case["param"].startswith("timing."):
            inp2, loads = _with_cutoff(inp, c2, flagged)
            loads = loads[loads.interval >= 0]
        nt = net_table(inp2, loads, hist)
        f_v = None if c2["reconcile"]["f_v"] == "auto" else float(c2["reconcile"]["f_v"])
        rec, M, bm = U.run_core(inp2, hist, nt, loads, c2, f_v=f_v, carry_over=opts.get("carry_over", True))
        same_blocks = case["param"] != "blockmodel.size" or float(case["value"]) == cfg["blockmodel"]["dx"]
        rows.append(dict(case, **U.summarise(bm, rec, base_bm if same_blocks else None, loads=loads)))
        log(f"  OAT {case['param']}={case['value']}: Cu {rows[-1]['cu_t']:.1f} t")
    return pd.DataFrame(rows)


def heldout_error_maps(inp, hist, rec, loads, cfg, out_path):
    f = int(round(cfg["movement"]["model_cell_m"] / inp.grid.cell))
    g = physics.coarse_grid(inp.grid, f)
    ks = [k for k in range(len(inp.rasters)) if k > cfg["validation"]["calibration_max_interval"]]
    fig, axs = plt.subplots(3, len(ks), figsize=(4.4 * len(ks), 12), constrained_layout=True)
    rows = []
    for j, k in enumerate(ks):
        Zb = physics.block_mean(physics.surface_before(inp.rasters, hist.z_pre, k), f)
        known = np.isfinite(Zb)
        Zf = physics.extrapolate(Zb)
        face = physics.face_mask(Zf, known, g.cell, cfg["physics"]["face_slope_deg"])
        pred = physics.predict_interval_geometric(g, Zf, face, forward_items(rec, loads, k), cfg["physics"]["angle_of_repose_deg"])
        obs = physics.block_mean(inp.rasters[k].thickness + hist.missfill[k], f)
        pred = pred * (np.nansum(obs) / pred.sum())
        diff = np.where((pred > 0.01) | (obs > 0.01), pred - obs, np.nan)
        m = validation.compare(pred, obs, g)
        rows.append(dict(interval=k, **m, rmse_thickness_m=float(np.sqrt(np.nanmean(diff ** 2)))))
        vmax = np.nanpercentile(obs[obs > 0], 99)
        for i, (arr, title, cmap, lims) in enumerate((
                (np.where(obs > 0.01, obs, np.nan), f"Interval {k}: observed fill (m)", plots.SEQ, (0, vmax)),
                (np.where(pred > 0.01, pred, np.nan), "forward prediction (m)", plots.SEQ, (0, vmax)),
                (diff, f"prediction − observed (m); EMD {m['emd_m']:.1f} m", plots.DIV, (-vmax, vmax)))):
            ax = axs[i, j]
            im = ax.imshow(arr, origin="lower", extent=g.extent(), cmap=cmap, vmin=lims[0], vmax=lims[1])
            fig.colorbar(im, ax=ax, shrink=0.7)
            ax.set_title(title, loc="left", fontsize=9)
            ax.set_aspect("equal")
            ax.set_xticks([])
            ax.set_yticks([])
    fig.suptitle("Held-out forward predictions vs surveyed fill (validation; red = predicted excess, blue = missed)", x=0.01, ha="left")
    fig.savefig(out_path)
    plt.close(fig)
    return pd.DataFrame(rows)


def repose_sensitivity(inp, hist, rec, loads, cfg) -> pd.DataFrame:
    """Forward-model skill on held-out intervals vs the angle of repose (A-018)."""
    from .stage_movement import forward_validation
    rows = []
    for phi in cfg["validation"]["repose_scan_deg"]:
        c2 = set_by_path(cfg, "physics.angle_of_repose_deg", phi)
        fv = forward_validation(inp, hist, rec, loads, c2, [cfg["physics"]["face_slope_deg"]], modes=("push",))
        held = fv[fv.interval > cfg["validation"]["calibration_max_interval"]]
        cal = fv[fv.interval <= cfg["validation"]["calibration_max_interval"]]
        rows.append(dict(angle_of_repose_deg=phi, calibration_mean_emd_m=cal.emd_m.mean(), heldout_mean_emd_m=held.emd_m.mean(),
                         heldout_mean_overlap=held.overlap.mean()))
    return pd.DataFrame(rows)


def fig_tornado(oat, base, path):
    metrics = [("cu_t", "Contained Cu (t)"), ("au_oz", "Contained Au (oz)"), ("tonnes", "Tonnes")]
    fig, axs = plt.subplots(1, 3, figsize=(17, 5), constrained_layout=True)
    for ax, (m, lab) in zip(axs, metrics):
        d = oat.copy()
        d["delta_pct"] = 100 * (d[m] / base[m] - 1)
        piv = d.pivot_table(index=["param", "assumption"], columns="level", values="delta_pct")
        piv["span"] = (piv.max(axis=1) - piv.min(axis=1)).abs()
        piv = piv.sort_values("span")
        y = np.arange(len(piv))
        ax.barh(y, piv["low"], color=plots.SERIES[0], label="low setting", height=0.6)
        ax.barh(y, piv["high"], color=plots.SERIES[1], label="high setting", height=0.6, alpha=0.85)
        ax.axvline(0, color=plots.INK2, lw=0.8)
        ax.set_yticks(y, [f"{p} ({a})" for p, a in piv.index], fontsize=8)
        ax.set_xlabel(f"Change in {lab} vs base (%)")
        ax.set_title(lab, loc="left")
    axs[0].legend(loc="lower right")
    fig.suptitle("One-at-a-time sensitivity of inventory totals (MODEL-GENERATED)", x=0.01, ha="left")
    fig.savefig(path)
    plt.close(fig)


def fig_mc(mc, base, path):
    fig, axs = plt.subplots(1, 4, figsize=(18, 4), constrained_layout=True)
    for ax, (m, lab) in zip(axs, [("tonnes", "Tonnes"), ("cu_t", "Contained Cu (t)"), ("au_oz", "Contained Au (oz)"),
                                  ("cu_pct", "Mean Cu (%)")]):
        ax.hist(mc[m], bins=12, color=plots.SERIES[0], edgecolor=plots.SURFACE)
        ax.axvline(base[m], color=plots.SERIES[1], lw=1.5)
        p10, p90 = np.percentile(mc[m], [10, 90])
        ax.set_title(f"{lab}\nP10 {p10:,.1f} · P90 {p90:,.1f} (base {base[m]:,.1f})", loc="left", fontsize=9)
        ax.set_ylabel("Realisations")
    fig.suptitle(f"Monte-Carlo distribution of totals ({len(mc)} realisations; random errors only, A-030/A-031/A-008/A-014)", x=0.01, ha="left")
    fig.savefig(path)
    plt.close(fig)


def fig_block_uncertainty(bmu, x0, y0, dx, dy, path):
    nx, ny = bmu.ix.max() + 1, bmu.iy.max() + 1
    ext = (x0, x0 + nx * dx, y0, y0 + ny * dy)

    def colmap(v, w="tonnes"):
        d = bmu.assign(_w=bmu[w], _v=bmu[v] * bmu[w]).groupby(["iy", "ix"])[["_w", "_v"]].sum()
        img = np.full((ny, nx), np.nan)
        img[d.index.get_level_values(0), d.index.get_level_values(1)] = (d._v / d._w).values
        return img

    fig, axs = plt.subplots(1, 3, figsize=(19, 5.6), constrained_layout=True)
    conf_num = bmu.confidence_final.map({"LOW": 0, "MEDIUM": 1, "HIGH": 2})
    for ax, (arr, title, cmap) in zip(axs, (
            (colmap("cu_pct_sd"), "Monte-Carlo SD of block Cu % (column, t-weighted)", plots.SEQ),
            (colmap("au_gpt_sd"), "Monte-Carlo SD of block Au g/t (column, t-weighted)", plots.SEQ_ORANGE),
            (colmap("conf_num"), "Final confidence (0 LOW · 1 MEDIUM · 2 HIGH), column mean", plots.SEQ))):
        im = ax.imshow(arr, origin="lower", extent=ext, cmap=cmap)
        fig.colorbar(im, ax=ax, shrink=0.75)
        ax.set_title(title, loc="left", fontsize=9)
        ax.set_aspect("equal")
        ax.ticklabel_format(useOffset=False, style="plain")
        ax.grid(False)
    fig.savefig(path)
    plt.close(fig)
    _ = conf_num


def final_confidence(bmu: pd.DataFrame, rules: dict) -> pd.Series:
    """Provenance class (A-029) downgraded one level where MC dispersion is high (A-032)."""
    order = ["LOW", "MEDIUM", "HIGH"]
    lvl = bmu.confidence.map({c: i for i, c in enumerate(order)})
    cv_cu = bmu.cu_pct_sd / bmu.cu_pct_mean
    cv_t = bmu.tonnes_sd / bmu.tonnes_mean
    down = (cv_cu > rules["max_cu_cv"]) | (cv_t > rules["max_tonnes_cv"])
    return pd.Series(np.array(order)[np.clip(lvl - down.astype(int), 0, 2)], index=bmu.index)


def validation_table(stages: dict, held_maps: pd.DataFrame, oat: pd.DataFrame, mc: pd.DataFrame, base: dict) -> pd.DataFrame:
    g, m, b = stages["growth"]["summary"], stages["movement"]["summary"], stages["blockmodel"]["summary"]
    q = stages["qaqc"]["summary"]
    rows = [
        ("Geometry", "Forward prediction of held-out fills (EMD, intervals 5-9)", f"{m['heldout_mean_emd_m']['push']:.1f} m vs {m['heldout_mean_emd_m']['no_push']:.1f} m (no push), {m['heldout_mean_emd_m']['uniform_face']:.1f} m (uniform)", "VALIDATED (held-out survey solids)", "beats both baselines"),
        ("Geometry", "Held-out thickness RMSE of forward prediction", f"{held_maps.rmse_thickness_m.mean():.2f} m mean over intervals 5-9", "VALIDATED (held-out)", "reported"),
        ("Geometry", "Reconstructed column tops vs surveyed final surface", f"{m['column_top_minus_survey_m']['p01']:+.2f} to {m['column_top_minus_survey_m']['p99']:+.2f} m (1st-99th pct)", "CALCULATED consistency check (constrained, not validation)", "< 0.10 m"),
        ("Geometry", "Raster vs exact TIN volume", f"max {100 * g['max_raster_vs_exact_rel']:.3f} %", "CALCULATED", "< 0.1 %"),
        ("Mass balance", "Recorded tonnes in = tonnes in block model", f"{b['integration_errors']['recorded_tonnes_err']:.1e} t", "CALCULATED", "< 1e-6 t"),
        ("Mass balance", "f_v hold-out prediction of interval volume", f"mean |error| {100 * g['holdout_mean_abs_rel_error']:.1f} % (constant density: {100 * g['holdout_mean_abs_rel_error_const_density']:.1f} %)", "VALIDATED (held-out intervals)", "< 10 %"),
        ("Mass balance", "Surveyed volume not explained by FMS (UNK)", f"{g['unk_m3']:,.0f} m³ ({100 * g['unk_m3'] / g['net_m3']:.1f} % of net) in intervals {g['unk_intervals']}", "INFERRED", "reported, not hidden"),
        ("Metal balance", "Cu recorded in = out", f"{stages['movement']['summary']['conservation']['cu_t_rec'] - stages['movement']['summary']['conservation']['expected_cu_t']:.1e} t", "CALCULATED", "< 1e-6 t"),
        ("Metal balance", "Au recorded in = out", f"{stages['movement']['summary']['conservation']['au_g_rec'] - stages['movement']['summary']['conservation']['expected_au_g']:.1e} g", "CALCULATED", "< 1e-3 g"),
        ("Temporal", "Survey cut-off inferred from data", f"best Pearson at {q['cutoff_scan_best_pearson_hours']:.0f} h; used {q['cutoff_hours_used']:.0f} h", "INFERRED", "-"),
        ("Temporal", "f_v from first half vs all intervals", f"{g['calibration']['f_v_first_half_only']:.3f} vs {g['calibration']['f_v']:.3f}", "CALCULATED", "stable"),
        ("Temporal", "Face threshold chosen on intervals 0-4 only", f"{m['face_threshold_best_on_calibration_deg']:.0f}°; push beats no-push in {m['heldout_intervals_push_beats_no_push']}/{m['heldout_n']} held-out intervals", "VALIDATED (held-out)", "-"),
        ("Robustness", "Total solid volume vs raster cell size", " / ".join(f"{k}: {v:,.0f} m³" for k, v in g["volume_by_cell_m3"].items()), "CALCULATED", "< 0.1 %"),
        ("Robustness", "OAT range of contained Cu", f"{oat.cu_t.min():,.0f}-{oat.cu_t.max():,.0f} t (base {base['cu_t']:,.0f})", "MODEL-GENERATED", "reported"),
        ("Robustness", "Monte-Carlo P10-P90 contained Cu", f"{np.percentile(mc.cu_t, 10):,.0f}-{np.percentile(mc.cu_t, 90):,.0f} t", "MODEL-GENERATED", "reported"),
        ("Robustness", "Monte-Carlo P10-P90 contained Au", f"{np.percentile(mc.au_oz, 10):,.0f}-{np.percentile(mc.au_oz, 90):,.0f} oz", "MODEL-GENERATED", "reported"),
    ]
    return pd.DataFrame(rows, columns=["area", "measure", "result", "evidence", "criterion"])


def run(inp: Inputs, cfg: dict, out_dir: Path, stages: dict, flagged: pd.DataFrame, log=print) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    growth, movement, blk = stages["growth"], stages["movement"], stages["blockmodel"]
    hist, rec, loads, nt = growth["history"], growth["reconciliation"], growth["loads"], growth["net"]
    base_bm = blk["bm"]
    base = U.summarise(base_bm, rec, loads=loads)

    held = heldout_error_maps(inp, hist, rec, loads, cfg, out_dir / "fig_heldout_error_maps.png")
    held.to_csv(out_dir / "heldout_forward_metrics.csv", index=False)

    rep = repose_sensitivity(inp, hist, rec, loads, cfg)
    rep.to_csv(out_dir / "repose_sensitivity_forward_model.csv", index=False)
    oat = run_oat(inp, hist, flagged, cfg, base_bm, log=log)
    oat.to_csv(out_dir / "sensitivity_oat.csv", index=False)
    fig_tornado(oat, base, out_dir / "fig_sensitivity_tornado.png")

    ucfg = cfg["uncertainty"]
    mc, blocks = U.monte_carlo(inp, hist, nt, loads, cfg, ucfg["mc_realisations"], ucfg["mc_seed"],
                               progress=lambda i: log(f"  MC {i + 1}/{ucfg['mc_realisations']}") if (i + 1) % 10 == 0 else None)
    mc.to_csv(out_dir / "mc_totals.csv", index=False)
    fig_mc(mc, base, out_dir / "fig_mc_totals.png")

    bmu = base_bm.merge(blocks, on=["ix", "iy", "iz"], how="left")
    bmu["confidence_final"] = final_confidence(bmu, ucfg["confidence"])
    bmu["conf_num"] = bmu.confidence_final.map({"LOW": 0, "MEDIUM": 1, "HIGH": 2})
    cols = ["ix", "iy", "iz", "xc", "yc", "zc", "tonnes", "cu_pct", "au_gpt", "tonnes_mean", "tonnes_sd", "tonnes_p10", "tonnes_p90",
            "cu_pct_mean", "cu_pct_sd", "cu_pct_p10", "cu_pct_p90", "au_gpt_mean", "au_gpt_sd", "au_gpt_p10", "au_gpt_p90",
            "n_realisations", "confidence", "confidence_final"]
    bmu[cols].to_csv(out_dir / "block_uncertainty.csv", index=False, float_format="%.6g")
    g = movement["M"]["geometry"].grid
    fig_block_uncertainty(bmu, g.x_min, g.y_min, cfg["blockmodel"]["dx"], cfg["blockmodel"]["dy"],
                          out_dir / "fig_block_uncertainty.png")
    inv_final = bmu.groupby("confidence_final").agg(
        blocks=("tonnes", "size"), tonnes=("tonnes", "sum"), cu_t=("cu_t", "sum"), au_oz=("au_oz", "sum"))
    inv_final["cu_pct"] = 100 * inv_final.cu_t / inv_final.tonnes
    inv_final.to_csv(out_dir / "inventory_by_final_confidence.csv")

    # scenario: Dens is the in-pile density, payloads understated (A-014 alternative)
    f_v = rec.f_v
    scen = dict(name="A-014 alternative: Dens is in-pile density; recorded payloads understate mass",
                tonnes_recorded=float(base_bm.tonnes_recorded.sum() * f_v),
                cu_t_recorded=float(base_bm.cu_t_recorded.sum() * f_v),
                au_oz_recorded=float(base_bm.au_g_recorded.sum() * f_v / 31.1034768),
                factor=f_v)

    vt = validation_table(stages, held, oat, mc, base)
    vt.to_csv(out_dir / "validation_metrics.csv", index=False)
    summary = dict(base=base,
                   mc={m: dict(p10=float(np.percentile(mc[m], 10)), p50=float(np.percentile(mc[m], 50)),
                               p90=float(np.percentile(mc[m], 90))) for m in ["tonnes", "cu_t", "au_oz", "cu_pct", "au_gpt"]},
                   oat_cu_t_range=[float(oat.cu_t.min()), float(oat.cu_t.max())],
                   oat_au_oz_range=[float(oat.au_oz.min()), float(oat.au_oz.max())],
                   tonnes_by_final_confidence=inv_final.tonnes.round(1).to_dict(),
                   alternative_scenario=scen, heldout_mean_rmse_m=float(held.rmse_thickness_m.mean()),
                   repose_sensitivity=rep.round(3).to_dict("records"))
    write_json(out_dir / "uncertainty_summary.json", summary)
    return dict(oat=oat, mc=mc, blocks=bmu, summary=summary, validation=vt)
