"""Stage 3 - material movement: forward-model validation and survey-constrained allocation."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from . import physics, plots, validation
from .movement import CI, COMP, run_movement
from .pipeline import Inputs, write_json
from .plots import plt


# ------------------------------------------------------------ forward validation
def forward_items(rec, loads, k):
    L = loads.set_index("record_id")
    P = rec.placements[rec.placements.interval_placed == k]
    items = [(L.loc[r.record_id, "x"], L.loc[r.record_id, "y"], r.volume_m3, bool(L.loc[r.record_id, "use_location"]))
             for r in P.itertuples()]
    unk = rec.intervals.set_index("interval").loc[k, "unk_m3"]
    if unk > 0:
        items.append((np.nan, np.nan, unk, False))
    return items


def forward_validation(inp: Inputs, hist, rec, loads, cfg, face_degs, modes=("push", "no_push", "uniform_face")):
    """Predict each interval's fill without using that interval's survey.

    Inputs used for interval k: surfaces up to k-1 (plus the pre-model
    terrain), the loads placed in k and their total volume. Returns one row
    per (face threshold, interval, mode) with location-skill metrics.
    """
    f = int(round(cfg["movement"]["model_cell_m"] / inp.grid.cell))
    g = physics.coarse_grid(inp.grid, f)
    repose = cfg["physics"]["angle_of_repose_deg"]
    rows = []
    for k in range(len(inp.rasters)):
        Zb = physics.block_mean(physics.surface_before(inp.rasters, hist.z_pre, k), f)
        known = np.isfinite(Zb)
        Zf = physics.extrapolate(Zb)
        obs = physics.block_mean(inp.rasters[k].thickness + hist.missfill[k], f)
        items = forward_items(rec, loads, k)
        for face_deg in face_degs:
            face = physics.face_mask(Zf, known, g.cell, face_deg)
            for mode in modes:
                if mode != "push" and face_deg != face_degs[0] and mode != "uniform_face":
                    continue  # no_push does not depend on the face threshold
                pred = physics.predict_interval_geometric(g, Zf, face, items, repose, mode=mode)
                rows.append(dict(interval=k, face_deg=face_deg, mode=mode, **validation.compare(pred, obs, g)))
    return pd.DataFrame(rows)


def choose_face_threshold(fv: pd.DataFrame, calib_max_interval: int) -> tuple[float, pd.DataFrame]:
    push = fv[fv["mode"] == "push"]
    cal = push[push.interval <= calib_max_interval].groupby("face_deg")["emd_m"].mean()
    return float(cal.idxmin()), cal.reset_index().rename(columns={"emd_m": "calibration_mean_emd_m"})


# ------------------------------------------------------------ summaries
def load_displacement(M, inp: Inputs, loads) -> pd.DataFrame:
    """Where each recorded load ended up (mass-weighted), vs. where it was dumped."""
    L = M["layers"]
    S = M["supplies"]
    g = M["geometry"].grid
    sid_rec = S["record_id"].values
    rec_id = sid_rec[L.sid]
    is_load = (S["kind"].values[L.sid] == "load")
    r, c = np.unravel_index(L.cell, (g.ny, g.nx))
    x = g.x_min + (c + 0.5) * g.cell
    y = g.y_min + (r + 0.5) * g.cell
    z = 0.5 * (L.z_bot + L.z_top)
    m = L.comp[:, CI["mass_fms"]]
    df = pd.DataFrame(dict(record_id=rec_id[is_load], x=x[is_load], y=y[is_load], z=z[is_load], m=m[is_load]))
    df = df[df.m > 0]
    gb = df.groupby("record_id")
    out = pd.DataFrame({
        "mass_t": gb.m.sum(),
        "x_final": gb.apply(lambda d: np.average(d.x, weights=d.m), include_groups=False),
        "y_final": gb.apply(lambda d: np.average(d.y, weights=d.m), include_groups=False),
        "z_final": gb.apply(lambda d: np.average(d.z, weights=d.m), include_groups=False),
        "spread_m": gb.apply(lambda d: np.sqrt(np.average((d.x - np.average(d.x, weights=d.m)) ** 2 + (d.y - np.average(d.y, weights=d.m)) ** 2, weights=d.m)), include_groups=False),
        "n_cells": gb.size(),
    }).reset_index()
    ld = loads.set_index("record_id")[["cycle_id", "timestamp", "payload_t", "x", "y", "z", "cu", "au", "use_location", "interval"]]
    out = out.join(ld, on="record_id")
    out["horizontal_displacement_m"] = np.where(out.use_location, np.hypot(out.x_final - out.x, out.y_final - out.y), np.nan)
    out["vertical_displacement_m"] = np.where(out.use_location, out.z_final - out.z, np.nan)
    sp = S[S.kind == "load"].groupby("record_id").agg(push_m=("push_m", "mean"), intervals_placed=("interval", lambda s: ",".join(map(str, sorted(set(s))))))
    return out.join(sp, on="record_id")


def fig_forward(fv, face_used, calib_max, path):
    sub = fv[(fv.face_deg == face_used) | (fv["mode"] == "no_push")].copy()
    sub = sub.drop_duplicates(["interval", "mode"])
    piv = sub.pivot_table(index="interval", columns="mode", values="emd_m")
    fig, ax = plt.subplots(figsize=(10, 4.2))
    x = np.arange(len(piv))
    w = 0.27
    names = {"push": "Push to crest + repose (model)", "no_push": "No dozer movement", "uniform_face": "Uniform over active face"}
    for i, mode in enumerate(["push", "no_push", "uniform_face"]):
        ax.bar(x + (i - 1) * w, piv[mode], width=w, color=plots.SERIES[i], label=names[mode])
    ax.axvspan(calib_max + 0.5, len(piv) - 0.5, color=plots.GRID, alpha=0.5, lw=0)
    ax.text(calib_max + 0.6, ax.get_ylim()[1] * 0.95, "held-out intervals", color=plots.INK2, fontsize=8, va="top")
    ax.set_xticks(x, piv.index)
    ax.set_xlabel("Interval")
    ax.set_ylabel("Earth mover's distance to observed fill (m)")
    ax.set_title(f"Forward prediction of where each interval's material comes to rest (face ≥ {face_used:.0f}°)", loc="left")
    ax.legend(loc="upper left")
    fig.savefig(path)
    plt.close(fig)


def fig_displacement(disp, inp, path):
    g = inp.grid
    d = disp[disp.use_location]
    fig, axs = plt.subplots(1, 2, figsize=(15, 6), constrained_layout=True, gridspec_kw=dict(width_ratios=[1.4, 1]))
    ax = axs[0]
    ax.quiver(d.x, d.y, d.x_final - d.x, d.y_final - d.y, angles="xy", scale_units="xy", scale=1,
              width=0.0025, color=plots.SERIES[0], alpha=0.8)
    ax.scatter(d.x, d.y, s=8, color=plots.SERIES[1], label="dump point (FMS)", zorder=3)
    ax.scatter(d.x_final, d.y_final, s=8, color=plots.SERIES[0], label="mass-weighted final position (MODEL)", zorder=3)
    plots.plan_axes(ax, g, "Dump point → modelled final position, per load")
    ax.legend(loc="lower left")
    ax = axs[1]
    ax.hist(d.horizontal_displacement_m, bins=np.arange(0, 61, 2), color=plots.SERIES[0], edgecolor=plots.SURFACE)
    med = np.median(d.horizontal_displacement_m)
    ax.axvline(med, color=plots.SERIES[1], lw=1.5)
    ax.text(med + 1, ax.get_ylim()[1] * 0.9, f"median {med:.1f} m", color=plots.INK2, fontsize=8)
    ax.set_xlabel("Horizontal displacement, dump → final centroid (m)")
    ax.set_ylabel("Loads")
    ax.set_title("Modelled displacement (trusted-location loads)", loc="left")
    fig.savefig(path)
    plt.close(fig)


def section_raster(M, axis: str, coord: float, zlim=(4472, 4492), dz=0.1, value="interval"):
    """Vertical section through the layered model at x = coord (axis='x') or y = coord."""
    L = M["layers"]
    g = M["geometry"].grid
    r, c = np.unravel_index(L.cell, (g.ny, g.nx))
    if axis == "y":
        sel = r == int((coord - g.y_min) // g.cell)
        h = c[sel]
        n = g.nx
        hmin = g.x_min
    else:
        sel = c == int((coord - g.x_min) // g.cell)
        h = r[sel]
        n = g.ny
        hmin = g.y_min
    zs = np.arange(zlim[0], zlim[1], dz)
    img = np.full((len(zs), n), np.nan)
    if value == "interval":
        v = L.interval[sel].astype(float)
    else:
        mass = L.comp[sel, CI["mass"]]
        v = np.divide(L.comp[sel, CI["cu_t_rec"]] + L.comp[sel, CI["cu_t_asm"]], mass, out=np.full(mass.shape, np.nan), where=mass > 0) * 100
    zb, zt = L.z_bot[sel], L.z_top[sel]
    for hh, a, b, val in zip(h, zb, zt, v):
        i0, i1 = np.searchsorted(zs, a), np.searchsorted(zs, b)
        img[i0:i1, hh] = val
    zpre = M["z_pre_model"]
    pre_line = zpre[int((coord - g.y_min) // g.cell), :] if axis == "y" else zpre[:, int((coord - g.x_min) // g.cell)]
    return img, (hmin, hmin + n * g.cell, zlim[0], zlim[1]), pre_line, hmin + (np.arange(n) + 0.5) * g.cell


def fig_sections(M, path, y_coord=7122335.0, x_coord=511350.0):
    fig, axs = plt.subplots(2, 2, figsize=(16, 8), constrained_layout=True)
    for row, (axis, coord) in enumerate((("y", y_coord), ("x", x_coord))):
        for col, value in enumerate(("interval", "cu")):
            img, ext, pre, hc = section_raster(M, axis, coord, value=value)
            ax = axs[row, col]
            cmap = plots.SEQ_ORANGE if value == "interval" else plots.SEQ
            im = ax.imshow(img, origin="lower", extent=ext, aspect="auto", cmap=cmap, interpolation="nearest")
            ax.plot(hc, pre, color=plots.INK2, lw=1, label="pre-model surface (base of first solid)")
            filled = hc[np.isfinite(img).any(axis=0)]
            if filled.size:
                ax.set_xlim(filled.min() - 3, filled.max() + 3)
            ax.set_ylim(4473, 4492)
            ax.set_xlabel("Easting X (m)" if axis == "y" else "Northing Y (m)")
            ax.set_ylabel("Elevation (m)")
            ax.ticklabel_format(useOffset=False, style="plain")
            lab = "Interval placed" if value == "interval" else "Cu % (recorded + assumed)"
            fig.colorbar(im, ax=ax, shrink=0.8).set_label(lab)
            ax.set_title(f"Section {'Y' if axis == 'y' else 'X'} = {coord:,.0f}: {lab.lower()} (MODEL-GENERATED)", loc="left", fontsize=9)
            if row == 0 and col == 0:
                ax.legend(loc="upper right")
    fig.savefig(path)
    plt.close(fig)


def run(inp: Inputs, cfg: dict, out_dir: Path, growth: dict) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    hist, rec, loads = growth["history"], growth["reconciliation"], growth["loads"]
    vcfg = cfg["validation"]
    fv = forward_validation(inp, hist, rec, loads, cfg, vcfg["face_slope_scan_deg"])
    face_best, cal_tab = choose_face_threshold(fv, vcfg["calibration_max_interval"])
    fv.to_csv(out_dir / "forward_validation.csv", index=False)
    cal_tab.to_csv(out_dir / "face_threshold_calibration.csv", index=False)
    face_used = cfg["physics"]["face_slope_deg"]
    fig_forward(fv, face_used, vcfg["calibration_max_interval"], out_dir / "fig_forward_validation.png")

    M = run_movement(inp, hist, rec, loads, cfg)
    M["checks"].to_csv(out_dir / "allocation_checks.csv", index=False)
    M["supplies"].to_csv(out_dir / "supplies.csv", index=False)
    disp = load_displacement(M, inp, loads)
    disp.to_csv(out_dir / "load_final_positions.csv", index=False)
    fig_displacement(disp, inp, out_dir / "fig_load_displacement.png")
    fig_sections(M, out_dir / "fig_sections.png")

    L = M["layers"]
    tot = L.totals()
    exp_cu = float((loads.payload_t * loads.cu / 100).sum())
    exp_au = float((loads.payload_t * loads.au).sum())
    zf = physics.block_mean(hist.z_final, int(round(cfg["movement"]["model_cell_m"] / inp.grid.cell)))
    ok = np.isfinite(zf) & np.isfinite(M["col_top"])
    top_err = (M["col_top"] - zf)[ok]
    held = fv[(fv.interval > vcfg["calibration_max_interval"])]
    hp = held[(held["mode"] == "push") & (held.face_deg == face_used)].set_index("interval").emd_m
    hn = held[held["mode"] == "no_push"].drop_duplicates("interval").set_index("interval").emd_m
    hu = held[(held["mode"] == "uniform_face") & (held.face_deg == face_used)].set_index("interval").emd_m
    summary = dict(
        face_threshold_used_deg=face_used, face_threshold_best_on_calibration_deg=face_best,
        heldout_mean_emd_m=dict(push=float(hp.mean()), no_push=float(hn.mean()), uniform_face=float(hu.mean())),
        heldout_intervals_push_beats_no_push=int((hp < hn.reindex(hp.index)).sum()), heldout_n=int(len(hp)),
        conservation=dict(mass_fms_t=float(tot[CI["mass_fms"]]), expected_mass_fms_t=float(rec.placements.tonnes.sum()),
                          cu_t_rec=float(tot[CI["cu_t_rec"]]), expected_cu_t=exp_cu,
                          au_g_rec=float(tot[CI["au_g_rec"]]), expected_au_g=exp_au,
                          max_interval_mass_error_t=float((M["checks"].mass_in - M["checks"].mass_added_to_layers).abs().max())),
        totals={c: float(tot[CI[c]]) for c in COMP if not c.startswith("m_")},
        n_layers=int(len(L.cell)), n_model_cells=int(len(np.unique(L.cell))),
        median_horizontal_displacement_m=float(disp.horizontal_displacement_m.median()),
        p90_horizontal_displacement_m=float(disp.horizontal_displacement_m.quantile(0.9)),
        median_push_m=float(disp.push_m.median()),
        column_top_minus_survey_m=dict(p01=float(np.percentile(top_err, 1)), p99=float(np.percentile(top_err, 99)), max_abs=float(np.abs(top_err).max())),
    )
    write_json(out_dir / "movement_summary.json", summary)
    cache = out_dir.parent / ".cache"
    cache.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(cache / "layers_latest.npz", cell=L.cell, interval=L.interval, sid=L.sid,
                        z_bot=L.z_bot, z_top=L.z_top, comp=L.comp)
    return dict(M=M, forward=fv, displacement=disp, summary=summary)
