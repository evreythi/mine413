"""Stockpile reconstruction and block-modelling platform (MIN E 413 term project).

The package reconstructs the growth of a truck-dumped stockpile from sequential
topographic surveys (DXF TINs) and Fleet Management System (FMS) dump records,
allocates each truck load to the volume that appears between consecutive
surveys, and builds a 3D block model of tonnage, Cu, Au, contained metal and
uncertainty.

Every quantity produced is tagged with an evidence category (see
``stockpile_model.provenance``): MEASURED, CALCULATED, INFERRED, ASSUMED,
MODEL-GENERATED or VALIDATED.
"""

__version__ = "0.1.0"
