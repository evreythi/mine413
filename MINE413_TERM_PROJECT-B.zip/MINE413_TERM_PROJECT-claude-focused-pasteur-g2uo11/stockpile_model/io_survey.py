"""Read stockpile survey surfaces (DXF 3DFACE TINs) and rasterise them.

Survey files are AutoCAD DXF 2013 drawings containing a single layer of
``3DFACE`` entities. Every face in the supplied data is a triangle stored with
``vtx3 == vtx0`` (checked on load). Degenerate (zero plan-area) faces are
counted and dropped; they cannot contribute to a 2.5D surface.

The survey date is parsed from the file name ``Topo_YYMMDD.dxf``. The layer
name carries a second date code. The two disagree on the year for 8 of the 10
supplied files, so the year is resolved by configuration (assumption A-001)
and both raw codes are retained for traceability.
"""

from __future__ import annotations

import dataclasses
import hashlib
import re
from pathlib import Path

import numpy as np

_DATE_RE = re.compile(r"(\d{2})(\d{2})(\d{2})")


@dataclasses.dataclass
class Survey:
    """A surveyed surface as a set of triangles plus provenance metadata."""

    name: str
    path: Path
    sha256: str
    file_date_code: str          # YYMMDD from file name (MEASURED, as supplied)
    layer_date_code: str | None  # YYMMDD from layer name (MEASURED, as supplied)
    date: np.datetime64          # resolved survey date (see A-001)
    triangles: np.ndarray        # (n, 3, 3) float64, non-degenerate only
    n_faces_raw: int
    n_degenerate: int
    layer: str

    @property
    def xy_bounds(self) -> tuple[float, float, float, float]:
        xy = self.triangles[:, :, :2].reshape(-1, 2)
        return xy[:, 0].min(), xy[:, 0].max(), xy[:, 1].min(), xy[:, 1].max()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _date_code(text: str) -> str | None:
    m = _DATE_RE.search(text)
    return "".join(m.groups()) if m else None


def resolve_date(file_code: str, year_override: int | None) -> np.datetime64:
    """Convert a YYMMDD code to a date, optionally forcing the year (A-001)."""
    yy, mm, dd = int(file_code[:2]), int(file_code[2:4]), int(file_code[4:6])
    year = year_override if year_override is not None else 2000 + yy
    return np.datetime64(f"{year:04d}-{mm:02d}-{dd:02d}")


def triangle_plan_area(tri: np.ndarray) -> np.ndarray:
    """Plan (XY) area of each triangle in an (n, 3, 3) array."""
    a = tri[:, 1, :2] - tri[:, 0, :2]
    b = tri[:, 2, :2] - tri[:, 0, :2]
    return 0.5 * np.abs(a[:, 0] * b[:, 1] - a[:, 1] * b[:, 0])


def read_dxf_tin(path: str | Path, year_override: int | None = None,
                 min_plan_area: float = 1e-6) -> Survey:
    """Load a DXF of 3DFACE triangles.

    Raises ``ValueError`` if a face is a genuine quadrilateral, because the
    rasteriser below assumes triangles and silently splitting quads could hide
    a change in the survey export format.
    """
    import ezdxf  # imported lazily so unit tests of other modules need not

    path = Path(path)
    doc = ezdxf.readfile(path)
    faces = []
    layers = set()
    for e in doc.modelspace().query("3DFACE"):
        v = [tuple(e.dxf.get(f"vtx{i}")) for i in range(4)]
        if not (np.allclose(v[3], v[0]) or np.allclose(v[3], v[2])):
            raise ValueError(f"{path.name}: quadrilateral 3DFACE found; "
                             "triangle-only export expected")
        faces.append(v[:3])
        layers.add(e.dxf.layer)
    if not faces:
        raise ValueError(f"{path.name}: no 3DFACE entities")
    tri = np.asarray(faces, dtype=float)
    area = triangle_plan_area(tri)
    keep = area > min_plan_area
    layer = sorted(layers)[0] if len(layers) == 1 else "|".join(sorted(layers))
    file_code = _date_code(path.stem)
    if file_code is None:
        raise ValueError(f"{path.name}: cannot parse YYMMDD date from file name")
    return Survey(
        name=path.stem,
        path=path,
        sha256=sha256_file(path),
        file_date_code=file_code,
        layer_date_code=_date_code(layer),
        date=resolve_date(file_code, year_override),
        triangles=tri[keep],
        n_faces_raw=len(tri),
        n_degenerate=int((~keep).sum()),
        layer=layer,
    )


@dataclasses.dataclass(frozen=True)
class GridSpec:
    """Regular plan grid shared by every surface (cell-centred)."""

    x_min: float
    y_min: float
    nx: int
    ny: int
    cell: float

    @classmethod
    def from_bounds(cls, x_min, x_max, y_min, y_max, cell) -> "GridSpec":
        nx = int(round((x_max - x_min) / cell))
        ny = int(round((y_max - y_min) / cell))
        return cls(float(x_min), float(y_min), nx, ny, float(cell))

    @property
    def x_max(self) -> float:
        return self.x_min + self.nx * self.cell

    @property
    def y_max(self) -> float:
        return self.y_min + self.ny * self.cell

    @property
    def xc(self) -> np.ndarray:
        return self.x_min + (np.arange(self.nx) + 0.5) * self.cell

    @property
    def yc(self) -> np.ndarray:
        return self.y_min + (np.arange(self.ny) + 0.5) * self.cell

    @property
    def cell_area(self) -> float:
        return self.cell * self.cell

    def index(self, x, y):
        """Return (row, col) integer indices of points; -1 if outside."""
        x = np.asarray(x, float)
        y = np.asarray(y, float)
        c = np.floor((x - self.x_min) / self.cell).astype(int)
        r = np.floor((y - self.y_min) / self.cell).astype(int)
        bad = (c < 0) | (c >= self.nx) | (r < 0) | (r >= self.ny)
        return np.where(bad, -1, r), np.where(bad, -1, c)

    def extent(self):
        """matplotlib imshow extent (origin='lower')."""
        return (self.x_min, self.x_max, self.y_min, self.y_max)


def rasterise_tin(tri: np.ndarray, grid: GridSpec, eps: float = 1e-9):
    """Linear (barycentric) interpolation of a TIN onto grid cell centres.

    Returns ``(z_top, z_bot, n_hits)``: the highest and lowest surface
    elevations found at each cell centre and the number of triangles covering
    it. Cells not covered are NaN / 0. ``n_hits > 1`` with ``z_top != z_bot``
    indicates overlapping triangles (overhangs or duplicated patches) — a QA
    item, not something that occurs in a valid 2.5D surface.
    """
    z_top = np.full((grid.ny, grid.nx), -np.inf)
    z_bot = np.full((grid.ny, grid.nx), np.inf)
    hits = np.zeros((grid.ny, grid.nx), dtype=np.int32)
    xc, yc = grid.xc, grid.yc
    x0, y0, cs = grid.x_min, grid.y_min, grid.cell
    for t in tri:
        xs, ys, zs = t[:, 0], t[:, 1], t[:, 2]
        c0 = max(int(np.ceil((xs.min() - x0) / cs - 0.5)), 0)
        c1 = min(int(np.floor((xs.max() - x0) / cs - 0.5)), grid.nx - 1)
        r0 = max(int(np.ceil((ys.min() - y0) / cs - 0.5)), 0)
        r1 = min(int(np.floor((ys.max() - y0) / cs - 0.5)), grid.ny - 1)
        if c1 < c0 or r1 < r0:
            continue
        X, Y = np.meshgrid(xc[c0:c1 + 1], yc[r0:r1 + 1])
        det = (ys[1] - ys[2]) * (xs[0] - xs[2]) + (xs[2] - xs[1]) * (ys[0] - ys[2])
        if abs(det) < 1e-12:
            continue
        if det < 0:  # make counter-clockwise so edge ownership is well defined
            xs, ys, zs = xs[[0, 2, 1]], ys[[0, 2, 1]], zs[[0, 2, 1]]
            det = -det
        l0 = ((ys[1] - ys[2]) * (X - xs[2]) + (xs[2] - xs[1]) * (Y - ys[2])) / det
        l1 = ((ys[2] - ys[0]) * (X - xs[2]) + (xs[0] - xs[2]) * (Y - ys[2])) / det
        l2 = 1.0 - l0 - l1
        # Half-open rule: a point on an edge shared by two triangles of one
        # surface is owned by exactly one of them (the edge traversed with
        # dy < 0, or dy == 0 and dx > 0), so it is not counted twice.
        inside = np.ones_like(X, dtype=bool)
        for lam, (a, b) in ((l0, (1, 2)), (l1, (2, 0)), (l2, (0, 1))):
            dy, dx = ys[b] - ys[a], xs[b] - xs[a]
            owned = dy < 0 or (dy == 0 and dx > 0)
            inside &= (lam > eps) | ((lam >= -eps) & owned)
        if not inside.any():
            continue
        z = l0 * zs[0] + l1 * zs[1] + l2 * zs[2]
        sub_top = z_top[r0:r1 + 1, c0:c1 + 1]
        sub_bot = z_bot[r0:r1 + 1, c0:c1 + 1]
        sub_hit = hits[r0:r1 + 1, c0:c1 + 1]
        np.maximum(sub_top, np.where(inside, z, -np.inf), out=sub_top)
        np.minimum(sub_bot, np.where(inside, z, np.inf), out=sub_bot)
        sub_hit += inside
    z_top[hits == 0] = np.nan
    z_bot[hits == 0] = np.nan
    return z_top, z_bot, hits
