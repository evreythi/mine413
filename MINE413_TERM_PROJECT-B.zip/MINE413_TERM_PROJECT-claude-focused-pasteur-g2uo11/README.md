# Stockpile Reconstruction & Block-Model Platform (MIN E 413 Term Project)

An in-house, reproducible platform that reconstructs the growth of the Pit I
high-grade stockpile from FMS truck-dump records and sequential survey
solids, estimates where each truck load finally came to rest (dozer push +
gravity, constrained by the surveys), and builds an updatable 3D block model
of tonnage, Cu, Au, contained metal and uncertainty.

Every result is labelled **MEASURED / CALCULATED / INFERRED / ASSUMED /
MODEL-GENERATED / VALIDATED**. "VALIDATED" is used only for comparisons
against held-out survey data.

| Document | Content |
|---|---|
| [`docs/engineering_report.md`](docs/engineering_report.md) | Final engineering report to mine management (D6) |
| [`docs/methodology.md`](docs/methodology.md) | Equations, algorithms, pseudocode (D3) |
| [`docs/assumption_register.md`](docs/assumption_register.md) | Assumption Register A-001 … (Task 4, D2) |
| [`docs/data_register.md`](docs/data_register.md) | Dataset inventory, QA/QC findings, preprocessing (D2) |
| [`docs/decision_log.md`](docs/decision_log.md) | Engineering decisions and corrected errors |
| [`docs/platform_guide.md`](docs/platform_guide.md) | Operating instructions, input formats, audit trail (D5) |
| [`docs/professional_practice.md`](docs/professional_practice.md) | Accountability, ethics, equity, limitations |
| [`docs/ai_and_software_disclosure.md`](docs/ai_and_software_disclosure.md) | AI and software disclosure (§6.1) |
| [`docs/team_templates.md`](docs/team_templates.md) | Templates for the team-only deliverables (D1, D7–D9) |

## Quick start

```bash
pip install -r requirements.txt
python -m stockpile_model ingest "Data_Topo 2026.zip"   # copy inputs into data/raw (SHA-256 logged)
python -m stockpile_model run                            # all stages -> outputs/ (~13 min with 60 MC realisations; --mc 5 for a quick run)
python -m stockpile_model report                         # fill docs/engineering_report.md from the run outputs
python -m stockpile_model status                         # data inventory and last runs
python -m pytest -q                                      # unit, real-data and platform tests
```

## What a run produces

| Folder | Stage | Key outputs |
|---|---|---|
| `outputs/01_qaqc/` | Data QA/QC | flagged FMS register (`fms_flagged.csv`), rule catalogue, survey closure/stacking checks, cut-off scan, figures |
| `outputs/02_growth/` | Growth & reconciliation | interval volume budget, f_v calibration + hold-out, load placement schedule, face slopes, figures |
| `outputs/03_movement/` | Material movement | forward-model validation, allocation conservation checks, per-load final positions, sections |
| `outputs/04_blockmodel/` | Block model | `block_model.csv`, `block_model_minesoftware.csv`, `block_model.vtk`, attribute dictionary, inventories, grade–tonnage |
| `outputs/05_uncertainty/` | Validation & uncertainty | validation metrics, OAT sensitivity, Monte-Carlo totals, per-block P10/P90 and final confidence |
| `outputs/run_manifest.json`, `run_history.csv`, `history/`, `change_report.txt` | Audit | inputs + hashes, code version, config, interventions, results of every run |

## Repository layout

| Path | Content |
|---|---|
| `stockpile_model/` | platform source code (see module docstrings) |
| `config/default.toml` | all parameters, each citing its assumption ID |
| `config/manual_interventions.csv` | the only supported way to override data (reason, author, date required) |
| `data/raw/` | managed raw-data store, created by `ingest` (not committed) |
| `tests/` | pytest suite |
