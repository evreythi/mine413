"""Phase 6: platform behaviour - ingest, incremental update, audit trail, interventions.

Uses the real project files, split into an 'earlier' and a 'later' delivery,
to demonstrate that the platform updates the model when new surveys arrive.
"""

import json
import zipfile

import pandas as pd
import pytest

from tests.conftest import DATA_ZIP


def _extract(names, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(DATA_ZIP) as zf:
        for info in zf.infolist():
            base = info.filename.split("/")[-1]
            if base in names:
                (dest / base).write_bytes(zf.read(info))
    return dest


@pytest.fixture(scope="module")
def platform_run(tmp_path_factory):
    if not DATA_ZIP.exists():
        pytest.skip("project data zip not present")
    from stockpile_model.__main__ import main
    tmp = tmp_path_factory.mktemp("platform")
    with zipfile.ZipFile(DATA_ZIP) as zf:
        all_names = [i.filename.split("/")[-1] for i in zf.infolist() if not i.is_dir()]
    surveys = sorted((n for n in all_names if n.endswith(".dxf")), key=lambda n: n[-8:-4])
    first, later = ["Dump Data.csv"] + surveys[:7], surveys[7:]
    cfg = tmp / "cfg.toml"
    cfg.write_text(f'[data]\nraw_dir = "{tmp / "raw"}"\ninterventions_file = "{tmp / "iv.csv"}"\n'
                   '[validation]\nface_slope_scan_deg = [33.0]\n')
    (tmp / "iv.csv").write_text("id,type,cycle_id,reason,author,date\n"
                                "MI-001,location_unknown,664604,test: position disputed by surveyor,QA tester,2026-10-07\n")
    out = tmp / "out"
    stages = "qaqc,growth,movement,blockmodel"
    assert main(["ingest", str(_extract(first, tmp / "d1")), "--config", str(cfg)]) == 0
    assert main(["run", "--config", str(cfg), "--out", str(out), "--stages", stages]) == 0
    first_summary = json.loads((out / "04_blockmodel" / "blockmodel_summary.json").read_text())
    assert main(["ingest", str(_extract(later, tmp / "d2")), "--config", str(cfg)]) == 0
    assert main(["run", "--config", str(cfg), "--out", str(out), "--stages", stages]) == 0
    return dict(tmp=tmp, out=out, first=first_summary,
                second=json.loads((out / "04_blockmodel" / "blockmodel_summary.json").read_text()))


def test_incremental_update_places_previously_pending_loads(platform_run):
    a, b = platform_run["first"], platform_run["second"]
    # with 7 surveys (to 22 Mar) all later loads are pending; after the update only the 31 Mar load is
    assert a["pending_after_last_survey_t"] > 10000
    assert b["pending_after_last_survey_t"] == pytest.approx(228.0)
    assert b["tonnes"] > a["tonnes"]


def test_history_manifest_and_change_report(platform_run):
    out = platform_run["out"]
    hist = pd.read_csv(out / "run_history.csv")
    assert len(hist) == 2 and hist.n_surveys.tolist() == [7, 10]
    man = json.loads((out / "run_manifest.json").read_text())
    assert len([f for f in man["inputs"] if f["kind"] == "survey"]) == 10
    assert all(len(f["sha256"]) == 64 for f in man["inputs"])
    assert man["environment"]["libraries"]["numpy"]
    assert (out / "history" / hist.run_id.iloc[0] / "run_manifest.json").exists()
    rep = (out / "change_report.txt").read_text()
    assert "Surveys" in rep and "<- changed" in rep


def test_ingest_is_idempotent_and_refuses_conflicts(platform_run):
    from stockpile_model.ingest import ingest
    raw = platform_run["tmp"] / "raw"
    again = ingest(platform_run["tmp"] / "d1", raw)
    assert set(again.status) == {"unchanged"}
    bad = platform_run["tmp"] / "bad"
    bad.mkdir()
    (bad / "Topo_260315.dxf").write_text("not the original survey")
    res = ingest(bad, raw)
    assert res.status.tolist() == ["REFUSED_conflict"]


def test_manual_intervention_applied_and_logged(platform_run):
    out = platform_run["out"]
    log = pd.read_csv(out / "01_qaqc" / "manual_interventions_applied.csv")
    assert log.status.tolist() == ["applied"] and log.records_matched.tolist() == [1]
    fl = pd.read_csv(out / "01_qaqc" / "fms_flagged.csv")
    row = fl[fl.cycle_id == 664604].iloc[0]
    assert not row.use_location and row.manual_intervention == "MI-001;"


def test_intervention_without_reason_is_rejected(tmp_path):
    from stockpile_model.audit import load_interventions
    p = tmp_path / "iv.csv"
    p.write_text("id,type,cycle_id,reason,author,date\nMI-9,exclude_record,1,,someone,2026-01-01\n")
    with pytest.raises(ValueError, match="lack reason"):
        load_interventions(p)


def test_report_generates_from_outputs(tmp_path):
    from stockpile_model.config import REPO_ROOT
    from stockpile_model.report import build
    out = REPO_ROOT / "outputs"
    if not (out / "05_uncertainty" / "uncertainty_summary.json").exists():
        pytest.skip("full run outputs not present")
    dest = build(out, dest=tmp_path / "report.md")
    text = dest.read_text()
    assert "⟨" not in text and "VALIDATED" in text
    man = json.loads((out / "run_manifest.json").read_text())
    assert man["run_id"] in text
