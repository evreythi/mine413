"""Phase 4: block-model integration, attributes, classification and exports."""

import numpy as np
import pandas as pd
import pytest

from stockpile_model import blockmodel as B
from stockpile_model.config import load_config
from stockpile_model.io_survey import GridSpec
from stockpile_model.movement import CI, Layers, comp_vector


def _layers():
    # one 1 m cell, two layers: 0.0-2.5 m (recorded, Cu 10 %), 2.5-3.0 m (UNK, assumed Cu 6 %)
    c1 = comp_vector(vol=2.5, mass=3.5, mass_fms=3.5, cu_t_rec=0.35, au_g_rec=28.0, m_cu2=3.5 * 100, m_au2=3.5 * 64)
    c2 = comp_vector(vol=0.5, mass=0.7, mass_unk=0.7, cu_t_asm=0.042, au_g_asm=4.2, m_cu2=0.7 * 36, m_au2=0.7 * 36)
    return Layers(np.array([0, 0]), np.array([0, 1]), np.array([0, 1]), np.array([4470.0, 4472.5]),
                  np.array([4472.5, 4473.0]), np.vstack([c1, c2]))


def test_integrate_layers_splits_by_thickness_exactly():
    g = GridSpec.from_bounds(0, 2, 0, 2, 1.0)
    keys, S = B.integrate_layers(_layers(), g, 2.0, 2.0, 1.0, 4470.0)
    assert keys[:, 2].tolist() == [0, 1, 2]
    np.testing.assert_allclose(S[:, CI["vol"]], [1.0, 1.0, 1.0])
    np.testing.assert_allclose(S[:, CI["mass_fms"]], [1.4, 1.4, 0.7])   # 3.5 t over 2.5 m
    np.testing.assert_allclose(S.sum(axis=0), _layers().totals())


def test_block_attributes_and_dispersion():
    cfg = load_config()
    g = GridSpec.from_bounds(0, 2, 0, 2, 1.0)
    bm = B.build_block_model(_layers(), g, cfg["blockmodel"])
    top = bm[bm.iz == 2].iloc[0]                    # mixed block: 0.5 m recorded + 0.5 m UNK
    assert top.tonnes == pytest.approx(0.7 + 0.7)
    assert top.cu_pct == pytest.approx(100 * (0.07 + 0.042) / 1.4)
    assert top.frac_recorded == pytest.approx(0.5)
    assert top.cu_mix_sd == pytest.approx(2.0)      # 50/50 mix of 10 % and 6 %
    assert top.fill_fraction == pytest.approx(1.0 / 4.0)
    chk = B.check_totals(bm, _layers())
    assert max(abs(v) for v in chk.values()) < 1e-12


def test_classification_rules():
    rules = dict(high_trusted=0.9, high_travel_m=15, medium_recorded=0.7, medium_travel_m=30)
    bm = pd.DataFrame(dict(frac_trusted=[0.95, 0.95, 0.8, 0.5], frac_recorded=[1, 1, 0.8, 0.6],
                           travel_m=[10, 20, 25, 5]))
    assert B.classify(bm, rules).tolist() == ["HIGH", "MEDIUM", "MEDIUM", "LOW"]


def test_grade_tonnage_monotone_and_vtk(tmp_path):
    cfg = load_config()
    g = GridSpec.from_bounds(0, 2, 0, 2, 1.0)
    bm = B.build_block_model(_layers(), g, cfg["blockmodel"])
    gt = B.grade_tonnage(bm, "cu_pct", [0, 7, 9, 20])
    assert (np.diff(gt.tonnes) <= 1e-12).all()
    p = tmp_path / "bm.vtk"
    B.write_vtk(bm, p, 2, 2, 1, 0, 0, 4470, ["tonnes", "cu_pct"])
    lines = p.read_text().splitlines()
    assert "DIMENSIONS 2 2 4" in lines
    assert sum(1 for ln in lines if ln.startswith("SCALARS")) == 2


# ------------------------------------------------------------- real-data tests
@pytest.fixture(scope="module")
def blocks(real_inputs, real_flagged):
    from stockpile_model import stage_growth
    from stockpile_model.growth import track
    from stockpile_model.movement import run_movement
    from stockpile_model.reconcile import reconcile
    cfg, inp = real_inputs
    loads = real_flagged[real_flagged.use_in_model]
    hist = track(inp.rasters)
    nt = stage_growth.net_table(inp, loads, hist)
    f, _ = stage_growth.resolve_f_v(cfg, nt)
    rec = reconcile(loads, nt, f, cfg["reconcile"]["sigma_z_m"])
    M = run_movement(inp, hist, rec, loads, cfg)
    bm = B.build_block_model(M["layers"], M["geometry"].grid, cfg["blockmodel"])
    return dict(bm=bm, M=M, loads=loads, cfg=cfg)


def test_real_block_totals_exact(blocks):
    bm, loads = blocks["bm"], blocks["loads"]
    chk = B.check_totals(bm, blocks["M"]["layers"])
    assert max(abs(v) for v in chk.values()) < 1e-6
    assert bm.tonnes_recorded.sum() == pytest.approx(44422.0, abs=1e-6)
    assert bm.cu_t_recorded.sum() == pytest.approx((loads.payload_t * loads.cu / 100).sum(), abs=1e-6)
    assert bm.au_g_recorded.sum() == pytest.approx((loads.payload_t * loads.au).sum(), abs=1e-3)


def test_real_blocks_physically_plausible(blocks):
    bm = blocks["bm"]
    assert bm.fill_fraction.max() <= 1.0 + 1e-9          # no block holds more than its own volume
    assert bm.density_t_m3.between(1.0, 2.2).all()
    lo, hi = blocks["loads"].cu.min(), blocks["loads"].cu.max()
    assert bm.cu_pct.between(lo - 1e-9, hi + 1e-9).all()   # mixtures stay within source range
    assert set(bm.confidence) <= {"HIGH", "MEDIUM", "LOW"}
