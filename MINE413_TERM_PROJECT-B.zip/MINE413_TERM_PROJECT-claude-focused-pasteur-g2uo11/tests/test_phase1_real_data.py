"""Checks of MEASURED / CALCULATED facts on the real project data.

These pin the Phase-1 findings so that a change in code or data that alters
them is noticed. They are regression checks, not validation of the model.
"""

import numpy as np
import pytest

from stockpile_model import stage_qaqc
from stockpile_model.surfaces import closure_check, stacking_table


def test_inventory_counts(real_inputs):
    cfg, inp = real_inputs
    assert len(inp.surveys) == 10
    assert len(inp.fms) == 275
    assert inp.fms.payload_t.sum() == 44650
    assert [str(s.date) for s in inp.surveys][0] == "2026-03-15"
    assert [str(s.date) for s in inp.surveys][-1] == "2026-03-29"
    # 8 of 10 files have a file-name year (26) that disagrees with the layer year (25)
    conflicts = sum(s.file_date_code[:2] != s.layer_date_code[:2] for s in inp.surveys)
    assert conflicts == 8


def test_payloads_are_multiples_of_38(real_inputs):
    _, inp = real_inputs
    assert np.all(inp.fms.payload_t % 38 == 0)


def test_surveys_are_closed_solids(real_inputs):
    _, inp = real_inputs
    for r in inp.rasters:
        assert closure_check(r)["frac_hits_eq_2"] > 0.999


def test_consecutive_solids_stack(real_inputs):
    _, inp = real_inputs
    st = stacking_table(inp.rasters, consecutive_only=True)
    exact = st[st.frac_within_tol > 0.99]
    assert len(exact) == 7
    # the two non-exact pairs bracket the survey gaps (3/17 and 3/23-3/26)
    inexact = st[st.frac_within_tol <= 0.99]
    assert set(inexact.later) == {"Topo_260318", "Topo_260327"}


def test_total_solid_volume_regression(real_inputs):
    _, inp = real_inputs
    v = sum(r.volume for r in inp.rasters)
    assert v == pytest.approx(35107, rel=0.005)


def test_fallback_coordinate_records(real_flagged):
    fl = real_flagged
    d = fl[fl.qa_LOC_DEFAULT]
    assert len(d) == 14
    assert d[["x", "y", "z"]].drop_duplicates().shape[0] == 1
    assert d.payload_t.sum() == 2356
    assert not d.use_location.any() and d.use_in_model.all()


def test_post_survey_record_excluded_but_retained(real_flagged):
    fl = real_flagged
    late = fl[fl.qa_TIME_AFTER_LAST_SURVEY]
    assert len(late) == 1 and late.payload_t.iloc[0] == 228
    assert not late.use_in_model.any()
    assert len(fl) == 275  # nothing deleted


def test_grades_are_source_tuples(real_flagged):
    assert real_flagged.source_group.nunique() == 21


def test_dump_z_matches_surface(real_flagged):
    dz = real_flagged.loc[real_flagged.use_location, "dz_surface"].dropna()
    assert abs(np.median(dz)) < 0.5


def test_cutoff_scan_supports_assumption(real_inputs, real_flagged):
    cfg, inp = real_inputs
    scan = stage_qaqc.cutoff_scan(real_flagged, inp, np.arange(0, 37, 1.0), 24.0)
    best = scan.loc[scan.pearson_T_V.idxmax(), "cutoff_hours"]
    assert 29 <= best <= 35
    used = scan.loc[scan.cutoff_hours == cfg["timing"]["survey_cutoff_hours"], "pearson_T_V"].iloc[0]
    midnight = scan.loc[scan.cutoff_hours == 24, "pearson_T_V"].iloc[0]
    assert used > 0.9 and used > midnight + 0.15
