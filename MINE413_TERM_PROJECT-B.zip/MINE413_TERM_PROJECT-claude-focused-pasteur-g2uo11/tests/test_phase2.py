"""Phase 2: growth tracking and tonnage/volume reconciliation."""

import numpy as np
import pandas as pd
import pytest

from stockpile_model.growth import exact_tin_volume, repose_estimate, track
from stockpile_model.io_survey import GridSpec, rasterise_tin
from stockpile_model.reconcile import mass_check, reconcile, robust_volume_factor
from stockpile_model.surfaces import SolidRaster
from tests.test_phase1_units import box_solid


def solid(g, *box, name="s"):
    t, b, h = rasterise_tin(box_solid(*box), g)
    return SolidRaster(name, None, t, b, h, g.cell_area)


# ------------------------------------------------------------------ unit tests
def test_track_detects_cut_and_missing_fill():
    g = GridSpec.from_bounds(0, 20, 0, 10, 1.0)
    s0 = solid(g, 0, 10, 0, 10, 0.0, 2.0)          # 200 m3 placed
    s1 = solid(g, 0, 5, 0, 10, 1.5, 3.0)           # rests 0.5 m below s0 top -> 25 m3 cut revealed
    s2 = solid(g, 5, 10, 0, 10, 2.4, 3.0)          # rests 0.4 m above s0 top -> 20 m3 missing fill
    s3 = solid(g, 10, 20, 0, 10, 0.0, 1.0)         # new ground
    h = track([s0, s1, s2, s3], tol=0.1)
    t = h.table
    assert t.loc[1, "revealed_cut_m3"] == pytest.approx(25.0)
    assert t.loc[2, "revealed_missing_fill_m3"] == pytest.approx(20.0)
    assert t.loc[1, "net_m3"] == pytest.approx(75.0 - 25.0)
    assert t.loc[2, "net_m3"] == pytest.approx(30.0 + 20.0)
    assert t.loc[3, "new_area_m2"] == pytest.approx(100.0)
    assert np.nanmax(h.z_final) == pytest.approx(3.0)
    assert h.first_cover[5, 15] == 3 and h.last_cover[5, 2] == 1


def test_track_consecutive_stack_has_no_cut():
    g = GridSpec.from_bounds(0, 10, 0, 10, 0.5)
    h = track([solid(g, 0, 10, 0, 10, 0, 1), solid(g, 0, 10, 0, 10, 1, 2)])
    assert h.table.revealed_cut_m3.sum() == 0 and h.table.revealed_missing_fill_m3.sum() == 0


def test_exact_volume_matches_box():
    # box_solid's top and base triangles share orientation, so as built it is not a
    # consistently oriented shell: the signed terms add (A*52.5 + A*50) instead of
    # cancelling. Flipping the base makes it a closed oriented shell -> A*2.5.
    tri = box_solid(2, 6, 3, 8, 50, 52.5)
    assert exact_tin_volume(tri) == pytest.approx(20 * (52.5 + 50))  # wrong orientation -> not a volume
    tri[2:] = tri[2:][:, ::-1, :]
    assert exact_tin_volume(tri) == pytest.approx(4 * 5 * 2.5)


def _loads(rows):
    return pd.DataFrame(rows, columns=["record_id", "interval", "timestamp", "payload_t", "dens"]).assign(
        timestamp=lambda d: pd.to_datetime(d.timestamp))


def test_reconcile_buffer_fifo_and_mass_conservation():
    loads = _loads([(0, 0, "2026-01-01 01:00", 100, 2.0), (1, 0, "2026-01-01 02:00", 100, 2.0),
                    (2, 1, "2026-01-02 01:00", 100, 2.0)])
    net = pd.DataFrame(dict(interval=[0, 1], net_m3=[60.0, 90.0], footprint_m2=[0.0, 0.0]))
    rec = reconcile(loads, net, f_v=1.0, sigma_z=0.0)   # each load = 50 m3
    P = rec.placements
    # interval 0 takes all of load 0 and 10 m3 (20 %) of load 1 (oldest first)
    i0 = P[P.interval_placed == 0]
    assert i0.record_id.tolist() == [0, 1] and i0.frac.tolist() == pytest.approx([1.0, 0.2])
    # interval 1 takes the rest of load 1 (40 m3) then all of load 2 (50 m3): exactly 90 m3
    i1 = P[P.interval_placed == 1]
    assert i1.record_id.tolist() == [1, 2] and i1.frac.tolist() == pytest.approx([0.8, 1.0])
    assert rec.intervals.loc[1, "unk_m3"] == pytest.approx(0.0, abs=1e-9)
    assert rec.intervals.loc[0, "buffer_after_m3"] == pytest.approx(40.0)
    assert rec.intervals.loc[1, "buffer_after_m3"] == pytest.approx(0.0, abs=1e-9)
    mc = mass_check(loads, rec)
    assert mc["residual_t"] == pytest.approx(0.0, abs=1e-9)
    assert mc["max_load_frac_error"] < 1e-12


def test_reconcile_excess_becomes_unk_beyond_tolerance():
    loads = _loads([(0, 0, "2026-01-01 01:00", 100, 2.0)])
    net = pd.DataFrame(dict(interval=[0], net_m3=[80.0], footprint_m2=[100.0]))
    rec = reconcile(loads, net, f_v=1.0, sigma_z=0.1)    # supply 50 m3, tolerance 10 m3
    I = rec.intervals.iloc[0]
    assert I.absorbed_tolerance_m3 == pytest.approx(10.0)
    assert I.unk_m3 == pytest.approx(20.0)
    assert I.placed_fms_m3 == pytest.approx(60.0)
    assert I.placed_fms_t == pytest.approx(100.0)        # mass unchanged; density lowered
    assert rec.placements.volume_m3.sum() == pytest.approx(60.0)


def test_reconcile_deficit_leaves_unplaced_buffer():
    loads = _loads([(0, 0, "2026-01-01 01:00", 100, 2.0)])
    net = pd.DataFrame(dict(interval=[0], net_m3=[30.0], footprint_m2=[0.0]))
    rec = reconcile(loads, net, f_v=1.0, sigma_z=0.0)
    assert rec.unplaced.tonnes.sum() == pytest.approx(40.0)
    assert mass_check(loads, rec)["residual_t"] == pytest.approx(0.0)


def test_robust_volume_factor_rejects_outlier():
    t = pd.DataFrame(dict(interval=range(6), net_m3=[150, 152, 148, 151, 149, 300.0], vdens_m3=[100.0] * 6))
    r = robust_volume_factor(t)
    assert r["outlier_intervals"] == [5]
    assert r["f_v"] == pytest.approx(1.50)


def test_repose_estimate_mode():
    rng = np.random.default_rng(0)
    s = np.concatenate([rng.normal(37.0, 2.0, 5000), rng.uniform(0, 25, 2000)])
    assert repose_estimate(s)["mode_deg"] == pytest.approx(37.0, abs=1.0)


# ------------------------------------------------------------- real-data tests
@pytest.fixture(scope="module")
def growth(real_inputs, real_flagged):
    from stockpile_model import stage_growth
    cfg, inp = real_inputs
    loads = real_flagged[real_flagged.use_in_model]
    hist = track(inp.rasters, cfg["growth"]["stacking_tol_m"])
    nt = stage_growth.net_table(inp, loads, hist)
    f, cal = stage_growth.resolve_f_v(cfg, nt)
    rec = reconcile(loads, nt, f, cfg["reconcile"]["sigma_z_m"])
    return dict(inp=inp, loads=loads, hist=hist, nt=nt, cal=cal, rec=rec, cfg=cfg)


def test_real_net_volume_budget(growth):
    nt = growth["nt"]
    assert nt.fill_m3.sum() == pytest.approx(35107, rel=0.002)
    assert nt.revealed_cut_m3.sum() == pytest.approx(583, rel=0.05)
    assert nt.revealed_missing_fill_m3.sum() == pytest.approx(103, rel=0.1)
    # cut is a small fraction of fill: rehandle cannot explain the ~1.5 volume factor
    assert nt.revealed_cut_m3.sum() / nt.fill_m3.sum() < 0.03


def test_real_raster_matches_exact_volume(growth):
    for s, r in zip(growth["inp"].surveys, growth["inp"].rasters):
        assert r.volume == pytest.approx(exact_tin_volume(s.triangles), rel=1e-3)


def test_real_volume_factor_calibration(growth):
    cal = growth["cal"]
    assert 1.40 < cal["f_v"] < 1.55
    assert sorted(cal["outlier_intervals"]) == [0, 7, 9]
    assert abs(cal["f_v_first_half_only"] - cal["f_v"]) < 0.05   # temporally stable


def test_real_mass_conserved(growth):
    mc = mass_check(growth["loads"], growth["rec"])
    assert mc["recorded_t"] == 44422
    assert abs(mc["residual_t"]) < 1e-6
    assert mc["max_load_frac_error"] < 1e-9


def test_real_holdout_prediction(growth):
    from stockpile_model.stage_growth import holdout_check
    ho = holdout_check(growth["nt"], 3.0)
    held = ho[(ho.role == "held-out") & ho.consistent_interval]
    assert len(held) >= 3
    assert held.rel_error.abs().max() < 0.10


def test_real_angle_of_repose(growth):
    from stockpile_model.growth import slope_statistics
    _, slopes = slope_statistics(growth["inp"].rasters, growth["inp"].grid.cell)
    rep = repose_estimate(slopes)
    assert 35.0 <= rep["mode_deg"] <= 39.0
