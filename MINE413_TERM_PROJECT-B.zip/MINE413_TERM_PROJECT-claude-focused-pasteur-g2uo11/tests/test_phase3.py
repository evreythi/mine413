"""Phase 3: physics, optimal transport, layered allocation and conservation."""

import numpy as np
import pandas as pd
import pytest

from stockpile_model import physics, validation
from stockpile_model.io_survey import GridSpec
from stockpile_model.movement import CI, Layers, comp_vector, rehandle_supplies, stack_layers
from stockpile_model.transport import sinkhorn_log, sparsify


# ------------------------------------------------------------------ unit tests
def test_relax_conserves_volume_and_reaches_repose():
    g = GridSpec.from_bounds(0, 40, 0, 40, 0.5)
    bed = np.zeros((g.ny, g.nx))
    mob = np.zeros_like(bed)
    mob[40, 40] = 400.0
    m, _ = physics.relax(bed, mob, g.cell, 37.0)
    assert m.sum() * g.cell_area == pytest.approx(100.0, rel=1e-12)
    ideal_h = (3 * 100 / (np.pi * np.tan(np.radians(37)))) ** (1 / 3) * np.tan(np.radians(37))
    assert m.max() == pytest.approx(ideal_h, rel=0.05)


def test_relax_does_not_erode_bed():
    g = GridSpec.from_bounds(0, 40, 0, 20, 0.5)
    X = np.arange(g.nx) * g.cell
    bed = np.clip(20 - X, 0, None)[None, :].repeat(g.ny, 0)   # 45 deg ramp, steeper than repose
    mob = np.zeros_like(bed)
    mob[20, 10] = 40.0
    m, _ = physics.relax(bed, mob, g.cell, 37.0)
    assert (m >= -1e-12).all()
    assert m.sum() == pytest.approx(40.0)
    assert np.argwhere(m > 0.01)[:, 1].min() > 10   # material left the steep ramp


def test_deposit_cone_exact_volume_and_slide_to_toe():
    g = GridSpec.from_bounds(0, 60, 0, 20, 1.0)
    X = np.arange(g.nx) * g.cell
    S = np.where(X < 20, 20.0, np.clip(20 - (X - 20), 0, None))[None, :].repeat(g.ny, 0)  # pad, 45 deg face, floor
    r, c = physics.slide_path(S, 10, 21, g.cell, 37.0)
    assert c >= 39                                   # ran down the face to the floor
    th = physics.deposit_cone(S, r, c, 150.0, g.cell, 37.0)
    assert th.sum() * g.cell_area == pytest.approx(150.0, rel=1e-9)


def test_release_point_is_nearest_face_cell():
    g = GridSpec.from_bounds(0, 20, 0, 20, 1.0)
    face = np.zeros((g.ny, g.nx), bool)
    face[:, 15] = True
    r, c, d = physics.release_points(g, face, np.array([5.5]), np.array([10.5]))
    assert (r[0], c[0]) == (10, 15) and d[0] == pytest.approx(10.0)


def test_sinkhorn_and_sparsify_marginals_exact():
    rng = np.random.default_rng(3)
    xs, xp = rng.uniform(0, 30, (12, 2)), rng.uniform(0, 30, (400, 2))
    C = np.hypot(xs[:, None, 0] - xp[None, :, 0], xs[:, None, 1] - xp[None, :, 1])
    a = rng.uniform(1, 5, 12)
    b = rng.uniform(0.1, 1, 400)
    b *= a.sum() / b.sum()
    P, info = sinkhorn_log(a, b, C, 2.0)
    assert info["row_rel_error"] < 1e-8 and info["col_rel_error"] < 1e-12
    S, si = sparsify(P, a, b, rel=0.01)
    np.testing.assert_allclose(S.sum(axis=1), a, rtol=1e-12)     # supplies (mass) exact
    assert si["col_rel_error"] < 1e-8                             # capacities (geometry)
    assert si["nnz"] < P.size
    # smaller eps -> lower transport cost (less mixing)
    _, i1 = sinkhorn_log(a, b, C, 0.5)
    assert i1["transport_cost"] < info["transport_cost"]


def test_stack_layers_orders_by_time_and_is_contiguous():
    g = GridSpec.from_bounds(0, 2, 0, 1, 1.0)
    col_top = np.array([[10.0, 20.0]])
    sup = [dict(kind="load", day=2.0, comp=comp_vector(vol=2.0, mass=3.0), push_m=0.0, trusted=True),
           dict(kind="load", day=1.0, comp=comp_vector(vol=1.0, mass=1.5), push_m=0.0, trusted=True)]
    cells = np.array([0, 1])
    P = np.array([[1.0, 1.0], [0.5, 0.5]])
    C = np.zeros_like(P)
    L = stack_layers(cells, P, C, sup, 0, col_top, g, k=0)
    c0 = L.cell == 0
    # older supply (sid 1, day 1) at the bottom of each cell
    assert L.sid[c0][np.argmin(L.z_bot[c0])] == 1
    assert L.z_bot[c0].min() == pytest.approx(10.0) and L.z_top[c0].max() == pytest.approx(11.5)
    assert col_top[0, 0] == pytest.approx(11.5) and col_top[0, 1] == pytest.approx(21.5)
    assert L.comp[:, CI["mass"]].sum() == pytest.approx(4.5)


def test_rehandle_removes_exact_volume_and_composition():
    g = GridSpec.from_bounds(0, 1, 0, 1, 1.0)
    L = Layers(np.array([0, 0]), np.array([0, 1]), np.array([0, 1]), np.array([0.0, 1.0]), np.array([1.0, 3.0]),
               np.vstack([comp_vector(vol=1.0, mass=2.0, cu_t_rec=0.02), comp_vector(vol=2.0, mass=4.0, cu_t_rec=0.08)]))
    col_top = np.array([[3.0]])
    z_pre = np.array([[0.0]])
    before = L.totals()
    sup = rehandle_supplies(L, np.array([[1.5]]), col_top, z_pre, g, 1.4, dict(cu=1, au=1, ag=1), k=2, day=0)
    removed = sup[0]["comp"]
    assert removed[CI["vol"]] == pytest.approx(1.5)
    assert removed[CI["cu_t_rec"]] == pytest.approx(0.08 * 0.75)
    np.testing.assert_allclose(L.totals() + removed - removed * (np.arange(len(removed)) == CI["mass_rehandled"]), before, atol=1e-12)
    assert col_top[0, 0] == pytest.approx(1.5)


def test_rehandle_into_pre_model_material():
    g = GridSpec.from_bounds(0, 1, 0, 1, 1.0)
    L = Layers.empty()
    col_top, z_pre = np.array([[5.0]]), np.array([[5.0]])
    sup = rehandle_supplies(L, np.array([[0.5]]), col_top, z_pre, g, 1.4, dict(cu=8, au=8, ag=100), k=1, day=0)
    c = sup[0]["comp"]
    assert c[CI["vol"]] == pytest.approx(0.5) and c[CI["mass_pre"]] == pytest.approx(0.7)
    assert c[CI["cu_t_asm"]] == pytest.approx(0.7 * 0.08) and z_pre[0, 0] == pytest.approx(4.5)


def test_emd_of_shifted_distribution():
    g = GridSpec.from_bounds(0, 40, 0, 40, 1.0)
    a = np.zeros((g.ny, g.nx))
    a[20, 10] = 1.0
    b = np.zeros_like(a)
    b[20, 22] = 1.0
    assert validation.emd(a, a, g, 2.0) == pytest.approx(0.0, abs=1e-9)
    assert validation.emd(a, b, g, 2.0) == pytest.approx(12.0, abs=0.01)
    m = validation.compare(a, b, g)
    assert m["overlap"] == 0 and m["centroid_m"] == pytest.approx(12.0)


# ------------------------------------------------------------- real-data tests
@pytest.fixture(scope="module")
def moved(real_inputs, real_flagged):
    from stockpile_model import stage_growth
    from stockpile_model.growth import track
    from stockpile_model.movement import run_movement
    from stockpile_model.reconcile import reconcile
    cfg, inp = real_inputs
    loads = real_flagged[real_flagged.use_in_model]
    hist = track(inp.rasters)
    nt = stage_growth.net_table(inp, loads, hist)
    f, _ = stage_growth.resolve_f_v(cfg, nt)
    rec = reconcile(loads, nt, f, cfg["reconcile"]["sigma_z_m"])
    M = run_movement(inp, hist, rec, loads, cfg)
    return dict(cfg=cfg, inp=inp, loads=loads, hist=hist, rec=rec, M=M)


def test_real_mass_and_metal_conserved_exactly(moved):
    tot = moved["M"]["layers"].totals()
    loads = moved["loads"]
    assert tot[CI["mass_fms"]] == pytest.approx(44422.0, abs=1e-6)
    assert tot[CI["cu_t_rec"]] == pytest.approx((loads.payload_t * loads.cu / 100).sum(), abs=1e-6)
    assert tot[CI["au_g_rec"]] == pytest.approx((loads.payload_t * loads.au).sum(), abs=1e-4)
    assert tot[CI["mass_locunk"]] == pytest.approx(2356.0, abs=1e-6)
    ch = moved["M"]["checks"]
    assert (ch.mass_in - ch.mass_added_to_layers).abs().max() < 1e-6
    assert ch.sparse_row_rel_error.max() < 1e-12 and ch.sparse_col_rel_error.max() < 1e-9


def test_real_volume_identity(moved):
    """Layer volume = net surveyed volume + pre-model material brought in by cuts."""
    M = moved["M"]
    tot = M["layers"].totals()
    net = sum(s.sum() for s in M["geometry"].sink) - sum(c.sum() for c in M["geometry"].cut)
    pre_vol = tot[CI["mass_pre"]] / M["pre_density"]
    assert tot[CI["vol"]] == pytest.approx(net + pre_vol, rel=1e-9)


def test_real_column_tops_match_final_survey(moved):
    zf = physics.block_mean(moved["hist"].z_final, 2)
    ct = moved["M"]["col_top"]
    m = np.isfinite(zf) & np.isfinite(ct)
    d = (ct - zf)[m]
    assert np.percentile(np.abs(d), 99) < 0.10


def test_real_forward_model_beats_baselines_on_heldout(moved):
    from stockpile_model.stage_movement import forward_validation
    cfg, inp = moved["cfg"], moved["inp"]
    fv = forward_validation(inp, moved["hist"], moved["rec"], moved["loads"], cfg, [cfg["physics"]["face_slope_deg"]])
    held = fv[fv.interval > cfg["validation"]["calibration_max_interval"]].groupby("mode").emd_m.mean()
    assert held["push"] < held["no_push"] < held["uniform_face"]
