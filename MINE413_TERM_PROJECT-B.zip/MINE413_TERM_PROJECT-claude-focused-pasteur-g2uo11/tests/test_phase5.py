"""Phase 5: sensitivity and Monte-Carlo machinery."""

import numpy as np
import pandas as pd
import pytest

from stockpile_model import uncertainty as U
from stockpile_model.config import load_config
from stockpile_model.stage_uncertainty import final_confidence


def _loads(n=40, seed=0):
    rng = np.random.default_rng(seed)
    return pd.DataFrame(dict(record_id=range(n), payload_t=rng.choice([114, 152, 190], n).astype(float),
                             cu=rng.choice([5.79, 8.53], n), au=7.0, ag=200.0, source_group=rng.integers(0, 3, n),
                             x=rng.uniform(0, 50, n), y=rng.uniform(0, 50, n), use_location=rng.random(n) > 0.2))


def test_perturb_loads_respects_error_model():
    cfg = load_config()
    L = _loads()
    P = U.perturb_loads(L, np.random.default_rng(1), cfg["uncertainty"])
    assert len(P) == len(L)
    assert (np.abs(P.payload_t - L.payload_t) <= 19.0 + 1e-9).all()
    # grade factor is shared within a source group (grades are source attributes)
    ratio = (P.cu / L.cu).round(12)
    assert ratio.groupby(L.source_group).nunique().max() == 1
    # untrusted positions are not perturbed (they are not used)
    assert (P.x[~L.use_location] == L.x[~L.use_location]).all()
    assert (P.x[L.use_location] != L.x[L.use_location]).all()


def test_bootstrap_f_v_within_interval_ratio_range():
    nt = pd.DataFrame(dict(interval=range(6), net_m3=[150, 140, 160, 155, 145, 400.0], vdens_m3=[100.0] * 6))
    f = U.bootstrap_f_v(nt, 3.0, 200, np.random.default_rng(0))
    assert f.min() >= 1.40 - 1e-12 and f.max() <= 1.60 + 1e-12   # outlier interval excluded
    assert 1.45 < f.mean() < 1.55


def test_block_accumulator_statistics():
    acc = U.BlockAccumulator(["tonnes"])
    for v in (1.0, 2.0, 3.0):
        acc.add(pd.DataFrame(dict(ix=[0], iy=[0], iz=[0], tonnes=[v])))
    r = acc.result().iloc[0]
    assert r.tonnes_mean == pytest.approx(2.0)
    assert r.tonnes_sd == pytest.approx(np.std([1, 2, 3]))
    assert r.n_realisations == 3


def test_final_confidence_downgrade():
    bmu = pd.DataFrame(dict(confidence=["HIGH", "HIGH", "MEDIUM", "LOW"], cu_pct_sd=[0.5, 1.5, 1.5, 1.5],
                            cu_pct_mean=[10, 10, 10, 10], tonnes_sd=[0.1] * 4, tonnes_mean=[5.0] * 4))
    out = final_confidence(bmu, dict(max_cu_cv=0.10, max_tonnes_cv=0.15))
    assert out.tolist() == ["HIGH", "MEDIUM", "LOW", "LOW"]


def test_unk_grade_bounds_bracket_base():
    bm = pd.DataFrame(dict(tonnes=[10.0, 10.0], tonnes_unrecorded=[0.0, 5.0], tonnes_premodel=[0.0, 0.0],
                           cu_t_recorded=[1.0, 0.5], au_g_recorded=[80.0, 40.0]))
    loads = pd.DataFrame(dict(cu=[5.0, 12.0], au=[6.0, 10.0]))
    lo, hi = U.unk_grade_bound(bm, loads, "min"), U.unk_grade_bound(bm, loads, "max")
    assert lo["cu_t"] == pytest.approx(1.5 + 5 * 0.05) and hi["cu_t"] == pytest.approx(1.5 + 5 * 0.12)
    assert lo["au_oz"] < hi["au_oz"]


def test_real_mc_realisation_conserves_its_own_inputs(real_inputs, real_flagged):
    from stockpile_model import stage_growth
    from stockpile_model.growth import track
    cfg, inp = real_inputs
    loads = real_flagged[real_flagged.use_in_model]
    hist = track(inp.rasters)
    nt = stage_growth.net_table(inp, loads, hist)
    L = U.perturb_loads(loads, np.random.default_rng(7), cfg["uncertainty"])
    rec, M, bm = U.run_core(inp, hist, nt, L, cfg, f_v=1.45)
    placed = rec.placements.tonnes.sum()
    assert bm.tonnes_recorded.sum() == pytest.approx(placed, rel=1e-12)
    assert placed + rec.unplaced.tonnes.sum() == pytest.approx(L.payload_t.sum(), rel=1e-12)
    assert bm.cu_t_recorded.sum() == pytest.approx(
        (rec.placements.merge(L[["record_id", "cu"]], on="record_id").eval("tonnes * cu / 100")).sum(), rel=1e-9)
