import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
DATA_ZIP = ROOT / "Data_Topo 2026.zip"


@pytest.fixture(scope="session")
def real_inputs(tmp_path_factory):
    """Real project data ingested into a temporary raw store (no synthetic data)."""
    if not DATA_ZIP.exists():
        pytest.skip("project data zip not present")
    from stockpile_model.config import load_config
    from stockpile_model.ingest import ingest
    from stockpile_model.pipeline import load_inputs
    tmp = tmp_path_factory.mktemp("real")
    cfg = load_config(overrides={"data": {"raw_dir": str(tmp / "raw")}})
    ingest(DATA_ZIP, tmp / "raw")
    inp = load_inputs(cfg, cache_dir=ROOT / "outputs" / ".cache")
    return cfg, inp


@pytest.fixture(scope="session")
def real_flagged(real_inputs):
    from stockpile_model import qaqc
    cfg, inp = real_inputs
    return qaqc.flag_records(inp.fms, cfg, inp.grid, inp.rasters, inp.interval_idx)
