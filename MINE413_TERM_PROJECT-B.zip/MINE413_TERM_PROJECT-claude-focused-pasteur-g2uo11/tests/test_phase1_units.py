"""Isolated unit tests (small synthetic inputs are allowed here only)."""

import numpy as np
import pandas as pd
import pytest

from stockpile_model import qaqc, timing
from stockpile_model.config import load_config
from stockpile_model.io_fms import read_fms, read_fms_csv
from stockpile_model.io_survey import GridSpec, rasterise_tin, read_dxf_tin, triangle_plan_area
from stockpile_model.surfaces import SolidRaster, closure_check, pair_stacking


def plane_triangles(x0, x1, y0, y1, a, b, c):
    """Two triangles covering a rectangle on the plane z = a + b x + c y."""
    z = lambda x, y: a + b * x + c * y  # noqa: E731
    p = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    P = [(x, y, z(x, y)) for x, y in p]
    return np.array([[P[0], P[1], P[2]], [P[0], P[2], P[3]]], float)


def box_solid(x0, x1, y0, y1, zb, zt):
    return np.concatenate([plane_triangles(x0, x1, y0, y1, zt, 0, 0),
                           plane_triangles(x0, x1, y0, y1, zb, 0, 0)])


def test_grid_index_and_centres():
    g = GridSpec.from_bounds(0, 10, 0, 5, 0.5)
    assert (g.nx, g.ny) == (20, 10)
    assert g.xc[0] == pytest.approx(0.25) and g.yc[-1] == pytest.approx(4.75)
    r, c = g.index([0.1, 9.99, 10.0, -0.1], [0.1, 4.99, 1, 1])
    assert list(r) == [0, 9, -1, -1] and list(c) == [0, 19, -1, -1]


def test_rasterise_plane_is_exact():
    g = GridSpec.from_bounds(0, 10, 0, 10, 0.5)
    tri = plane_triangles(1, 9, 1, 9, 100.0, 0.3, -0.2)
    top, bot, hits = rasterise_tin(tri, g)
    X, Y = np.meshgrid(g.xc, g.yc)
    m = np.isfinite(top)
    assert m.sum() == 16 * 16
    np.testing.assert_allclose(top[m], (100 + 0.3 * X - 0.2 * Y)[m], atol=1e-9)
    assert set(np.unique(hits[m])) == {1}  # shared diagonal owned by exactly one triangle
    # interpolation never extrapolates outside the TIN
    assert np.isnan(top[0, 0]) and np.isnan(top[-1, -1])


def test_closed_box_solid_volume_and_hits():
    g = GridSpec.from_bounds(0, 10, 0, 10, 0.5)
    tri = box_solid(2, 6, 3, 8, 50.0, 52.5)
    top, bot, hits = rasterise_tin(tri, g)
    r = SolidRaster("box", np.datetime64("2026-01-01"), top, bot, hits, g.cell_area)
    assert r.volume == pytest.approx(4 * 5 * 2.5)
    assert closure_check(r)["frac_hits_eq_2"] == 1.0


def test_pair_stacking_detects_cut():
    g = GridSpec.from_bounds(0, 10, 0, 10, 0.5)
    a = rasterise_tin(box_solid(0, 10, 0, 10, 0.0, 2.0), g)
    b_ok = rasterise_tin(box_solid(0, 10, 0, 10, 2.0, 3.0), g)
    b_cut = rasterise_tin(box_solid(0, 10, 0, 5, 1.5, 3.0), g)
    A = SolidRaster("a", None, a[0], a[1], a[2], g.cell_area)
    s1 = pair_stacking(A, SolidRaster("b", None, *b_ok, g.cell_area))
    s2 = pair_stacking(A, SolidRaster("c", None, *b_cut, g.cell_area))
    assert s1["frac_within_tol"] == 1.0 and s1["cut_volume_m3"] == 0
    assert s2["frac_cut"] == 1.0 and s2["cut_volume_m3"] == pytest.approx(10 * 5 * 0.5)


def test_read_dxf_roundtrip(tmp_path):
    ezdxf = pytest.importorskip("ezdxf")
    doc = ezdxf.new("R2013")
    msp = doc.modelspace()
    for t in box_solid(0, 4, 0, 4, 10, 12):
        msp.add_3dface([tuple(t[0]), tuple(t[1]), tuple(t[2]), tuple(t[0])], dxfattribs={"layer": "250401_TEST"})
    msp.add_3dface([(0, 0, 0), (1, 0, 0), (0, 0, 0), (0, 0, 0)], dxfattribs={"layer": "250401_TEST"})  # degenerate
    p = tmp_path / "Topo_260401.dxf"
    doc.saveas(p)
    s = read_dxf_tin(p, year_override=2026)
    assert s.n_faces_raw == 5 and s.n_degenerate == 1 and len(s.triangles) == 4
    assert s.file_date_code == "260401" and s.layer_date_code == "250401"
    assert str(s.date) == "2026-04-01"
    assert triangle_plan_area(s.triangles).sum() == pytest.approx(32.0)


def test_read_dxf_rejects_quads(tmp_path):
    ezdxf = pytest.importorskip("ezdxf")
    doc = ezdxf.new("R2013")
    doc.modelspace().add_3dface([(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0)])
    p = tmp_path / "Topo_260401.dxf"
    doc.saveas(p)
    with pytest.raises(ValueError, match="quadrilateral"):
        read_dxf_tin(p)


CSV_HEADER = "Cycle ID,Truck PayLoad,Au,Ag,Cu,Dens,X (Dump Event),Y (Dump Event),Z (Dump Event),Dump_tstamp\n"


def test_read_fms_coerces_bad_values(tmp_path):
    p = tmp_path / "a.csv"
    p.write_text(CSV_HEADER + "1,152,8.3,182,9.5,2.0,100,200,10,3/15/2026 17:43\n"
                              "2,abc,8.3,182,9.5,2.0,100,200,10,not a date\n")
    df = read_fms_csv(p)
    assert df.payload_t.isna().tolist() == [False, True]
    assert df.timestamp.isna().tolist() == [False, True]
    assert df.source_row.tolist() == [2, 3]


def test_read_fms_collapses_exact_duplicates_only(tmp_path):
    a, b = tmp_path / "a.csv", tmp_path / "b.csv"
    a.write_text(CSV_HEADER + "1,152,8.3,182,9.5,2.0,100,200,10,3/15/2026 17:43\n")
    b.write_text(CSV_HEADER + "1,152,8.3,182,9.5,2.0,100,200,10,3/15/2026 17:43\n"
                              "1,190,8.3,182,9.5,2.0,100,200,10,3/15/2026 17:43\n")
    df = read_fms([a, b])
    assert len(df) == 2  # exact copy collapsed, conflicting copy kept for QA


def test_timing_boundaries():
    cut = timing.survey_cutoffs(["2026-03-15", "2026-03-16"], 31.0)
    assert str(cut[0]) == "2026-03-16 07:00:00"
    t = pd.to_datetime(["2026-03-15 06:59", "2026-03-15 07:01", "2026-03-16 07:00",
                        "2026-03-16 07:01", "2026-03-17 07:01", None])
    idx = timing.assign_intervals(t, cut, 24.0)
    assert idx.tolist() == [timing.BEFORE_FIRST, 0, 0, 1, timing.AFTER_LAST, -3]
    with pytest.raises(ValueError):
        timing.survey_cutoffs(["2026-03-16", "2026-03-15"], 31.0)


def test_qaqc_rules_flag_without_deleting():
    cfg = load_config()
    g = GridSpec.from_bounds(0, 100, 0, 100, 1.0)
    top, bot, hits = rasterise_tin(box_solid(10, 90, 10, 90, 0.0, 5.0), g)
    ras = [SolidRaster("s", None, top, bot, hits, g.cell_area)]
    n = 6
    df = pd.DataFrame(dict(
        record_id=range(n), cycle_id=pd.array([1, 2, 3, 4, 5, 6], dtype="Int64"),
        payload_t=[152, 38, 304, 152, 152, 152], au=[8, 8, 8, 8, 8, 999], ag=[100] * n,
        cu=[9, 9, 9, 9, 9, 9], dens=[2.0] * n,
        x=[50, 50, 50, 20, 20, 20], y=[50, 51, 52, 20, 20, 20], z=[0.2, 0.0, 0.1, -30, -30, -30],
        timestamp=pd.to_datetime(["2026-03-15 10:00"] * n)))
    fl = qaqc.flag_records(df, cfg, g, ras, np.zeros(n, int))
    assert len(fl) == n
    assert fl.qa_PAYLOAD_PARTIAL.tolist() == [False, True, False, False, False, False]
    assert fl.qa_PAYLOAD_HIGH.tolist() == [False, False, True, False, False, False]
    assert fl.qa_LOC_DEFAULT.tolist() == [False, False, False, True, True, True]
    assert fl.use_location.tolist() == [True, True, True, False, False, False]
    assert fl.qa_LOC_Z_INCONSISTENT.tolist() == [False, False, False, True, True, True]
    assert fl.qa_GRADE_INVALID.tolist() == [False] * 5 + [True]
    assert fl.use_in_model.all()
