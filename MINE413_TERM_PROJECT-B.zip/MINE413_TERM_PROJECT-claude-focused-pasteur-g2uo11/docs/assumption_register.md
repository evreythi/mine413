# Assumption Register

The true historical movement of stockpiled material is not observed, so the
reconstruction is non-unique. Every assumption the platform relies on is listed
here **at the time it is made**, with the evidence category of its value:

| Category | Meaning |
|---|---|
| MEASURED | directly present in supplied data |
| CALCULATED | mathematically derived from measured data |
| INFERRED | estimated from evidence in the data |
| ASSUMED | selected because the data do not determine it |

`Status` is `ACTIVE`, `REVISED` (superseded — the revision is described in the
entry and the earlier text kept), or `RETIRED`. Parameters that encode an
assumption cite its ID in `config/default.toml`. "Treatment" says whether the
assumption is tested in the sensitivity/uncertainty analysis (Phase 5) or
controlled another way.

---

### A-001 Survey year = 2026 (survey dates are the month/day of the file name)
- **Category:** ASSUMED (month/day: MEASURED)
- **Assumption:** All ten surveys are dated 2026-MM-DD using the MMDD part of the file name.
- **Need:** File names mix `25MMDD` (2 files) and `26MMDD` (8 files); every DXF layer name uses `25MMDD`; the DXF `$TDUPDATE` header is 2025-11-13; all 275 FMS timestamps are in March 2026. Without a common year, surveys cannot be aligned with FMS records.
- **Justification:** (i) The MMDD sequence (15,16,18,…,29 March) is internally consistent and overlaps the FMS period day-for-day. (ii) Solids stack exactly in MMDD order (base of k+1 = top of k to < 1 mm, 7 of 9 pairs), which would not occur if the year labels reflected a 12-month separation. (iii) With MMDD alignment, interval FMS tonnage correlates with fill volume (Pearson r = 0.97 at the adopted cut-off, A-003) — a coincidence of this strength would be implausible if the two datasets were from different years. The year discrepancy is most likely a relabelling artefact of dataset preparation.
- **Consequence if wrong:** if surveys and FMS are from different years, no load-to-survey reconciliation is meaningful and the whole reconstruction collapses. The evidence above makes this unlikely.
- **Treatment:** Controlled — conflict is flagged per file in `outputs/01_qaqc/dataset_inventory.csv` (`year_conflict`) and the year is a config parameter (`data.survey_year`). Should be confirmed with the survey department.
- **Status:** ACTIVE (2026-10-07)

### A-002 Common coordinate reference system
- **Category:** INFERRED
- **Assumption:** FMS X/Y/Z and DXF coordinates are in the same projected, metric site system (magnitudes resemble UTM southern-hemisphere coordinates; the exact CRS/datum is not stated and is not needed because no transformation is performed).
- **Need:** Neither dataset states a CRS, datum or units.
- **Justification:** Dumps plot on and around the surveyed solids (217/275 inside their union footprint); dump Z lies within −1.4 to 0 m (IQR) of the surveyed surface envelope; coordinate magnitudes and resulting geometry are only physically sensible in metres (pile height ≈ 15 m, fill volumes of the order of truck-load volumes). Note: the DXF headers declare `$INSUNITS = 1` (inches) and `$MEASUREMENT = 0` (imperial); this metadata is contradicted by the coordinates and is treated as unreliable (MEASURED defect, recorded in the data register).
- **Consequence if wrong:** a horizontal shift between systems would bias dump-to-fill distances and the movement algorithm's direction/distance; volumes are unaffected.
- **Treatment:** Controlled by the per-record Z envelope check (`LOC_Z_INCONSISTENT`); GPS error sensitivity in Phase 5.
- **Status:** ACTIVE (2026-10-07)

### A-003 Survey cut-off time = 07:00 on the day after the label date
- **Category:** INFERRED
- **Assumption:** A survey labelled day D represents the stockpile after all dumping up to D+1 07:00 (the morning shift change). Interval k = (cutoff_{k−1}, cutoff_k].
- **Need:** Surveys have a date but no time; FMS records have minute timestamps. Assigning loads near the boundary to the wrong interval corrupts interval reconciliation.
- **Justification:** (i) Scanning the cut-off from D 00:00 to D+1 12:00, the correlation between interval FMS tonnage and fill-solid volume rises from −0.44 (D 00:00) and 0.73 (D 24:00) to a plateau of 0.94–0.97 for D+1 06:00–11:00; the fraction of dumps within 3 m of their assigned solid also rises (0.15 → 0.58). (ii) Independently, the dump time-of-day histogram has near-empty windows 06:00–07:30 (2 of 275 loads) and 18:30–20:00 (0 loads), i.e. 12-h shift changes; a drone/total-station survey during the shift change is operationally typical. Any cut-off between 06:26 and 07:28 gives an identical load assignment.
- **Consequence if wrong:** loads dumped between 06:26 and ~10:00 (up to ~13 loads per boundary) would move between adjacent intervals; interval-level density/reconciliation would shift but cumulative balances are unchanged.
- **Treatment:** Sensitivity (Phase 5): cut-off 30 h and 34 h. Evidence table: `outputs/01_qaqc/survey_cutoff_scan.csv`; figure `fig_time_of_day_and_cutoff_scan.png`.
- **Status:** ACTIVE (2026-10-07)

### A-004 Units of FMS attributes
- **Category:** ASSUMED
- **Assumption:** `Truck PayLoad` in metric tonnes; `Cu` in %; `Au` and `Ag` in g/t; `Dens` in t/m³.
- **Need:** The CSV header has no units.
- **Justification:** Payload values 38–304 match large haul-truck classes in tonnes; Au/Ag in g/t and Cu in % are the industry convention. Note: tonnage-weighted Cu = 8.42 % and Au = 8.00 g/t are an order of magnitude above typical Cu–Au porphyry grades; the values may be scaled/anonymised for teaching or represent a selectively stockpiled high-grade product (layer names contain `HGHS`).
- **Consequence if wrong:** contained-metal totals scale linearly with a unit factor; spatial distribution, ranking and relative uncertainty are unaffected.
- **Treatment:** Reported in the units as supplied; stated on every output. Not varied.
- **Status:** ACTIVE (2026-10-07)

### A-005 FMS Z is a ground elevation with metre-level precision; Z is used for QA only
- **Category:** INFERRED
- **Assumption:** `Z (Dump Event)` refers to ground level at the dump (not GPS antenna height) with a vertical precision of roughly ±2 m; Z is not used to place material (placement uses XY and the surveyed surfaces).
- **Need:** The vertical reference of the FMS Z is not documented.
- **Justification:** The residual of dump Z outside the surveyed surface envelope of its interval has median −0.23 m (n = 199, trusted locations), IQR −1.36 to 0.00 m — an antenna offset would give a ~+5–7 m bias. The spread is typical of non-RTK fleet GPS.
- **Consequence if wrong:** none for placement; only the QA flag threshold (5 m) is affected.
- **Treatment:** Controlled (QA only).
- **Status:** ACTIVE (2026-10-07)

### A-006 Repeated identical XYZ is a fallback coordinate (location unknown)
- **Category:** INFERRED
- **Assumption:** A dump coordinate repeated exactly (to the cm) on ≥ 3 records is a system default, not a measured position. Those loads' tonnage and grade are used, but their location is treated as unknown within their interval.
- **Need:** 14 loads (2,356 t, 5.3 % of FMS tonnage) report exactly (511334.70, 7122320.38, 4473.00) between 16 and 28 March.
- **Justification:** Real GPS positions of 14 dumps over 12 days cannot coincide to the cm; Z = 4473.00 is 1.6 m below the lowest surveyed elevation of any solid (4474.6 m); a round-valued Z is characteristic of a fixed waypoint.
- **Consequence if wrong:** if the position were real, these loads would be placed ~0–20 m from where the algorithm spreads them; effect bounded by 5.3 % of tonnage.
- **Treatment:** Location-unknown loads are allocated by the movement algorithm without a spatial prior (Phase 3); share of block tonnage from such loads is reported as an uncertainty indicator.
- **Status:** ACTIVE (2026-10-07)

### A-007 Grades are source (dig-block) attributes, homogeneous within a load
- **Category:** INFERRED
- **Assumption:** Each load carries the Cu/Au/Ag/Dens of its source block; the grade is uniform within the load; all loads from the same source share identical values.
- **Need:** Only 21 distinct (Au, Ag, Cu, Dens) tuples occur in 275 loads (the largest covers 117 loads, 19,228 t), so the grades are not per-truck assays.
- **Justification:** Identical four-attribute tuples across dozens of trucks over several days can only come from a block-model or polygon lookup.
- **Consequence if wrong:** within-source variability (real but unrecorded) is invisible to the model; block-grade variance and uncertainty are under-stated.
- **Treatment:** Phase 5 Monte Carlo applies an assumed per-load grade error (assay/ block-model error) — its magnitude will be registered as a separate assumption.
- **Status:** ACTIVE (2026-10-07)

### A-008 Payloads are nominal (pass count × 38 t), not weighed
- **Category:** INFERRED
- **Assumption:** Recorded payloads are loader-pass counts multiplied by a 38 t nominal pass; the true load mass differs randomly by up to about ± half a pass.
- **Need:** Every payload is an exact multiple of 38 t (38, 76, …, 304; 275/275 records).
- **Justification:** A weighed payload (strut-pressure or scale) would not be quantised. 228 t (6 passes) is the modal full load for ~220–230 t class trucks; 266 t and 304 t (3 loads) exceed that and are flagged.
- **Consequence if wrong:** per-load mass error of ±19 t (≈ ±12 % of a 152 t load) is random and partly averages out over many loads; a systematic pass-mass bias would scale all tonnages.
- **Treatment:** Phase 5: per-load uniform ±19 t error and a systematic tonnage factor.
- **Status:** ACTIVE (2026-10-07)

### A-009 Each DXF is a fill-only increment solid between consecutive surveys
- **Category:** INFERRED
- **Assumption:** Each survey file is a closed solid whose base is the surface at the previous survey and whose top is the surface at this survey, restricted to where the surface rose. Elevation decreases (cuts) are not represented in the supplied files.
- **Need:** The files are described as topographic surveys but are not open surfaces: ≥ 99.98 % of covered 0.5 m cells are intersected by exactly two faces (top and base), thickness pinches to 0 at the edges, and coverage is a 1,300–3,200 m² band, not the whole pile.
- **Justification:** On 7 of 9 consecutive pairs, base(k+1) = top(k) on 100 % of the overlap (|Δz| ≤ 0.1 m; median 0.000 m). The two exceptions (3/16→3/18, 3/22→3/27) bracket days with no supplied survey (3/17, 3/23–3/26), consistent with unsupplied intermediate solids. Comparing non-consecutive solids reveals limited cut (base of a later solid below the top of an earlier one; ≤ 2.7 m deep, a few hundred m³ in total), i.e. elevation decreases did occur but are only visible where later refilled.
- **Consequence if wrong:** if the files were full surfaces, volumes would be grossly over-stated; the closure test rules this out. Because cuts are invisible, material removed from earlier fills (e.g. crest re-push) cannot be fully tracked.
- **Treatment:** Detected cuts are applied (material removed from the column and re-allocated); undetectable cut is an acknowledged limitation and is covered by the volume-balance uncertainty.
- **Status:** ACTIVE (2026-10-07)

### A-010 Model domain and 0.5 m plan resolution
- **Category:** ASSUMED
- **Assumption:** Fixed rectangular domain X 511280–511430, Y 7122280–7122420; all rasters use 0.5 m cells sampled at cell centres by linear interpolation on the TIN.
- **Need:** A common lattice is required to difference and stack surfaces.
- **Justification:** The domain contains all solids and all FMS records with ≥ 15 m margin. The median TIN edge length is 0.84–1.04 m, so a 0.5 m cell resolves the TIN without inventing detail.
- **Consequence if wrong:** volume discretisation error at the pinched edges; affects totals by a small amount (to be quantified).
- **Treatment:** Phase 2/5: volumes recomputed at 0.25 m and 1.0 m.
- **Status:** ACTIVE (2026-10-07)

### A-011 The first (open) interval spans 24 h
- **Category:** ASSUMED
- **Assumption:** The first solid (Topo_260315) represents fill during the 24 h before its cut-off (15 Mar 07:00 → 16 Mar 07:00).
- **Need:** No survey precedes it.
- **Justification:** Supplied surveys are daily where available.
- **Consequence if wrong:** only affects whether early records would be assigned to the first interval; the earliest FMS record (15 Mar 17:43) falls inside either way.
- **Treatment:** Controlled (no record falls near the boundary).
- **Status:** ACTIVE (2026-10-07)

### A-012 Material dumped after the last survey is not in the current model
- **Category:** ASSUMED (rule)
- **Assumption:** The single record after the last cut-off (31 Mar 20:52, 228 t) is excluded from the reconstructed model and reported as pending tonnage until a later survey captures it.
- **Need:** No surveyed geometry exists for it.
- **Justification:** Placing it would require an unconstrained forward prediction.
- **Consequence if wrong:** stockpile inventory understated by 228 t (0.5 %).
- **Treatment:** Reported separately in every inventory output; the platform will include it automatically when a later survey is ingested.
- **Status:** ACTIVE (2026-10-07)

### A-013 Revealed cut / missing fill is attributed to the interval in which it is revealed
- **Category:** ASSUMED
- **Assumption:** When the base of solid k differs from the latest known surface by more than 0.10 m, the difference (cut or missing fill) is booked to interval k. The earliest interval in which it could have happened is stored with it.
- **Need:** A cut or an unsupplied fill is only observed when a later solid covers the cell; its timing between the two observations is unknown.
- **Justification:** Interval k is the latest interval consistent with the observation; for the survey gaps (3/17, 3/23–26) the gap lies inside interval k anyway. The 0.10 m tolerance is twice the assumed systematic survey error (A-016) and far above the observed stacking residual of consecutive solids (≤ 0.007 m).
- **Consequence if wrong:** revealed volumes are small (cut 583 m³, missing fill 103 m³ = 1.7 % and 0.3 % of fill), so re-timing them changes interval balances by < 10 % and cumulative balances not at all.
- **Treatment:** Controlled (small); stacking tolerance can be varied in config.
- **Status:** ACTIVE (2026-10-07)

### A-014 In-pile volume of a load = f_v × T / Dens, with f_v = 1.476 calibrated
- **Category:** INFERRED (value); ASSUMED (interpretation)
- **Assumption:** Each load occupies `v_i = f_v · T_i / Dens_i` in the stockpile; equivalently its in-pile bulk density is `Dens_i / f_v` (≈ 1.38 t/m³ on average). `f_v` is the pooled ratio of surveyed net volume to Σ(T/Dens) over the 7 intervals whose ratio is not an outlier (median ± 3 robust SD).
- **Need:** The surveyed net volume (34,627 m³) is 1.61 × Σ(T/Dens) (21,525 m³). Using `Dens` as the in-pile density would leave 13,000 m³ (37 %) of surveyed volume unexplained.
- **Justification:** (i) The ratio is consistent across 7 of 10 intervals (1.20–1.59; robust SD 0.17). (ii) Temporal stability: calibrating on the first half only gives 1.469 vs 1.476. (iii) Held-out test: calibrated on intervals 0–4, the model predicts the net volume of held-out consistent intervals 5, 6, 8 within −5.2 %, −0.0 %, +4.2 % (mean |error| 3.2 %); a constant-density model that ignores `Dens` does worse (8.4 %), so `Dens` carries real relative-density information. (iv) Rehandle cannot explain the factor: revealed cut is only 1.7 % of fill. (v) Literature: Caterpillar tabulates bank-to-loose swell of up to ~60 % (load factor 0.625) for excavated materials (search-result summary of cat.com "Swell & Void Percentage, Load Factors"; the primary page could not be retrieved from this environment and must be checked by the team). A 48 % swell is high but within that range if `Dens` is an in-situ density.
- **Alternative explanation that the data cannot exclude:** recorded payloads understate true mass by ≈ 32 % (with `Dens` as the true in-pile density). Volumes would then imply ≈ 71,600 t instead of 44,422 t — a first-order difference in contained metal.
- **Consequence if wrong:** under the alternative, all tonnages and contained metal are understated by ~1/3, while grades and spatial distribution are unchanged.
- **Treatment:** Sensitivity f_v ∈ [1.35, 1.65] (Phase 5); both interpretations are reported, and a field bulk-density / payload-scale check is recommended before the inventory is used for production commitments.
- **Status:** ACTIVE (2026-10-07)

### A-015 Pad buffer: dumped material is pushed into the surveyed fill oldest-first
- **Category:** ASSUMED
- **Assumption:** Loads may wait on the pile top (where the survey solids do not record them) and be pushed over the crest in a later interval. Placement into fill is first-in, first-out by dump time, allowing partial loads.
- **Need:** Interval 1 has 25 % less surveyed volume than its loads imply, while intervals 2–3 have slightly more; a strict same-interval balance would mis-place material.
- **Justification:** Trucks dump on the pad and dozers push in sequence; the model's peak buffer is 726 m³ (7 loads), physically plausible for a working pad. The interval-1 deficit coincides with the unsupplied 17 March survey.
- **Consequence if wrong:** load timing within ±1 interval, which changes the vertical/lateral position of individual loads in the fill but not totals.
- **Treatment:** Phase 3/5: compare with a no-buffer variant.
- **Status:** ACTIVE (2026-10-07)

### A-016 Survey systematic vertical error σ_z = 0.05 m
- **Category:** ASSUMED
- **Assumption:** Surveyed volumes can be biased by up to `σ_z × footprint` per interval (e.g. ±160 m³ for the 3,164 m² 28-March solid); excess volume within this tolerance is attributed to survey error, not to unrecorded material.
- **Need:** No repeat survey of an unchanged surface or survey accuracy report was supplied.
- **Justification:** typical systematic vertical accuracy of UAV photogrammetry / laser scanning of stockpiles with ground control is a few centimetres (to be confirmed with the survey department's QA reports).
- **Consequence if wrong:** shifts at most a few hundred m³ between "placed material at lower density" and "unrecorded material".
- **Treatment:** Phase 5 sensitivity (0.02–0.10 m).
- **Status:** ACTIVE (2026-10-07)

### A-017 Volume exceeding FMS supply (beyond tolerance) is unrecorded material (UNK) of unknown grade
- **Category:** ASSUMED
- **Assumption:** Where surveyed net volume exceeds the supply of recorded loads (plus buffer) by more than the survey tolerance, the excess is material that entered the stockpile without an FMS record. It is carried in the model as a separate material class `UNK` with unknown grade; it is **not** hidden by lowering density.
- **Need:** In intervals 0, 7 and 9, 31–38 % of the surveyed net volume is not explained by the loads and buffer available (UNK 980, 1,067 and 364 m³; plus 20 m³ in interval 8), coinciding with visible FMS gaps (records start 15 Mar 17:43; one load 22 Mar 18:28 → 28 Mar 03:54; none 29 Mar 08:17 → 31 Mar).
- **Justification:** Forcing the density to fit would imply 0.85–0.90 t/m³ in those intervals — physically implausible for broken rock — and would silently assign recorded grades to unrecorded material. Making the gap explicit is required by the assignment's accountability scenario.
- **Consequence if wrong:** if the excess is actually recorded material with extra bulking, UNK tonnage (≈ 2,431 m³ ≈ 3,350 t at 1.38 t/m³) would instead carry recorded grades.
- **Treatment:** Phase 4 decides the grade treatment of UNK (reported separately, with an assumed grade range); Phase 5 sensitivity on f_v changes the UNK volume (figure `fig_volume_factor_tradeoff.png`).
- **Status:** ACTIVE (2026-10-07)

### A-018 Angle of repose = 37°
- **Category:** CALCULATED (from surveys), corroborated by literature
- **Assumption:** Loose dumped material stands at 37° on free faces.
- **Need:** Required by the downslope (gravity) component of the movement model.
- **Justification:** Slope of the 10 surveyed solid tops (0.5 m cells thicker than 0.3 m, central differences): pooled mode of slopes > 25° = 37.5°, median 36.7°, IQR 33.9–39.0°, 95th percentile 42.6°; per-survey medians 34.4–36.9°. Literature: waste overburden angle of repose 37–38° measured at Clinton Creek mine (Yukon government report, 1974; search-result summary, primary not retrieved).
- **Consequence if wrong:** affects how far material travels down the face in the forward model and the shape of predicted fills.
- **Treatment:** Phase 5 sensitivity 34–40° — **done:** held-out forward-model EMD 12.7 / 12.2 / 12.2 m at 34 / 37 / 40°; the calibration-period optimum is 37°, independently matching the surveyed face slopes (`repose_sensitivity_forward_model.csv`). The repose angle does not enter the survey-constrained reconstruction.
- **Status:** ACTIVE (2026-10-07; tested)

### A-019 Dozer push: shortest path from the dump point to the active face (slope ≥ 33°)
- **Category:** INFERRED (threshold calibrated); concept tested on held-out data
- **Assumption:** Each load with a trusted position is pushed the shortest way to the nearest cell of the active face (slope of the start-of-interval surface ≥ 33°, 1 m cells, 3 × 3 smoothing). That *release point* is where gravity takes over. Dumps already on the face have zero push.
- **Need:** Dozer trajectories are not recorded (no dozer telemetry supplied).
- **Justification:** Trucks dump on the pad behind the crest and dozers push over the nearest edge (standard tip-head practice). The 33° threshold was chosen by minimising forward-prediction error on intervals 0–4 only (scan 20–40°; 8.9 m mean EMD). On held-out intervals 5–9 the push model predicts where material comes to rest with a mean EMD of 12.2 m, better than "no dozer movement" (14.5 m) and "uniform over the face" (27.9 m); it beats no-push in 4 of 5 held-out intervals (the exception, interval 6, is a period of direct end-tipping onto the fill).
- **Consequence if wrong:** release points move along the crest; individual-load positions change by ~10 m.
- **Treatment:** Phase 5 sensitivity (face threshold 30–36°); per-block travel distance reported as an uncertainty indicator.
- **Status:** ACTIVE (2026-10-07)

### A-020 Unknown terrain is extrapolated from the nearest known cell (forward model only)
- **Category:** ASSUMED
- **Assumption:** In forward predictions, cells never covered by any solid take the elevation of the nearest known cell (a flat pad behind the crest, a flat apron beyond the toe).
- **Need:** The supplied solids do not describe the pile top away from the active face or the ground beyond the final toe.
- **Justification:** Only used for validation; affects where material could run out beyond the surveyed footprint.
- **Consequence if wrong:** forward-prediction errors at the outer toe; no effect on the survey-constrained reconstruction.
- **Treatment:** Controlled (validation only).
- **Status:** ACTIVE (2026-10-07)

### A-021 Mixing length ε = 3 m in the survey-constrained allocation
- **Category:** ASSUMED
- **Assumption:** The entropic regularisation of the optimal-transport allocation is 3 m: a load's material is spread over fill cells with weights decaying like exp(−distance/3 m) relative to the minimum-push allocation.
- **Need:** The degree of mixing between loads is not observable.
- **Justification:** 3 m is comparable to the radius of a single dumped load (a 110 m³ cone at 37° has a 5 m radius) and to the dozer blade width; it represents blade-scale mixing without smearing loads across the whole face.
- **Consequence if wrong:** block-scale grade variability (more mixing → smoother grades); totals unaffected.
- **Treatment:** Phase 5 sensitivity ε ∈ {1, 3, 10} m.
- **Status:** ACTIVE (2026-10-07)

### A-022 Allocation at 1 m plan cells; contributions < 1 % of a cell dropped then re-balanced exactly
- **Category:** ASSUMED (numerical)
- **Assumption:** The column state is kept on 1 m cells (volumes summed exactly from the 0.5 m rasters). In each cell, contributions below 1 % of the cell volume are dropped unless needed to place 99.9 % of a supply; marginals are then restored by iterative proportional fitting ending with a supply (row) scaling.
- **Need:** A dense plan would hold ~1.3 M entries per interval.
- **Justification:** Mass and metal stay exact (row error ≤ 6·10⁻¹⁶ on the real data); cell-capacity (geometry) error ≤ 10⁻¹² relative; modelled column tops are within ±8 cm (1st–99th percentile) of the surveyed final surface.
- **Consequence if wrong:** slightly less mixing in tails; negligible.
- **Treatment:** Phase 5 robustness — **done:** 0.5 m model cell changes totals by +0.02 % (pre-model rehandle geometry), block Cu by 0.18 % points (tonnage-weighted mean absolute change) and provenance-HIGH tonnage from 9.2 to 10.4 kt, at 4× the run time; sparsification 0.5 % / 2 % changes nothing measurable.
- **Status:** ACTIVE (2026-10-07; tested)

### A-023 Unrecorded material (UNK) carries the grade of loads dumped in neighbouring intervals
- **Category:** ASSUMED
- **Assumption:** UNK volume of interval k has the tonnage-weighted mean Cu/Au/Ag of recorded loads dumped in intervals k−1…k+1 and the mean placed density of interval k. Its metal is booked as *assumed* metal, separate from *recorded* metal.
- **Need:** By definition there is no record of this material (A-017).
- **Justification:** Mining faces and sources persist over days (the largest source supplies 117 loads over 3/16–3/29), so the most likely provenance of unrecorded loads is the same faces worked just before and after the gap.
- **Consequence if wrong:** UNK is 3,080 t (6.5 % of model tonnage) and 321 t of 4,062 t Cu; its true grade could lie anywhere in the source range (Cu 5.6–13.7 %, Au 5.6–10.1 g/t).
- **Treatment:** Reported separately in all inventories; Phase 5 bounds it with the source grade range.
- **Status:** ACTIVE (2026-10-07)

### A-024 Pre-model material exposed by cuts has the mean placed density and the mean recorded grade
- **Category:** ASSUMED
- **Assumption:** Where a revealed cut extends below the pre-model surface, the removed material is pre-15-March stockpile (PRE) with density 1.38 t/m³ and the global tonnage-weighted FMS grade; booked as assumed metal.
- **Need:** No data describe the stockpile before 15 March.
- **Justification:** Same stockpile (layer names `STOCK_HGHS`); quantity is tiny (93 t).
- **Consequence if wrong:** negligible (0.2 % of model tonnage).
- **Treatment:** Controlled (reported separately).
- **Status:** ACTIVE (2026-10-07)

### A-025 Within a cell, material is stacked in time order
- **Category:** ASSUMED
- **Assumption:** In each column, contributions placed in one interval are stacked oldest at the bottom (by dump time; rehandled material at interval start; UNK at mid-interval).
- **Need:** The internal stratigraphy of a fill increment is not observed.
- **Justification:** On an advancing tipping face, earlier material lies against the old face and later material outside/above it.
- **Consequence if wrong:** vertical position of loads within one increment (≤ increment thickness, median ~1–3 m).
- **Treatment:** Bounded by increment thickness; block vertical size is chosen accordingly (Phase 4).
- **Status:** ACTIVE (2026-10-07)

### A-026 Size segregation on the face does not change grade
- **Category:** ASSUMED (consequence of A-007)
- **Assumption:** Coarse fragments rolling to the toe are not modelled separately; with grade homogeneous within a load (A-007), segregation moves mass but not grade.
- **Need:** Tipped material segregates by size on the face (coarse to the toe), but no size-by-grade data exist to model its effect on grade.
- **Justification:** With grade homogeneous within a load (A-007, the only information available), any redistribution of a load's fragments leaves its grade unchanged; segregation would matter only if metal concentrated in particular size fractions (e.g. free gold in fines), which cannot be assessed with the supplied data.
- **Consequence if wrong:** toe material could be systematically lower/higher grade than modelled.
- **Treatment:** Listed as a limitation; recommend size-by-assay testing of reclaimed material.
- **Status:** ACTIVE (2026-10-07)

### A-027 Allocation cost = plan distance from the release point (isotropic)
- **Category:** ASSUMED
- **Assumption:** In the survey-constrained allocation, reaching fill cell p from release point r costs |p − r|; direction along vs across the crest is not distinguished.
- **Need:** Required to rank which fill cells each load most likely reached.
- **Justification:** Simplest rule consistent with the forward physics; no dozer-path data exist to calibrate anisotropy.
- **Consequence if wrong / observed effect:** because each interval's fill is an 80–100 m crescent while dumps cover only part of it, the survey constraint moves material laterally: median horizontal displacement 11.4 m, but 37 % of recorded mass moves > 20 m and 19 % > 30 m (max 46 m). This may be real dozer work along the crest, unrecorded loads, buffer timing or GPS error; the data cannot separate these.
- **Treatment:** Mass-weighted travel distance is carried into every block as an uncertainty indicator; Phase 5 tests ε and face-threshold sensitivity.
- **Status:** ACTIVE (2026-10-07)

### A-028 Block size 2 × 2 × 1 m; partial blocks by fill fraction, no air dilution
- **Category:** ASSUMED
- **Assumption:** Regular blocks of 2 m (E) × 2 m (N) × 1 m (Z), origin (511280, 7122280, 4470). No sub-blocking: each block stores the material volume it contains and `fill_fraction`; grades are tonnage-weighted over material present (blocks on the surface or against the pre-model base are not diluted with air or with unmodelled pre-existing material).
- **Need:** Assignment Task 5 requires justified block dimensions and partial-block treatment.
- **Justification:** 1 m vertical resolves the fill increments (median thickness 1–3 m) and the time-ordered stacking (A-025); 2 m plan is 2× the column resolution (1 m) and fine enough to represent the 10–30 m wide face bands, while the stated lateral placement uncertainty (~10 m, §5) is carried as an attribute rather than hidden by coarse blocks. Blocks can be re-aggregated to reclaim scale (e.g. 10 × 10 × 2.5 m) without loss because all quantities are extensive.
- **Consequence if wrong:** block-scale grade variability is resolution dependent; totals are not (exact integration).
- **Treatment:** Phase 5 robustness — **done:** 5 × 5 × 2 m (reclaim-scale) blocks give identical totals (exact integration, 1,285 blocks) and provenance-HIGH 6.2 kt vs 9.2 kt at 2 × 2 × 1 m — classes are scale dependent (see A-029).
- **Status:** ACTIVE (2026-10-07; tested)

### A-029 Provisional confidence classes from provenance indicators
- **Category:** ASSUMED (rule set)
- **Assumption:** HIGH if ≥ 90 % of block tonnes are recorded loads with trusted positions and the mass-weighted dump-to-final travel ≤ 15 m; MEDIUM if ≥ 70 % recorded and travel ≤ 30 m; otherwise LOW.
- **Need:** Task 5 requires an uncertainty indicator per block; the assignment's ethics scenario requires uneven data quality to be visible to decision makers.
- **Justification:** These indicators measure *how much of the block estimate rests on measured information* (recorded mass, trusted location) versus assumption (UNK/PRE grade) and model extrapolation (long travel). Thresholds are round numbers chosen to separate the observed populations (median travel 22 m); they are not calibrated against reclaim data (none exist). These are **not** JORC/NI 43-101 resource classes.
- **Consequence if wrong:** class boundaries move; the underlying indicators are exported and can be re-classified.
- **Treatment:** Phase 5 adds Monte-Carlo grade/tonnage dispersion per block and re-states the classes.
- **Sensitivity result (Phase 5, MODEL-GENERATED):** the classes depend on the mixing assumption through the travel indicator — HIGH tonnage is 13.9 kt at ε = 1 m, 9.2 kt at the base ε = 3 m and 2.6 kt at ε = 10 m (face threshold 30–36°: 9.1–9.5 kt; 4 × 4 m blocks: 7.2 kt). The class is therefore a *relative* ranking under the stated assumptions, not an absolute reliability measure; this is stated wherever classes are reported.
- **Status:** ACTIVE (2026-10-07; sensitivity added in Phase 5)

### A-030 Grade error: per-source multiplicative lognormal, log-SD 0.10
- **Category:** ASSUMED
- **Assumption:** In Monte-Carlo realisations the Cu, Au and Ag of each source group are multiplied by independent lognormal factors (mean 1, log-SD 0.10 ≈ 10 % CV); all loads of a source share the factor.
- **Need:** No assay/QC data or block-model error estimates were supplied; grades are source attributes (A-007).
- **Justification:** A 10 % relative error is a moderate allowance for block-model/estimation error of a dig block; making it per-source (not per-load) respects the observed data structure, so errors do not average out across loads from the same source.
- **Consequence if wrong:** the reported P10–P90 of grades and metal scales roughly linearly with this value.
- **Treatment:** Stated with every MC result; should be replaced by the mine's reconciliation statistics (mine-to-mill) when available.
- **Status:** ACTIVE (2026-10-07)

### A-031 Dump-position error: isotropic Gaussian, σ = 3 m per load
- **Category:** ASSUMED
- **Assumption:** Trusted dump coordinates carry a random horizontal error N(0, 3 m) per axis.
- **Need:** GPS accuracy of the FMS is not documented.
- **Justification:** Typical fleet GPS (non-RTK) horizontal accuracy is metres; the observed vertical residual spread (IQR ≈ 1.4 m, A-005) is consistent with metre-level horizontal error. A systematic antenna-to-tipping-point offset (~5–10 m towards the crest) is not included here — it is partly absorbed by the push step.
- **Consequence if wrong:** release points and therefore block-level grades shift locally; totals are unaffected.
- **Treatment:** Monte Carlo.
- **Status:** ACTIVE (2026-10-07)

### A-032 Final confidence = provenance class downgraded where Monte-Carlo dispersion is high
- **Category:** ASSUMED (rule set)
- **Assumption:** The provenance class (A-029) is lowered by one level if the block's MC coefficient of variation exceeds 10 % for Cu grade or 15 % for tonnes.
- **Need:** Combine data-provenance quality with numerical sensitivity in one indicator usable by planners.
- **Justification:** Round thresholds; with only random errors simulated, these flag blocks whose estimate is sensitive to plausible input errors. Epistemic uncertainties (f_v interpretation, UNK grade, mixing) are reported as scenarios/OAT ranges, not folded into this class.
- **Consequence if wrong:** class boundaries move; indicators are exported for re-classification.
- **Treatment:** Controlled; thresholds in config.
- **Sensitivity result (Phase 5):** final HIGH tonnage was 7.8 kt with 30 realisations and 5.2 kt with 60 — blocks near the CV thresholds change class as the SD estimate sharpens. The final class is reported with the realisation count and should be re-derived with ≥ 60 realisations.
- **Status:** ACTIVE (2026-10-07; sensitivity added)
