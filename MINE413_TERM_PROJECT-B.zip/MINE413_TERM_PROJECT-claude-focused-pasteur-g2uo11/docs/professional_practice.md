# Professional Accountability, Ethics, Equity and Limitations

This is the team-level response to assignment §6.2 and the basis for
report sections 13–15. Each student's individual D9 assessment must be
written by that student (see `team_templates.md`).

## 1. The scenario, restated against this stockpile

Management asks for a definitive Cu/Au inventory and a reclaim sequence for
next year. The evidence assembled here shows the conditions the scenario
describes are real for this dataset, not hypothetical:

| Scenario element | What the data show | Evidence |
|---|---|---|
| Some regions have substantial uncertainty | 11.7 kt (25 %) of modelled tonnes is LOW confidence on provenance grounds and 23.3 kt (49 %) after the Monte-Carlo downgrade; lateral placement error is of order 10 m (held-out EMD 12.2 m) | `inventory_by_confidence.csv`, `validation_metrics.csv` |
| Parts of the record are less complete for particular periods | FMS records are missing or sparse for 15 Mar before 17:43, 23–27 Mar and 29–30 Mar; 2,431 m³ (≈ 3.1 kt) of surveyed fill has no FMS record; 14 loads have a fallback coordinate | data register F6–F8; A-006, A-017 |
| A production target is easier to justify with expected values only | The inventory depends on an unresolved interpretation of the `Dens` column: under the base case 44.4 kt of recorded material is in the pile; under the alternative (payloads understated) the same volume would hold ≈ 65.6 kt | A-014, `uncertainty_summary.json` |

## 2. Professional response

1. **Report ranges, not a single number.** Every inventory figure is
   published with its MC P10–P90 range, the OAT range and, separately, the
   share resting on assumed grades (7.9 % of Cu metal). The headline must
   state the base-case assumption on `Dens` and the alternative scenario.
2. **Qualify or decline the "definitive" request.** A definitive inventory
   is not supportable until (a) the meaning of `Dens` / payload accuracy is
   confirmed (bulk-density test or weighbridge/strut-pressure check of a
   sample of loads), (b) the FMS gaps are investigated with dispatch and the
   contractor, and (c) the survey year/date conflict is resolved. A reclaim
   sequence may be drafted for HIGH/MEDIUM material now, with LOW material
   scheduled late and sampled before commitment.
3. **Do not attribute discrepancies to people.** Data gaps are reported by
   *time period and data system* (e.g. "no FMS records 23–27 Mar"), never
   by crew, contractor or operator. The platform contains no truck,
   operator or crew identifiers and none should be added to the
   discrepancy reports without a fair-process review. Missing records can
   arise from system outages, configuration changes, GPS loss or
   destination-code errors as easily as from operator behaviour.
4. **Make uneven data quality visible in the product used for decisions.**
   Recorded vs assumed metal, provenance shares and confidence classes are
   attributes of every block, so a planner filtering by grade sees the
   confidence of what they select.
5. **Validation before operational use.** Only the movement concept and the
   volume factor have been tested against held-out survey data. No
   reclaim assays exist to test block grades; the first reclaim campaign
   should be designed as a validation (sample by block, compare with
   predicted grade and confidence class).

## 3. Controls built into the workflow

| Control | Where |
|---|---|
| No deletion of questionable data; every flag has a stated model action | `qaqc.RULES`, `fms_flagged.csv` |
| Manual interventions only through a register requiring reason, author, date; applied and reported in every run | `config/manual_interventions.csv`, `audit.py` |
| Every run records inputs (SHA-256), git commit, library versions, full configuration, interventions, results; previous runs archived | `run_manifest.json`, `run_history.csv`, `history/` |
| Assumptions have IDs, evidence category, consequence and treatment; config keys cite them | `assumption_register.md`, `config/default.toml` |
| Recorded vs assumed metal never mixed silently | block attributes, inventories |
| Conservation checks fail loudly if mass/metal are created or lost | `allocation_checks.csv`, tests |
| Test suite must pass before a model is issued | `tests/` |
| AI-generated code and text verified and disclosed | `ai_and_software_disclosure.md` |
| Evidence category on every reported quantity; "VALIDATED" reserved for held-out tests | all outputs |

**Recommended sign-off** (organisational, not software): model owner
(planning engineer) runs and checks the acceptance list in
`platform_guide.md` §4; survey reviews closure and date checks; geology
reviews grade assumptions (A-007, A-023, A-030); processing reviews the
inventory before plant-feed forecasting. A model issued without these
sign-offs should be marked "preliminary".

## 4. Equity and inclusive decision-making

| Consideration | Response |
|---|---|
| Systematic bias from missing or unequal-quality data | Gaps are concentrated in specific periods (night of 14–15 Mar, 23–27 Mar, 29–30 Mar). Material from those periods is LOW confidence and carries assumed grades; this is a property of the record, not of the material or of any group. |
| Wrongly attributing discrepancies to crews/contractors | See §2.3 — the platform reports by period and system only. |
| Explainability to people affected | Each block's estimate can be traced to its loads (`supplies.csv`, `load_final_positions.csv`) and assumptions; the methodology is written for a non-developer. |
| Inclusion of planning, geology, survey, operations, processing | Sign-off roles above; assumption register entries flag which group should confirm each one (A-001 survey, A-004/A-007 geology, A-008 operations/dispatch, A-014 processing/metallurgy). |
| Usability across programming skill levels | Three commands for routine use; outputs are CSV/PNG/VTK; parameters in one commented text file. |
| Fair and responsible use | The confidence class is a planning aid, not a resource classification; it must not be used to compare crews or contractors. |

## 5. Principal limitations

1. **Survey files are fill solids.** Cuts are seen only where later refilled
   (583 m³ revealed); the pile top away from the face and the pre-15-March
   stockpile are not described, so the block model covers only material
   placed 15–30 March.
2. **Density/tonnage ambiguity (A-014).** Volumes are explained either by
   ≈ 48 % bulking or by ≈ 32 % under-recorded payloads; the data cannot
   distinguish them. This dominates absolute tonnage and metal.
3. **Grades are source averages (A-007).** Within-source variability is
   unknown; block grade variability is understated.
4. **Lateral placement is weakly constrained.** 37 % of recorded mass is
   moved > 20 m by the survey-constrained allocation (A-027); individual
   loads are located to ~10 m at best.
5. **Unrecorded material (≈ 3.1 kt) carries assumed grades** (A-023).
6. **No independent grade validation** — no reclaim, drilling or sampling
   data exist.
7. **Literature values** (swell, repose angle) were taken from search
   summaries; primary sources were not accessible from the build
   environment and must be checked.

## 6. Recommendations for mine implementation

1. Confirm with the survey department the date/year convention and that
   files are fill solids; request cut solids (or full surfaces) as well.
2. Resolve A-014: weigh a sample of loads, and/or measure in-pile bulk
   density (excavate-and-weigh or calibrated reclaim tonnage vs survey).
3. Investigate FMS gaps (23–27 Mar, 29–30 Mar, before 15 Mar 17:43) with
   dispatch; add stockpile destination validation to the FMS.
4. Fix the fallback-coordinate behaviour of the FMS (14 loads).
5. Add truck and source/dig-block IDs to the export (for traceability, not
   for performance attribution).
6. Design the first reclaim as a validation campaign (block-tagged sampling).
7. Re-run the platform after every survey; review `change_report.txt` and
   the acceptance checklist before issuing a model.
