# Definition of Done — Assignment Requirements → Evidence

Status: **DONE** = produced and checked in this repository · **TEAM** = must be produced by the students themselves (cannot be delegated) · **PARTIAL** = produced with a stated limitation.

## Tasks 1–8

| Requirement | Status | Evidence |
|---|---|---|
| Task 1 — QA/QC: coverage, CRS/units, missing/duplicate, anomalous locations, tonnages, grades, FMS vs survey consistency, survey resolution/noise, temporal alignment; visualisations; no silent deletion | DONE | `docs/data_register.md`, `outputs/01_qaqc/*`, `qaqc.RULES` |
| Task 2 — growth S_t→S_t+1, increases/decreases, FMS vs survey, density/swell justification, discrepancies quantified | DONE (decreases only where revealed — limitation) | `outputs/02_growth/*`, methodology §3–4, A-013/A-014 |
| Task 3 — movement algorithm answering A–J | DONE | methodology §5 (table §5.5), `movement.py`, `physics.py`, `transport.py` |
| Task 4 — Assumption Register (all listed topics, 5 fields each) | DONE | `docs/assumption_register.md` (A-001 – A-032) |
| Task 5 — block model: coordinates, volume, tonnage, Cu, Au, contained Cu/Au, uncertainty; justification of block size, partial blocks, density, compositing, mixing, uncertain regions | DONE | `outputs/04_blockmodel/*`, methodology §6, A-028/A-029 |
| Task 6 — validation: geometry, mass, metal, temporal, robustness; quantitative measures | DONE (block grades not validatable — no data) | `outputs/05_uncertainty/validation_metrics.csv`, methodology §7 |
| Task 7 — uncertainty & sensitivity over listed sources; distinguish measured/inferred/assumed/model-generated | DONE | `outputs/05_uncertainty/*`, attribute dictionary with evidence column |
| Task 8 — platform steps 1–11; reproducibility standard | DONE | `docs/platform_guide.md`, `audit.py`, `tests/test_platform.py` |

## Deliverables

| Deliverable | Status | Evidence |
|---|---|---|
| D1 Team charter & work plan | TEAM | template in `docs/team_templates.md` |
| D2 Data & assumption register | DONE | `docs/data_register.md`, `docs/assumption_register.md` |
| D3 Technical methodology | DONE | `docs/methodology.md` |
| D4 Block model & outputs | DONE | `outputs/04_blockmodel/`, `outputs/05_uncertainty/block_uncertainty.csv` |
| D5 Automated platform | DONE | `stockpile_model/`, `README.md`, `docs/platform_guide.md`, `requirements.txt` |
| D6 Final engineering report | DONE (draft for team review) | `docs/engineering_report.md` |
| D7 Presentation | TEAM | outline in `docs/team_templates.md` |
| D8 Individual teamwork reflection | TEAM | template only |
| D9 Individual ethics/equity assessment | TEAM | shared evidence in `docs/professional_practice.md` |

## §12 Submission checklist

| Item | Status |
|---|---|
| Team Charter and Work Plan submitted | TEAM |
| Data/Assumption Register included | DONE |
| Algorithm documented with sufficient technical detail | DONE |
| Mass and metal conservation checked | DONE (tests + per-interval checks + validation table) |
| Stockpile block model and export files included | DONE |
| Validation metrics and reconciliation results included | DONE |
| Uncertainty/sensitivity analysis completed | DONE |
| Automated platform and operating documentation included | DONE |
| AI/software use fully disclosed and verified | DONE (`docs/ai_and_software_disclosure.md`); team must verify the reference list |
| Professional accountability and EDI requirements addressed | DONE (team level) / TEAM (individual D9) |
| Individual teamwork reflection and peer/self-assessment submitted | TEAM |
| Individual ethics/equity assessment submitted | TEAM |
| All files named clearly and can be opened by the instructor | DONE (CSV, PNG, MD, JSON, VTK; DXF/CSV inputs in original zip) |

## Items the team must confirm before submission
1. A-001 survey year, A-004 units, A-014 meaning of `Dens` — with the instructor/mine if possible.
2. References in the report (§17) checked against the original sources.
3. Review of every assumption value as the team's own engineering judgement.
