# Engineering Decision Log

Each entry records what was decided, the evidence, the alternatives
rejected, and the consequence. Entries are appended in order; a decision that
is later reversed is not deleted — a new entry supersedes it.

---

### ED-001 (Phase 1) Python package + TOML config + CLI as the platform
- **Decision:** implement the platform as a Python package (`stockpile_model`) with a TOML configuration, a command-line interface and pytest tests, rather than spreadsheets or a GUI.
- **Why:** auditability (code + config + hashes are versionable), reproducibility (one command re-runs everything), and the assignment states GUI is optional. Dependencies are limited to widely used open-source libraries (numpy, pandas, scipy, matplotlib, ezdxf).
- **Consequence:** users need Python; operating instructions are in `README.md`.

### ED-002 (Phase 1) Never delete data; flag and state the model action
- **Decision:** every FMS record is kept with `qa_*` flags and usage columns; every survey face is counted (degenerate faces dropped from rasterisation only).
- **Why:** assignment Task 1 ("do not simply delete questionable data") and traceability to the source row.

### ED-003 (Phase 1) Interpret the DXFs as fill-increment solids (A-009)
- **Decision:** rasterise each DXF to top and base elevations on a common 0.5 m grid; treat the difference as the fill volume of that interval.
- **Evidence:** two hits per covered cell (closure); exact base/top stacking of consecutive solids; crescent-shaped partial coverage.
- **Alternative rejected:** treating each file as a full topographic surface and differencing consecutive "surfaces" — this would difference two unrelated partial bands and is contradicted by the closure test.
- **Consequence:** the movement problem becomes "allocate each interval's loads into a known fill volume", and cut is only observable where later refilled.

### ED-004 (Phase 1) Dump-Z check uses the surface envelope of the interval
- **Decision:** a dump's Z is compared with [base, top] of its interval's fill solid at that XY (or the latest earlier top if outside the solid).
- **Evidence:** the first implementation compared Z with the start-of-interval surface and flagged 13 dumps on 19–20 March that were in fact on fill that had grown 5–8 m during the interval.
- **Consequence:** `LOC_Z_INCONSISTENT` fell from 16 to 2 records (one of them a fallback coordinate). The earlier flags were a modelling error, not a data error.

### ED-005 (Phase 1) Rasteriser edge-ownership rule
- **Decision:** cell centres lying exactly on a triangle edge are owned by one triangle (half-open rule) so they are not double counted.
- **Evidence:** a unit test on a two-triangle plane found centres on the shared diagonal counted twice; z values were unaffected, but the closure-check hit counts were.
- **Consequence:** closure statistics are now exact; volumes unchanged.

### ED-006 (Phase 2) Mass balance uses net volume, not fill volume
- **Decision:** compare FMS supply with `V_net = V_fill + V_missing_fill − V_cut` (revealed quantities from the composite-surface tracker).
- **Why:** material cut from an earlier fill and pushed into a later one would otherwise be counted twice. Effect here is small (net 34,627 vs fill 35,107 m³) but the principle matters for future data.

### ED-007 (Phase 2) Calibrate f_v robustly on consistent intervals; do not force per-interval densities
- **Decision:** `f_v` = pooled ratio over intervals within median ± 3 robust SD (1.476); outlier intervals keep their unexplained volume as UNK.
- **Alternatives rejected:** (a) fit a density per interval so every interval balances — produces 0.85–0.90 t/m³ in intervals 0/7/9, physically implausible, and hides FMS gaps; (b) choose `f_v` minimising total unexplained volume (≈ 1.55) — circular, because it presumes the FMS record is complete.
- **Evidence:** temporal stability (1.469 first half vs 1.476 all) and held-out prediction error 3.2 %.

### ED-008 (Phase 2) Stock-flow reconciliation with pad buffer and explicit UNK
- **Decision:** reconcile each interval with FIFO carry-over of unpushed loads and an explicit unrecorded-material term beyond a survey tolerance. Mass of every recorded load is conserved exactly (residual 0.0 t on the real data).
- **Why:** answers assignment Task 3-G (no creation/loss of material) while keeping data gaps visible.

### ED-009 (Phase 2) Output QA: figure label error corrected
- **Observation:** the first version of `fig_growth_maps.png` labelled the colour scale of the revealed-change map backwards (cut was shown red but labelled blue). Detected by inspecting the figure against the table values; corrected before commit. No numerical result was affected.

### ED-010 (Phase 3) Two-tier movement model: forward physics for validation, OT for reconstruction
- **Decision:** a forward model (push to nearest face cell → slide to toe → cone at the angle of repose) predicts each interval's fill *without* its survey; a survey-constrained entropic optimal transport then allocates loads into the observed fill.
- **Why:** the constrained allocation reproduces the surveyed geometry by construction, so geometric agreement alone would be circular evidence. The forward model provides a falsifiable test on held-out intervals (Task 6).

### ED-011 (Phase 3) Avalanche: fixed bed + mobile layer; geometric deposition used for validation runs
- **Evidence:** the first cellular automaton relaxed the *existing* surveyed faces (which stand up to 42–45°), producing −714 m³ of spurious negative deposition and a footprint 2.4× too large. Corrected to a non-erodible bed with a mobile layer. The iterative automaton still needed 40–50 s per interval, so validation uses an equivalent direct construction (steepest-descent slide while steeper than repose, then a cone truncated by the bed, apex by bisection; volume exact). The automaton is kept and unit-tested.

### ED-012 (Phase 3) Exact conservation after sparsification
- **Evidence:** the first sparsification re-balanced columns last; 6 of 10 intervals kept up to 1 % supply error (recorded mass 44,421.27 t instead of 44,422 t; Au −45 g in one interval), caught by the per-interval conservation check.
- **Fix:** support = cell-significant ∪ supply-significant entries; IPF ends with row (supply) scaling. Mass/metal exact to 10⁻¹⁰; geometry error ≤ 10⁻¹² relative.

### ED-013 (Phase 3) EMD at 4 m aggregation
- **Evidence:** exact LP EMD at 2 m took 80–180 s per comparison; values at 3, 4 and 6 m were 11.809, 11.805 and 11.811 m (interval 3), i.e. insensitive. 4 m adopted (≈ 1 s).

### ED-014 (Phase 3) Lateral transport is reported, not suppressed
- **Observation:** 37 % of recorded mass is displaced > 20 m from its dump point in the reconstruction (A-027).
- **Decision:** keep the survey-constrained solution (it is the only one consistent with both the measured fill and the measured tonnage) but carry mass-weighted travel distance into the block model as an uncertainty indicator rather than impose an untestable maximum push distance.

### ED-015 (Phase 4) Travel indicator for rehandled material; a wrong statement corrected
- **Observation:** block `travel_m` reached 117 m. I first described this as impossible (the maximum *load-centroid* displacement is 46 m) and found a genuine semantic error: rehandled material had its travel overwritten with (total mass × last move), while the block denominator excluded its unrecorded share. Fixed: travel accumulates over recorded, located mass only, and rehandled material keeps its history.
- **Correction:** the 117 m values persisted after the fix and are real model output: parts of loads (not centroids) travel up to ~117 m to fill the north-east lobe surveyed on 28 March, which is far from that interval's dump points. 227 blocks / 452 t (1 %) have travel > 50 m; all are LOW confidence. The earlier "impossible" statement was wrong and is withdrawn.

### ED-016 (Phase 4) Recorded vs assumed metal kept separate in every block and inventory
- **Decision:** block attributes `cu_t_recorded`/`cu_t_assumed` (and Au) are exported separately; inventories report both.
- **Why:** 7.9 % of Cu metal (321 t of 4,062 t) and 7.3 % of Au rests on assumed grades of unrecorded material; decision makers must be able to exclude it (assignment §6.2 scenario).

### ED-017 (Phase 5) Inventory totals include recorded material that cannot be placed
- **Observation:** in the first sensitivity run, f_v = 1.65 reduced contained Cu to 3,650 t only because loads left in the pad buffer at the end were excluded from the *block* model — but that material is still in the stockpile (on the unsurveyed pad top).
- **Decision:** totals = located (block-model) material + unplaced recorded material (reported separately, with its recorded grade). Corrected f_v = 1.65 result: 3,834 t Cu (2,108 t unplaced). The block-model stage now writes `unplaced_recorded_material.csv`.

### ED-018 (Phase 5) No hard-coded numbers in validation outputs
- **Observation:** two rows of the first validation table (resolution volumes, column-top agreement) were typed-in numbers from an earlier run; they would silently go stale with new data.
- **Fix:** both are computed in the growth and movement stages and read by the validation table.

### ED-019 (Phase 5) Confidence classes reported as relative rankings
- **Evidence:** HIGH tonnage 2.6–13.9 kt across ε = 10–1 m (A-029 sensitivity result).
- **Decision:** classes are presented as a ranking under stated assumptions, with the indicators exported for re-classification; never as resource categories.

### ED-020 (Phase 6) Platform defect found by the incremental-update test
- **Observation:** on a fresh output directory the movement stage failed writing its layer cache (`outputs/.cache` assumed to exist). Found by `tests/test_platform.py`; fixed by creating the directory.

### ED-021 (Phase 6) Engineering report generated from run outputs
- **Decision:** `docs/engineering_report.md` is produced by `python -m stockpile_model report` from a template and the latest run's JSON/CSV outputs; numbers in the summary and tables are never typed by hand. A like-for-like error in the template (alternative-scenario *recorded* tonnes compared with *total* base tonnes) was caught on review and corrected before generation.
