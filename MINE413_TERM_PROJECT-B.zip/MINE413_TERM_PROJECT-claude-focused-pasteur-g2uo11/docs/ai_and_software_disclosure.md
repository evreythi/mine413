# AI and Software Disclosure (assignment §6.1)

## AI system used

| Item | Disclosure |
|---|---|
| AI system / tool | Claude (Anthropic), used through Claude Code, an agentic coding environment with shell, file and web-search access |
| Purpose | Data audit, code implementation of the platform, numerical analysis, figure generation, drafting of technical documentation (registers, methodology, report text) |
| Nature of assistance | The AI wrote the Python package, tests, configuration and documentation drafts in this repository, ran them on the supplied data, inspected outputs and figures, and proposed engineering interpretations. Literature look-ups were made with a web-search tool; primary sources could not be opened from the execution environment (network proxy), so literature values are flagged as "search-result summary" in the Assumption Register. |
| How output was checked | (1) 65 automated tests (unit, real-data regression, platform), including unit tests on synthetic geometry with known answers and regression tests on the real data; (2) conservation checks inside the pipeline (mass, Cu, Au to < 10⁻⁸); (3) independent cross-checks (exact divergence-theorem volume vs raster volume; EMD insensitivity to aggregation); (4) held-out temporal validation of calibrated parameters; (5) visual inspection of every figure against the numbers, which caught a mislabelled colour scale (ED-009) and two modelling defects (ED-004, ED-011); (6) the decision log records defects the AI introduced and later corrected (ED-005, ED-012, ED-015), including one wrong statement that was withdrawn. |
| What remains the team's responsibility | Every engineering judgement in `assumption_register.md` (values, justifications, acceptability); confirming the survey year (A-001), the units (A-004) and the meaning of the `Dens` column (A-014) with the mine; verifying literature citations against primary sources; the confidence-class rule set (A-029/A-032); the professional recommendations; all individual deliverables (D1, D7, D8, D9). Students remain professionally responsible for the submitted work (assignment §6.1). |

AI-generated technical claims were treated as **unverified** until checked
against the data, mathematical consistency, conservation laws, numerical
tests or (where possible) literature. The evidence category of every
reported result (MEASURED, CALCULATED, INFERRED, ASSUMED, MODEL-GENERATED,
VALIDATED) is stated next to it; "VALIDATED" is reserved for comparisons
against held-out survey solids.

## External software and algorithms

| Component | Use | Licence |
|---|---|---|
| Python 3.13 | language | PSF |
| NumPy, pandas | arrays, tables | BSD-3 |
| SciPy | distance transforms, `linprog` (HiGHS) for exact Earth mover's distance, `logsumexp` | BSD-3 |
| Matplotlib | figures | PSF-based |
| ezdxf | reading DXF 3DFACE entities | MIT |
| pytest | tests | MIT |
| Sinkhorn algorithm (log-domain) | entropic optimal transport (Cuturi 2013; Peyré & Cuturi 2019, *Computational Optimal Transport*) — implemented from the published equations, not copied code | — |
| Sand-pile / angle-of-repose cellular automaton | standard granular-flow idea, implemented from first principles | — |

No commercial mine-planning software was used. Exact library versions of
each run are recorded in `outputs/run_manifest.json`.
