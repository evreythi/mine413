# Technical Methodology (Deliverable D3)

This document describes the data model, equations and algorithms implemented
in `stockpile_model/`. Section numbers are referenced from code docstrings.
Assumption IDs (A-xxx) refer to `assumption_register.md`; decision IDs
(ED-xxx) to `decision_log.md`.

## 1. Data model

### 1.1 Grid
All surfaces are sampled on one plan grid (A-010): origin (511280, 7122280),
0.5 m cells, 300 × 280 cells. Cell (r, c) has centre
`x = x0 + (c + ½)Δ`, `y = y0 + (r + ½)Δ` and area `a = Δ² = 0.25 m²`.

### 1.2 Survey solids
Each DXF is a set of triangles `T`. For every cell centre p, all triangles
containing p in plan are found (barycentric test, half-open edge rule
ED-005) and their linearly interpolated elevations collected. For the
supplied files every covered cell receives exactly two values (A-009):
`top_k(p) = max`, `base_k(p) = min`. The fill thickness is
`h_k(p) = top_k(p) − base_k(p)` and the solid volume
`V_k = a · Σ_p h_k(p)`.

Independent check: the enclosed volume of a closed, consistently oriented
triangulated shell is `V = Σ_f A_xy(f) · z̄(f)` (divergence theorem with
F = (0, 0, z), exact for planar faces). Raster and exact volumes agree within
0.05 % for every solid; totals at 0.25 / 0.5 / 1.0 m cells are 35,109 /
35,107 / 35,096 m³ (exact 35,107 m³).

### 1.3 FMS loads
Load i: recorded mass `T_i`, grades `Cu_i, Au_i, Ag_i`, density `Dens_i`,
dump position `(x_i, y_i)` and time `t_i`. QA rules (`qaqc.RULES`) set three
usage flags; nothing is deleted (ED-002). Loads with an untrusted position
(A-006) keep mass and grade but have no spatial prior.

## 2. Temporal alignment
Survey k labelled day `D_k` closes interval k at
`t_k = D_k 00:00 + 31 h` (A-003). Interval k = `(t_{k−1}, t_k]`; the first
interval opens 24 h before `t_0` (A-011). The 31 h cut-off was inferred by
scanning 0–36 h and maximising agreement between interval tonnage and fill
volume (Pearson r = 0.97 vs 0.73 at midnight), independently supported by the
shift-change gap in dump times.

## 3. Growth tracking (composite surface)
A per-cell state `Z(p)` (latest known surface) is updated in time order:

```
for k = 0..K-1:
    for p in solid k:
        if Z(p) known:
            d = base_k(p) − Z(p)
            cut_k(p)      = max(−d, 0)   if d < −τ      (revealed cut)
            missfill_k(p) = max( d, 0)   if d >  τ      (revealed missing fill)
        else:
            z_pre(p) = base_k(p)                          (pre-model surface)
        Z(p) = top_k(p)
```

with τ = 0.10 m (A-013). The net volume placed in interval k is

`N_k = V_k + a·Σ missfill_k − a·Σ cut_k`   (ED-006).

Real data: Σ V = 35,107 m³, revealed cut 583 m³, revealed missing fill
103 m³, Σ N = 34,627 m³.

## 4. Tonnage–volume reconciliation (stock-flow model)
In-pile volume of load i (A-014): `v_i = f_v · T_i / Dens_i`.

**Calibration.** For each interval `r_k = N_k / Σ_{i∈k} T_i/Dens_i`. With
median m and robust SD s = 1.4826·MAD, intervals with |r_k − m| ≤ 3s are
used and `f_v = Σ N_k / Σ Σ T_i/Dens_i` over those intervals. Real data:
f_v = 1.476 (intervals 1–6, 8); outliers 0, 7, 9 are the intervals with
visible FMS gaps. Calibrating on the first half only gives 1.469; predicting
the held-out consistent intervals gives errors −5.2 %, −0.0 %, +4.2 %.

**Stock-flow.** A FIFO buffer `B` of (load, remaining fraction) holds material
dumped but not yet pushed into surveyed fill (A-015). For interval k:

```
B ← B + loads of interval k            (in dump-time order)
S_k = Σ_B remaining volume
take volume N_k from the front of B     (partial loads allowed)
if N_k > S_k:
    E_k = N_k − S_k ;  τ_k = σ_z · footprint_k     (A-016, σ_z = 0.05 m)
    absorbed = min(E_k, τ_k)  -> placed volumes stretched (density lowered)
    UNK_k    = E_k − absorbed -> unrecorded material, unknown grade (A-017)
```

**Conservation.** Every recorded tonne is placed exactly once or remains in
the end buffer: on the real data, recorded 44,422 t = placed 44,422 t +
unplaced 0 t (residual 0.0 t; max per-load fraction error 2·10⁻¹⁶). Volume:
`Σ N_k = Σ placed volume + Σ UNK_k` by construction.

Results: placed FMS material 32,196 m³ at a mean density of 1.38 t/m³;
UNK = 2,431 m³ (intervals 0, 7, 8, 9); peak pad buffer 726 m³ (7 loads).

## 5. Material-movement algorithm

```
Truck dump (FMS x,y,t,T,grade) ──► pad buffer (FIFO, §4) ──► dozer push to nearest
active-face cell (release point) ──► gravity: rest within the surveyed fill
(allocation by optimal transport) ──► stacked in time order in each 1 m column
```

### 5.1 Forward physics model (prediction, used for validation)
Inputs for interval k: surface at the start of the interval `Z_{k−1}` (latest
solid tops; elsewhere the pre-model terrain), the loads placed in k and
their volumes. Nothing from survey k is used.

1. Face cells: slope(`Z_{k−1}`, 3×3 smoothed) ≥ θ_face.
2. Release point `r_i` = nearest face cell to the dump point (A-019).
3. Slide: from `r_i` follow steepest descent while the drop to the lowest
   neighbour exceeds `tan φ` (φ = 37°, A-018).
4. Deposit: thickness `max(0, H − tan φ · |p − s| − S(p))`, with apex H solved
   by bisection so the deposited volume equals `v_i` exactly; S is updated
   (loads in time order).
5. Loads without a trusted position and UNK are spread uniformly over face cells.

Score: Earth-mover's distance (exact LP, 4 m aggregation) between predicted
and observed fill, after rescaling to equal volume.

| Held-out intervals 5–9 (θ_face chosen on 0–4) | Mean EMD |
|---|---:|
| Push to crest + repose (model) | **12.2 m** |
| No dozer movement (cone at dump point) | 14.5 m |
| Uniform over active face | 27.9 m |

### 5.2 Survey-constrained allocation (reconstruction)
For interval k, sinks are 1 m model cells p with volume
`b_p = a·Σ(fill + missing fill)` aggregated from 0.5 m rasters; supplies are
(i) rehandled material from revealed cuts (§5.3), (ii) the load fractions
placed by the reconciliation, (iii) UNK. `Σ a_i = Σ b_p` holds by construction
(checked: relative gap ≤ 10⁻¹⁵).

Cost `C_ip = |p − r_i|` for supplies with a release point; a constant (the
mean cost) for supplies without one. The plan solves

`min_π ⟨C, π⟩ + ε KL(π ‖ a bᵀ)` s.t. `π1 = a`, `πᵀ1 = b`,

by log-domain Sinkhorn (ε = 3 m, A-021), then sparsified (A-022).

### 5.3 Elevation decreases (cuts)
At the start of interval k, each column with revealed cut volume `c_p` is
lowered by `c_p / a`; layers above the new top are removed proportionally
(uniform within a layer); removed composition is pooled per connected cut
cluster into a rehandle supply located at the cluster centroid. Cut below the
pre-model surface removes PRE material (A-024).

### 5.4 Column state and sequential updating
State = flat table of layers (cell, interval, supply, z_bot, z_top, 17
extensive components: volume, mass, recorded/UNK/PRE/location-unknown/
rehandled mass, recorded and assumed Cu/Au/Ag metal, Σm·Cu², Σm·Au²,
Σm·travel, Σm·day). New layers in a cell are stacked from the current column
top in time order (A-025). The state after interval k is the initial
condition of interval k+1.

### 5.5 Answers to the required questions (Task 3)
| | Question | Implementation |
|---|---|---|
| A | Initial placement | Each load (or buffer fraction) is a supply with its recorded mass, volume `f_v·T/Dens` and grade at its dump XY (fallback-coordinate loads: no position). |
| B | Direction | Shortest path to the nearest active-face cell (slope ≥ 33°), then down the face. |
| C | Distance / stopping | Push stops at the face; on the face material stops where the slope falls below 37° (forward model) or where the surveyed fill has capacity, preferring nearer cells (allocation). |
| D | Downslope behaviour | Steepest-descent slide + repose-angle deposition (forward); surveyed fill geometry (reconstruction). |
| E | Mixing | Mass-weighted (extensive) mixing in every cell; lateral mixing length ε = 3 m; vertical time order. |
| F | Surface reconciliation | Hard constraint: allocation fills exactly the surveyed fill volume of each cell; final column tops within ±8 cm of the surveyed surface. |
| G | Mass conservation | Supplies are split, never created: recorded mass 44,422 t in = out (error < 10⁻⁹ t); per-interval checks. |
| H | Metal conservation | Metal carried as extensive components: Cu 3,740.97 t and Au 354,820.82 g in = out (error < 10⁻⁸). |
| I | Sequential updating | Layered column state + pad buffer carried between intervals. |
| J | Numerical stability | Volumes insensitive to cell size (0.25–1 m: ±0.03 %); EMD insensitive to aggregation (3–6 m: ±0.01 m); Sinkhorn tolerance 10⁻¹⁰; sensitivity to ε, θ_face and model cell in Phase 5. |

### 5.6 Observed behaviour of the reconstruction
Median push distance 2.9 m; median horizontal displacement dump → final
centroid 11.4 m, but 37 % of recorded mass moves > 20 m because the surveyed
fill crescent is longer than the zone covered by dump points (A-027, ED-014).
Each load spreads over a median 8.0 m (mass-weighted radius).

## 6. Block model

**Geometry.** Regular 2 × 2 × 1 m blocks, origin (511280, 7122280, 4470)
(A-028). Each layer (1 m column cell, `[z_bot, z_top]`, extensive vector
`q`) contributes to block slice `[z0 + kΔz, z0 + (k+1)Δz]` the amount
`q · overlap / (z_top − z_bot)`; all contributions are summed per block
(`blockmodel.integrate_layers`). Because `q` is extensive, block totals equal
layer totals exactly (volume, tonnes, Cu, Au errors < 10⁻⁸).

**Attributes** (`outputs/04_blockmodel/block_model_dictionary.csv` lists
units and evidence category of each):

| Attribute | Definition |
|---|---|
| `volume_m3`, `fill_fraction` | material volume in block; ÷ block volume (partial blocks) |
| `tonnes`, `density_t_m3` | Σ mass; mass ÷ volume |
| `cu_pct`, `au_gpt`, `ag_gpt` | (recorded + assumed metal) ÷ tonnes |
| `cu_t`, `au_g`, `au_oz` | contained metal; split `*_recorded` / `*_assumed` |
| `tonnes_recorded/unrecorded/premodel/location_unknown/rehandled` | provenance of the tonnes |
| `frac_recorded`, `frac_trusted`, `frac_assumed_grade` | provenance shares |
| `cu_mix_sd`, `au_mix_sd` | √(Σm·g²/Σm − ḡ²): grade heterogeneity of the material mixed into the block |
| `travel_m` | mass-weighted dump → final distance of located recorded material |
| `confidence` | HIGH / MEDIUM / LOW (A-029) |

**Results (MODEL-GENERATED, base case):** 11,392 blocks; 34,695 m³;
47,596 t at 8.54 % Cu, 8.04 g/t Au; Cu 4,062 t (3,741 t recorded + 321 t
assumed); Au 12,304 oz. By confidence: HIGH 9,204 t, MEDIUM 26,670 t,
LOW 11,722 t. Pending (dumped after the last survey): 228 t.

**Domain.** Only material placed between 15 Mar 07:00 and 30 Mar 07:00 within
the surveyed fill solids (plus 93 t of pre-model material re-handled by
cuts). The pre-existing stockpile beneath the pre-model surface is not
modelled because no data describe it.

**Exports.** `block_model.csv` (all attributes), `block_model_minesoftware.csv`
(XC, YC, ZC, XINC, YINC, ZINC + key fields), `block_model.vtk` (ParaView),
inventories (total, by confidence, by bench) and grade–tonnage table.

## 7. Validation and uncertainty

### 7.1 What counts as validation here
The survey-constrained reconstruction reproduces the surveyed geometry by
construction, so agreement with the surveys used to build it is a
*consistency check* (CALCULATED), not validation. VALIDATED is used only for
predictions compared with survey data **not used** to fit the parameter
being tested:

| Test | Calibrated on | Tested on |
|---|---|---|
| Volume factor f_v predicts interval net volume | intervals 0–4 | consistent intervals 5, 6, 8 |
| Face threshold of the forward model; forward prediction of fill location | intervals 0–4 | intervals 5–9 |

No independent observation of grade inside the pile exists (no reclaim,
drilling or sampling), so **block grades are not validated**; they are
MODEL-GENERATED from MEASURED source grades.

### 7.2 Performance measures
`outputs/05_uncertainty/validation_metrics.csv` lists every measure with
its evidence category: held-out EMD and thickness RMSE (geometry), recorded
tonnes and metal in = out (mass/metal balance), f_v hold-out error, survey
cut-off inference, temporal stability of calibrated parameters, resolution
robustness, OAT and Monte-Carlo ranges. Spatial error maps of the held-out
forward predictions: `fig_heldout_error_maps.png`.

### 7.3 One-at-a-time sensitivity
Each uncertain parameter is set to a low and a high value with all others at
base (`[[uncertainty.oat]]` in config): f_v (1.35/1.65), survey cut-off
(30/34 h), σ_z (0.02/0.10 m), ε (1/10 m), face threshold (30/36°), pad
buffer (off/on), UNK grade (min/max source grade, analytic), sparsification
(0.5/2 %), block size (2 × 2 × 1 / 5 × 5 × 2 m), model cell (0.5/1 m); and,
for the forward model, the angle of repose (34/37/40°). Reported: inventory totals (located +
unplaced material), HIGH/LOW tonnage, and the tonnage-weighted mean absolute
change of block Cu and Au relative to base (spatial effect).

### 7.4 Monte Carlo (random errors)
For realisation r: payload `T_i + U(−19, 19)` t; per-source lognormal grade
factors (log-SD 0.10); dump position `+ N(0, 3 m)` for trusted loads; f_v
from a bootstrap of the calibration intervals. The full chain
reconciliation → movement → block model is re-run. Per block: mean, SD, P10,
P90 of tonnes, Cu % and Au g/t. Totals: P10/P50/P90.

### 7.5 Final confidence class
Provenance class (A-029) lowered one level if Cu CV > 10 % or tonnes
CV > 15 % (A-032). Because classes depend on ε and block size (A-029
sensitivity result), they are a relative ranking under stated assumptions.

### 7.6 Scenario not covered by random errors
A-014 alternative (recorded payloads understate mass; `Dens` is the in-pile
density): recorded tonnes and metal scale by f_v (≈ 1.48). Reported
separately as a scenario, never mixed into P10–P90.
