# Templates for Team and Individual Deliverables (D1, D7, D8, D9)

These deliverables assess the team's own work and each student's own
reflection. They **cannot be written by an AI or by another team member** —
doing so would misrepresent individual contribution. This file only gives
structure; replace every `[...]` with your own content.

## D1 — Team Charter and Work Plan
- Team members and initial roles: [name — role (e.g. data QA lead, algorithm lead, platform lead, validation lead, report lead)]
- Communication channels and expected response times: [...]
- Decision-making process (consensus / majority / lead-decides with escalation): [...]
- Disagreement resolution procedure: [...]
- Meeting cadence and contribution expectations: [...]
- Internal technical review and QC (e.g. two-person review of every assumption change and every model issued; test suite must pass): [...]
- Respectful and inclusive participation expectations: [...]
- Work plan (tasks, owners, dates) mapped to assignment Tasks 1–8: [...]

## D7 — Presentation outline (every member presents)
1. Problem and data (what the surveys really are; FMS gaps) — [presenter]
2. QA/QC and assumptions (cut-off inference, fallback coordinates, A-014) — [presenter]
3. Movement algorithm (forward physics vs survey-constrained OT; conservation) — [presenter]
4. Block model and uncertainty (confidence classes, MC, OAT) — [presenter]
5. Platform demo (ingest → run → change report) and limitations/recommendations — [presenter]

## D8 — Individual teamwork reflection and peer/self-assessment
- My contributions (link to commits, documents, decisions): [...]
- Coordination, leadership/followership, conflict resolution examples: [...]
- Workload equity and inclusive practice: [...]
- Peer/self-assessment (confidential, per course form): [...]

## D9 — Individual professional responsibility, ethics and equity assessment
Use `professional_practice.md` as shared evidence, but write your own:
ethical issues, affected parties, uncertainty disclosure, risks, bias/equity
concerns, professional responsibilities, required actions, and a justified
recommendation in your own words.
