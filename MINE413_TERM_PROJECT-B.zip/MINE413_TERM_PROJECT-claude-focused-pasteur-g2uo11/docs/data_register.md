# Data Register and QA/QC Findings (Deliverable D2, part 1)

Generated outputs referenced here live in `outputs/01_qaqc/` and are
re-created by `python -m stockpile_model run --stages qaqc`. Numbers below are
from the run on the supplied data (`Data_Topo 2026.zip`, SHA-256 of members in
`data/raw/ingest_log.csv`). Evidence category is given in brackets.

## 1. Dataset inventory

| File | Content | Records | Period / extent |
|---|---|---|---|
| `Dump Data.csv` | FMS dump records: Cycle ID, payload, Au, Ag, Cu, Dens, dump X/Y/Z, timestamp | 275 [MEASURED] | 15 Mar 2026 17:43 → 31 Mar 2026 20:52 |
| `Topo_260315.dxf` … `Topo_250329.dxf` (10 files) | DXF 2013, one layer each, 5,534–15,516 `3DFACE` triangles | 10 surveys [MEASURED] | 15, 16, 18, 19, 20, 21, 22, 27, 28, 29 March |

Not supplied (relevant to the assignment's list in §3.2): truck ID, source /
dig-block ID, loader ID, dozer activity logs, a full pre-stockpile base
surface, and a full current topographic surface. Their absence is discussed
in §4.

Full per-file details: `dataset_inventory.csv` (hashes, layer names, date
codes, extents, degenerate faces, solid volumes).

## 2. Survey files — what they actually contain

**Finding S1 — the DXFs are closed fill-increment solids, not topographic
surfaces [INFERRED, A-009].** Rasterising each TIN on a 0.5 m grid,
≥ 99.98 % of covered cells are intersected by exactly two faces (a top and a
base, `survey_closure_check.csv`). Thickness pinches to zero at the outline.
Each solid covers only a 1,300–3,200 m² crescent-shaped band on the advancing
south face of the pile. On 7 of 9 consecutive pairs the base of solid k+1
equals the top of solid k on 100 % of their overlap (median Δz = 0.000 m,
`survey_stacking_pairs.csv`).

Consequences: (i) volumes are read directly as solid volumes; (ii) the
supplied files record only *fill* — elevation decreases are not directly
observed (assignment Task 2 "elevation decrease"), and (iii) the top of the
pile (where trucks dump) is surveyed only where it rose.

**Finding S2 — survey gaps [CALCULATED].** No surveys for 17 March or
23–26 March. The stacking mismatches (3/16→3/18: 23.5 % of overlap with cut up
to 0.43 m; 3/22→3/27: 4.7 % cut, fill up to 0.64 m) are consistent with
unsupplied intermediate solids. Interval 7 (Topo_260327) therefore spans 5 days.

**Finding S3 — evidence of cut / rehandle [CALCULATED].** Across
non-consecutive pairs, the base of a later solid lies below the top of an
earlier one by up to 2.74 m (e.g. 3/15→3/18: 17.5 % of a 1,372 m² overlap).
This is material placed and later removed (most plausibly dozer crest
re-pushing). Visible cut volumes are small (pairwise sums of a few hundred m³
against 35,107 m³ of fill).

**Finding S4 — date metadata conflict [MEASURED].** File names: 8 × `26MMDD`,
2 × `25MMDD`; layer names: 10 × `25MMDD`; DXF `$TDUPDATE` = 2025-11-13 for all.
Resolved by A-001 (year 2026, MMDD from file name).

**Finding S5 — unit metadata defect [MEASURED].** DXF headers declare
`$INSUNITS = 1` (inches) and `$MEASUREMENT = 0` (imperial). Coordinates are
evidently metres (A-002). Header units are ignored.

**Finding S6 — degenerate faces [MEASURED].** 220–649 zero-plan-area faces per
file (2–9 %), mostly vertical slivers at the solid outline. Dropped during
rasterisation (they cannot carry plan area); counts retained in the inventory.

**Finding S7 — survey resolution [CALCULATED].** Median TIN edge 0.84–1.04 m
(95th percentile 1.5–2.4 m). Surface slopes have a median of 32–36°, close to
the angle of repose of loose broken rock — the faces are tipping/push faces.

## 3. FMS records

All 275 records are retained in `fms_flagged.csv` with their original row
number (`source_row`), every QA flag (`qa_*`) and three usage columns
(`use_in_model`, `use_location`, `use_grade`). Nothing is deleted.

| Rule | Records | Tonnes | Model action |
|---|---:|---:|---|
| Missing / non-numeric values, duplicate Cycle IDs | 0 | 0 | — |
| `PAYLOAD_PARTIAL` (≤ 76 t) | 3 | 152 | kept, flagged |
| `PAYLOAD_HIGH` (> 228 t: 266, 304, 304) | 3 | 874 | kept as recorded, flagged; payload uncertainty |
| `LOC_DEFAULT` (identical XYZ 511334.70, 7122320.38, 4473.00 ×14) | 14 | 2,356 | location treated as unknown (A-006) |
| `LOC_Z_INCONSISTENT` (> 5 m outside surface envelope) | 2 | 380 | kept, flagged (1 is also `LOC_DEFAULT`) |
| `LOC_OUTSIDE_SURVEYS` (outside every fill solid) | 58 | 9,462 | informational — pad-interior dumps later pushed over the crest |
| `TIME_AFTER_LAST_SURVEY` (31 Mar 20:52) | 1 | 228 | excluded from current model, reported as pending (A-012) |
| `TIME_DUPLICATE` (two trucks, same minute, 13 m apart) | 2 | 304 | informational |

**F1 — payload quantisation [MEASURED → INFERRED, A-008].** All payloads are
multiples of 38 t (38: 2, 76: 1, 114: 27, 152: 155, 190: 75, 228: 12, 266: 1,
304: 2). Payloads are nominal pass counts, not weights.

**F2 — grades are source attributes [MEASURED → INFERRED, A-007].** 21
distinct (Au, Ag, Cu, Dens) tuples; the five largest carry 92 % of tonnage.
Tonnage-weighted Cu 8.42 %, Au 8.00 g/t, Dens 2.07 t/m³ [CALCULATED]. Grade
units assumed (A-004); values are unusually high for a porphyry.

**F3 — Cycle ID order ≠ dump order [MEASURED].** 31 inversions when sorted by
time. Cycle IDs are presumably issued at loading; trucks overtake on the haul.
Not an error; records are ordered by timestamp.

**F4 — shift structure [MEASURED].** No dumps 00:00–01:30, 18:30–20:00 and
only 2 between 06:00–07:30 → 12-h shifts with changes ≈ 06:30 and ≈ 19:00 and
meal breaks. Used as evidence for A-003.

**F5 — dump Z [CALCULATED, A-005].** Relative to the surveyed surface
envelope of its interval, dump Z has median −0.23 m (IQR −1.36 to 0.00 m).
Z is ground-referenced with ≈ ±2 m precision; used for QA only. An earlier
version of this check compared Z with the *start*-of-interval surface and
wrongly flagged 13 late-interval dumps on 19–20 March; those trucks were
tipping onto fill that had grown by up to 10 m during the interval. The check
was corrected to use the [base, top] envelope (decision ED-004).

**F6 — dumps relative to fill [CALCULATED].** 217/275 dumps lie inside the
union footprint of all solids; per interval, dumps sit on the pile top behind
(north of) the crest band that fills during the same interval
(`fig_fill_solids_by_interval.png`) — the expected signature of truck dumping
followed by dozer push-over.

## 4. Temporal alignment and FMS completeness

Interval table at the adopted cut-off (A-003), `interval_summary.csv`
[CALCULATED]:

| k | Survey | Loads | FMS t | Fill m³ | t / m³ | Fill ÷ Σ(t/Dens) |
|---|---|---:|---:|---:|---:|---:|
| 0 | Topo_260315 | 14 | 2,432 | 2,868 | 0.85 | 2.37 |
| 1 | Topo_260316 | 25 | 4,142 | 2,309 | 1.79 | 1.20 |
| 2 | Topo_260318 | 42 | 6,802 | 4,842 | 1.40 | 1.52 |
| 3 | Topo_260319 | 71 | 11,704 | 8,710 | 1.34 | 1.59 |
| 4 | Topo_260320 | 17 | 3,040 | 2,148 | 1.42 | 1.50 |
| 5 | Topo_260321 | 12 | 2,166 | 1,426 | 1.52 | 1.40 |
| 6 | Topo_260322 | 24 | 3,838 | 2,888 | 1.33 | 1.49 |
| 7 | Topo_260327 | 21 | 3,116 | 3,683 | 0.85 | 2.28 |
| 8 | Topo_250328 | 41 | 6,004 | 4,923 | 1.22 | 1.59 |
| 9 | Topo_250329 | 7 | 1,178 | 1,311 | 0.90 | 2.20 |
| | **Total** | **274** | **44,422** | **35,107** | **1.27** | **2.06**¹ |

¹ ratio of totals uses Σ(t/Dens) = 21,525 m³.

**F7 — volume conversion [CALCULATED].** For six of ten intervals the fill
volume is a consistent 1.40–1.59 × the volume implied by `t / Dens`. Either
`Dens` is not the in-pile bulk density (e.g. it is an in-situ density and the
pile has ≈ 50 % bulking), or fills systematically include material not in the
FMS. Phase 2 quantifies this.

**F8 — probable FMS gaps [INFERRED].** Intervals 0, 7 and 9 carry roughly
1.5 × more fill than consistent intervals would predict:
interval 0 — FMS starts 15 Mar 17:43 although the interval opens 07:00;
interval 7 — only one load between 22 Mar 18:28 and 28 Mar 03:54 for a
3,683 m³ fill; interval 9 — no records between 29 Mar 08:17 and 31 Mar 20:52.
These match the assignment scenario's "less complete operating periods" and
must not be resolved by silently lowering density (Phase 2 treatment).

## 5. Preprocessing decisions (summary — details in `decision_log.md`)

1. No record or face is deleted; FMS flags + usage columns; degenerate faces
   counted (ED-002).
2. Survey year forced to 2026 (A-001); interval cut-off D+1 07:00 (A-003).
3. Fallback-coordinate loads keep mass and grade; location treated as
   unknown (A-006).
4. One post-survey load excluded from the current model and reported as
   pending (A-012).
5. Z is QA-only (A-005); Z check uses the interval surface envelope (ED-004).
