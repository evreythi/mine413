# Platform Guide (Deliverable D5)

Audience: a mine-planning engineer who did not build the platform
(assignment reproducibility standard). No programming is needed for routine
updates; changing assumptions means editing `config/default.toml`.

## 1. Installation
Python ≥ 3.11 and the packages in `requirements.txt`:

```bash
pip install -r requirements.txt
python -m pytest -q          # optional: confirms the installation reproduces the tested results
```

## 2. Input formats

| Input | Format | Notes |
|---|---|---|
| FMS dump export | CSV with header `Cycle ID, Truck PayLoad, Au, Ag, Cu, Dens, X (Dump Event), Y (Dump Event), Z (Dump Event), Dump_tstamp`; timestamp `M/D/YYYY H:MM` | Several files may be ingested; exact duplicates are collapsed, conflicting duplicates flagged. Units per A-004. |
| Survey | DXF (any version readable by ezdxf) containing `3DFACE` triangles forming a **closed fill solid** for one survey interval; file name `Topo_YYMMDD.dxf` | Quadrilateral faces are rejected (format change must be investigated). The year is taken from config (`data.survey_year`, A-001) until the naming issue is fixed. |
| Manual interventions | `config/manual_interventions.csv`: `id,type,cycle_id,reason,author,date`; types `exclude_record`, `location_unknown` | Rows without reason/author/date are rejected. Applied interventions are listed in every run's QA output and manifest. |

If the survey department starts supplying **full topographic surfaces**
instead of fill solids, `io_survey`/`surfaces` must be extended (difference
consecutive surfaces into fill and cut); the closure check in the QA stage
will detect the change (cells hit once instead of twice).

## 3. Routine update workflow (Task 8 steps 1–11)

| Step | Command / file | What happens |
|---|---|---|
| 1–2 Import new FMS records and surveys | `python -m stockpile_model ingest <zip or folder>` | Files copied unmodified to `data/raw/`, logged with SHA-256 in `data/raw/ingest_log.csv`; identical re-imports are no-ops; a different file under an existing name is refused. |
| 3 QA checks | `run` → `outputs/01_qaqc/` | 18 rules flag records (never deleted); closure/stacking checks on surveys; cut-off scan. Review `qa_flag_summary.csv` and figures before accepting the run. |
| 4 New placement & period | automatic | Records are assigned to survey intervals (cut-off D+1 07:00, A-003); records after the last survey are reported as *pending*. |
| 5 Movement algorithm | `outputs/03_movement/` | Forward-model validation and survey-constrained allocation; conservation checks per interval. |
| 6–7 Block model, inventories | `outputs/04_blockmodel/` | Rebuilt from all data (full recompute, ≈ 2 min without the uncertainty stage). |
| 8 Uncertainty | `outputs/05_uncertainty/` | OAT sensitivity, Monte Carlo (`--mc N`), final confidence class. |
| 9 QA/QC & reconciliation outputs | `validation_metrics.csv`, `growth_budget_and_reconciliation.csv` | |
| 10 Visualisations & exports | PNG figures; CSV, mine-software CSV, VTK | |
| 11 Audit | `run_manifest.json`, `run_history.csv`, `history/<run_id>/`, `change_report.txt` | Inputs + hashes, git commit, library versions, full configuration, interventions, summaries; comparison with the previous model. |

The model is recomputed from all ingested data each run rather than patched
incrementally; this guarantees that a revised assumption or a corrected
record propagates through the whole history. Runtime: ≈ 2 min without the uncertainty
stage and ≈ 13 min with 60 Monte-Carlo realisations.

**Demonstrated:** `tests/test_platform.py` ingests the real FMS file with the
first 7 surveys, runs the model (≈ 10 kt pending), ingests the last 3 surveys,
re-runs, and checks that the pending loads are placed, the history/change
report record the update, and a manual intervention is applied and logged.

## 4. Acceptance checklist for each model update
1. `qa_flag_summary.csv`: any new rule counts? Investigate before use.
2. `survey_closure_check.csv`: every new survey ≥ 99.9 % cells hit twice.
3. `growth_budget_and_reconciliation.csv`: new interval ratio within the calibration band? If not, it is booked as UNK — find out why (FMS gap?).
4. `allocation_checks.csv`: mass in = mass out for the new interval.
5. `validation_metrics.csv`: held-out forward-model skill still better than baselines.
6. `change_report.txt`: are the inventory changes explained by the new data?
7. Sign-off recorded (who, when) — see `professional_practice.md` §3.

## 5. Changing an assumption
Edit the value in `config/default.toml` (each key cites its assumption ID),
update the entry in `docs/assumption_register.md` (status `REVISED`, with the
reason), re-run, and compare `change_report.txt`. Never edit outputs by hand.

## 6. Module map

| Module | Role |
|---|---|
| `ingest.py` | hashed import of raw files |
| `io_fms.py`, `io_survey.py` | readers; TIN rasteriser |
| `qaqc.py`, `stage_qaqc.py` | QA rules, inventory, cut-off scan |
| `surfaces.py`, `growth.py`, `reconcile.py`, `stage_growth.py` | solids, composite surface, cut/fill, stock-flow reconciliation |
| `physics.py`, `validation.py` | forward model, EMD metrics |
| `transport.py`, `movement.py`, `stage_movement.py` | optimal-transport allocation, layered column state |
| `blockmodel.py`, `stage_blockmodel.py` | block integration, attributes, exports |
| `uncertainty.py`, `stage_uncertainty.py` | OAT, Monte Carlo, final confidence, validation table |
| `audit.py` | manifests, history, change report, interventions |
